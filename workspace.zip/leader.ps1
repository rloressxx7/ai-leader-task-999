# Run the Ollama Leader (Windows PowerShell). ASCII-only for PS 5.1.
# Usage (note the leading .\ in PowerShell):
#   .\leader.ps1                          # serve (dashboard on 127.0.0.1:18789)
#   .\leader.ps1 doctor                   # environment/worker/tool check
#   .\leader.ps1 send "fix my bot"        # queue a task on the running server
#   .\leader.ps1 status                   # show active tasks
#   .\leader.ps1 stop-all                 # emergency stop
#   .\leader.ps1 claude-login             # log in the Claude worker
#   .\leader.ps1 arena-login --profile 1  # log in an Arena worker (you sign in)
Set-Location $PSScriptRoot
$env:PYTHONUTF8 = "1"
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "No venv found. Run .\setup.ps1 first." -ForegroundColor Red
    exit 1
}
& .\.venv\Scripts\python.exe -m app @args
