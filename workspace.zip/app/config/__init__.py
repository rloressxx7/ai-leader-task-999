"""Configuration.

Non-secret settings come from a TOML file (``config.toml`` next to the project,
or the path in ``LEADER_CONFIG``). Secrets are only ever read from environment
variables (optionally loaded from ``secrets.env``) and are never written to the
database, logs or memory.
"""
from __future__ import annotations

import glob
import os
import re
import shutil
import sys
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

PROJECT_ROOT = Path(__file__).resolve().parents[2]

Level = Literal["AUTO", "CONFIRM", "BLOCK"]


class LeaderSettings(BaseModel):
    model: str = "gemma4:26b"
    ollama_url: str = "http://127.0.0.1:11434"
    mode: Literal["MANUAL", "ASSISTED", "AUTONOMOUS"] = "AUTONOMOUS"
    llm_timeout_s: float = 300
    num_ctx: int = 16384
    keep_alive: str = "30m"


class EngineSettings(BaseModel):
    max_parallel_tasks: int = 2
    max_fix_iterations: int = 3
    max_worker_retries: int = 1          # retries on the same worker for transient errors
    max_step_attempts: int = 5           # total attempts across all workers for one step
    step_timeout_min: float = 45
    stall_timeout_min: float = 12        # no output from a worker for this long -> stalled
    verify_timeout_min: float = 25
    poll_interval_s: float = 2.0
    rate_limit_cooldown_min: float = 60  # used when a provider gives no reset time
    max_recoveries: int = 3              # automatic crash recoveries per task before FAILED
    supervisor_interval_s: float = 30    # watchdog cadence for orphaned/stalled tasks
    orphan_grace_s: float = 90           # active-but-not-running this long -> recover
    worktree_root: str = ""              # default: <data_dir>/worktrees
    remove_worktree_on_success: bool = True


class ClaudeCodeSettings(BaseModel):
    enabled: bool = True
    path: str = "auto"
    model: str = ""                      # high-effort model ("" = account default)
    low_model: str = "haiku"             # fast/cheap model used when the leader picks low effort
    permission_mode: str = "acceptEdits"
    allowed_tools: list[str] = Field(default_factory=lambda: [
        "Read", "Glob", "Grep", "Edit", "Write", "MultiEdit", "NotebookEdit", "TodoWrite",
        "Bash(cargo:*)", "Bash(rustc:*)", "Bash(npm:*)", "Bash(npx:*)", "Bash(node:*)",
        "Bash(pnpm:*)", "Bash(yarn:*)", "Bash(python:*)", "Bash(py:*)", "Bash(pytest:*)",
        "Bash(go:*)", "Bash(git status:*)", "Bash(git diff:*)", "Bash(git log:*)",
        "Bash(git show:*)", "Bash(ls:*)", "Bash(dir:*)", "Bash(cat:*)", "Bash(type:*)",
    ])
    max_turns: int = 80
    max_concurrency: int = 2
    extra_args: list[str] = Field(default_factory=list)


class CodexSettings(BaseModel):
    enabled: bool = True
    path: str = "auto"
    model: str = ""
    sandbox: Literal["read-only", "workspace-write", "danger-full-access"] = "workspace-write"
    low_effort: str = "low"              # model_reasoning_effort when leader picks low effort
    high_effort: str = "high"           # ...and when it picks high effort
    max_concurrency: int = 2
    extra_args: list[str] = Field(default_factory=list)


class GenericWorkerSettings(BaseModel):
    name: str
    enabled: bool = False
    provider: str = "generic"
    model: str = ""
    command: list[str]                   # "{prompt}" and "{workspace}" are substituted
    prompt_via: Literal["stdin", "arg"] = "stdin"
    capabilities: list[str] = Field(default_factory=lambda: [
        "execute_task", "write_code", "edit_files", "create_files", "inspect_project", "review_code", "debug"])
    max_concurrency: int = 1
    auth_error_patterns: list[str] = Field(default_factory=list)
    rate_limit_patterns: list[str] = Field(default_factory=list)


class ArenaSettings(BaseModel):
    enabled: bool = False
    count: int = 2
    url: str = "https://arena.ai/agent"
    browser_channel: str = "chrome"
    headless: bool = False
    response_timeout_min: float = 20
    idle_settle_s: float = 18.0         # response done after this much no-change (Arena streams w/ long pauses during web search)
    max_context_chars: int = 60000
    # Arena's terms allow prompts to be used/shared for research. Code is sent only
    # after secret redaction, and only when this is explicitly true.
    allow_sending_code: bool = False
    # Arena is an agent that keeps files in its own cloud workspace and streams
    # reasoning, so scraping code files out of it is unreliable. By default Arena is
    # used for its strengths (research, review, edge-cases, investigation) and NOT for
    # writing code — that keeps every worker productive instead of failing implement
    # steps. Turn on only with github_handoff configured for experimental coding.
    allow_implement: bool = False
    # Optional reliable handoff. Authentication is read only from
    # GITHUB_HANDOFF_TOKEN in secrets.env.
    github_handoff: bool = False
    github_repo: str = "ai-leader-handoffs"  # repo name or owner/name
    github_repo_per_task: bool = True
    github_repo_prefix: str = "ai-leader-task"
    # DOM selectors (Arena's UI is login-gated; override here if the defaults drift).
    composer_selector: str = ""         # empty -> auto-detect textarea/contenteditable
    response_selector: str = ""         # empty -> whole-page text diff heuristic
    logged_in_markers: list[str] = Field(default_factory=lambda: [
        "New Chat", "Agent Mode", "Send a message", "Ask anything"])
    login_markers: list[str] = Field(default_factory=lambda: [
        "Sign in", "Log in", "Continue with Google", "Connect your GitHub"])


class WorkersSettings(BaseModel):
    claude_code: ClaudeCodeSettings = Field(default_factory=ClaudeCodeSettings)
    codex: CodexSettings = Field(default_factory=CodexSettings)
    arena: ArenaSettings = Field(default_factory=ArenaSettings)
    generic: list[GenericWorkerSettings] = Field(default_factory=list)
    # Env vars inherited from a host agent session that must not leak into workers.
    scrub_env_prefixes: list[str] = Field(default_factory=lambda: [
        "CLAUDECODE", "CLAUDE_CODE_", "CLAUDE_AGENT_SDK", "CLAUDE_PID", "CLAUDE_EFFORT",
        "CLAUDE_PREVIEW_"])


class PolicySettings(BaseModel):
    rules: dict[str, Level] = Field(default_factory=dict)  # overrides of security.policy.DEFAULT_RULES
    bulk_delete_threshold: int = 25
    extra_patterns: dict[str, list[str]] = Field(default_factory=dict)


class DashboardSettings(BaseModel):
    host: str = "127.0.0.1"
    port: int = 18789


class InstagramSettings(BaseModel):
    enabled: bool = False
    api_base: str = "https://graph.instagram.com"
    graph_version: str = "v23.0"
    allowed_sender_ids: list[str] = Field(default_factory=list)


class WhatsAppSettings(BaseModel):
    enabled: bool = False
    api_base: str = "https://graph.facebook.com"
    graph_version: str = "v23.0"
    phone_number_id: str = ""
    allowed_numbers: list[str] = Field(default_factory=list)


class InstagramScrapeSettings(BaseModel):
    """Instagram via browser scraping (no Meta API): you log in once with your own
    session/cookies (persistent profile), then the leader watches ONE conversation
    thread and replies in it. Only that thread is watched, so only that person is
    answered. Automating Instagram may violate its Terms and risks account limits —
    use your own account, at a conservative poll rate, at your own risk."""
    enabled: bool = False
    profile_dir: str = ""               # default: <data_dir>/instagram/profile
    headless: bool = False              # keep visible so you can see/intervene
    browser_channel: str = "chrome"
    thread_url: str = ""                # the DM conversation to watch: instagram.com/direct/t/<id>/
    allowed_usernames: list[str] = Field(default_factory=list)  # optional extra guard
    poll_interval_s: float = 20.0       # be gentle; too fast looks like a bot
    max_reply_chars: int = 900
    push_reports: bool = True           # also push task progress into the thread


class TelegramSettings(BaseModel):
    """Remote control via a Telegram bot. Token from env TELEGRAM_BOT_TOKEN.
    Uses long-polling (getUpdates), so it works from behind NAT/localhost with no
    tunnel or public IP. Only allow-listed chat ids are answered."""
    enabled: bool = False
    allowed_chat_ids: list[int] = Field(default_factory=list)
    poll_timeout_s: int = 30


class MessagingSettings(BaseModel):
    gateway_host: str = "127.0.0.1"
    gateway_port: int = 18790
    coalesce_seconds: float = 4.0
    max_message_chars: int = 3500
    verbose: bool = True                # report every event ("her seyden haberimiz olsun")
    notify_events: list[str] = Field(default_factory=lambda: [
        "TASK_STARTED", "PLAN_READY", "WORKER_ASSIGNED", "WORKER_COMPLETED", "WORKER_FAILED",
        "FAILOVER", "REVIEW_RESULT", "TEST_STARTED", "TEST_FAILED", "FIX_STARTED", "TEST_PASSED",
        "QUOTA_WARNING",
        "MERGED", "TASK_COMPLETED", "TASK_BLOCKED", "TASK_FAILED", "APPROVAL_REQUIRED",
        "TASK_CANCELLED", "TASK_PAUSED"])
    instagram: InstagramSettings = Field(default_factory=InstagramSettings)
    instagram_scrape: InstagramScrapeSettings = Field(default_factory=InstagramScrapeSettings)
    whatsapp: WhatsAppSettings = Field(default_factory=WhatsAppSettings)
    telegram: TelegramSettings = Field(default_factory=TelegramSettings)


class ProjectsSettings(BaseModel):
    roots: list[str] = Field(default_factory=lambda: ["~"])
    scan_depth: int = 1
    new_project_root: str = "~/leader-projects"
    exclude: list[str] = Field(default_factory=lambda: [
        "AppData", "node_modules", ".cache", ".cargo", ".rustup", "vcpkg", "OneDrive",
        "Music", "Pictures", "Videos", "Contacts", "Favorites", "Links", "Searches",
        "Saved Games", "3D Objects"])


class Settings(BaseModel):
    data_dir: str = "data"
    leader: LeaderSettings = Field(default_factory=LeaderSettings)
    engine: EngineSettings = Field(default_factory=EngineSettings)
    workers: WorkersSettings = Field(default_factory=WorkersSettings)
    policy: PolicySettings = Field(default_factory=PolicySettings)
    dashboard: DashboardSettings = Field(default_factory=DashboardSettings)
    messaging: MessagingSettings = Field(default_factory=MessagingSettings)
    projects: ProjectsSettings = Field(default_factory=ProjectsSettings)

    @property
    def data_path(self) -> Path:
        p = Path(os.path.expanduser(self.data_dir))
        if not p.is_absolute():
            p = PROJECT_ROOT / p
        return p

    @property
    def worktree_path(self) -> Path:
        if self.engine.worktree_root:
            return Path(os.path.expanduser(self.engine.worktree_root))
        return self.data_path / "worktrees"


def load_secrets_file(path: Path | None = None) -> None:
    """Load KEY=VALUE lines from secrets.env into os.environ (without overriding)."""
    path = path or PROJECT_ROOT / "secrets.env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def secret(name: str) -> str | None:
    """Read a secret from the environment. Never persist the returned value."""
    v = os.environ.get(name)
    return v if v else None


def load_settings(path: str | os.PathLike | None = None) -> Settings:
    load_secrets_file()
    path = path or os.environ.get("LEADER_CONFIG") or PROJECT_ROOT / "config.toml"
    p = Path(path)
    if p.exists():
        with p.open("rb") as f:
            return Settings.model_validate(tomllib.load(f))
    return Settings()


# --------------------------------------------------------------------------- discovery

def _version_key(p: str) -> tuple:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", p)
    return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)


def discover_claude(configured: str = "auto") -> str | None:
    if configured and configured != "auto":
        return configured if Path(configured).exists() or shutil.which(configured) else None
    found = shutil.which("claude")
    if found:
        return found
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        local = os.environ.get("LOCALAPPDATA", "")
        cands = glob.glob(os.path.join(appdata, "Claude", "claude-code", "*", "claude.exe"))
        cands += glob.glob(os.path.join(local, "Packages", "Claude_*", "LocalCache", "Roaming",
                                        "Claude", "claude-code", "*", "claude.exe"))
        cands += glob.glob(os.path.join(os.path.expanduser("~"), ".local", "bin", "claude.exe"))
        if cands:
            return max(cands, key=_version_key)
    else:
        for c in ("~/.local/bin/claude", "~/.claude/local/claude"):
            c = os.path.expanduser(c)
            if os.path.exists(c):
                return c
    return None


def discover_codex(configured: str = "auto") -> str | None:
    if configured and configured != "auto":
        return configured if Path(configured).exists() or shutil.which(configured) else None
    found = shutil.which("codex")
    if found:
        return found
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA", "")
        cands = glob.glob(os.path.join(local, "OpenAI", "Codex", "bin", "*", "codex.exe"))
        if cands:
            return max(cands, key=os.path.getmtime)
    return None


def discover_git_bash() -> str | None:
    if sys.platform != "win32":
        return shutil.which("bash")
    for c in (r"C:\Program Files\Git\bin\bash.exe", r"C:\Program Files (x86)\Git\bin\bash.exe"):
        if os.path.exists(c):
            return c
    git = shutil.which("git")
    if git:  # ...\Git\cmd\git.exe or ...\Git\mingw64\bin\git.exe
        root = Path(git).resolve().parents[1]
        for c in (root / "bin" / "bash.exe", root.parent / "bin" / "bash.exe"):
            if c.exists():
                return str(c)
    return None


def discover_chrome() -> str | None:
    cands = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        "/usr/bin/google-chrome", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ]
    for c in cands:
        if os.path.exists(c):
            return c
    return shutil.which("chrome") or shutil.which("google-chrome")
