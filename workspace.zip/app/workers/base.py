"""Unified worker abstraction.

A worker is an actionable coding agent (Claude Code, Codex, Arena, or a generic
CLI), not a chatbot. The orchestrator hands it a WorkerTask scoped to a workspace
and receives a WorkerResult describing what it actually did. Progress callbacks
feed the stall detector and the action log.

Capability model (what a worker advertises it can do):
    execute_task write_code edit_files create_files delete_files run_terminal
    run_tests build_project debug review_code inspect_project git_operations
    report_result
"""
from __future__ import annotations

import asyncio
import os
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Awaitable, Callable

Capability = str
ALL_CAPABILITIES = [
    "execute_task", "write_code", "edit_files", "create_files", "delete_files",
    "run_terminal", "run_tests", "build_project", "debug", "review_code",
    "inspect_project", "git_operations", "report_result",
]


class Availability(str, Enum):
    READY = "ready"
    BUSY = "busy"
    RATE_LIMITED = "rate_limited"
    UNAVAILABLE = "unavailable"     # not installed / not configured
    NEEDS_LOGIN = "needs_login"     # installed but not authenticated
    ERROR = "error"


class FailureKind(str, Enum):
    NONE = "none"
    TRANSIENT = "transient"         # network blip, timeout -> retry same worker
    RATE_LIMIT = "rate_limit"       # provider usage/quota -> mark unavailable, failover
    AUTH = "auth"                   # not logged in -> needs_login, failover
    STALLED = "stalled"             # no output for too long -> killed
    CANCELLED = "cancelled"
    FATAL = "fatal"                 # worker produced a clean error -> failover


@dataclass
class WorkerTask:
    task_id: int
    step_id: int
    kind: str                       # StepKind value
    instruction: str
    workspace: str
    read_only: bool = False
    context: str = ""               # project summary, prior results, review findings
    disallowed_categories: list[str] = field(default_factory=list)
    effort: str = "high"            # "low" (fast/cheap) or "high" (thorough), chosen by the leader
    timeout_s: float = 2700
    extra: dict = field(default_factory=dict)


@dataclass
class WorkerResult:
    ok: bool
    summary: str = ""
    output: str = ""                # full transcript / last message (already redacted upstream)
    failure: FailureKind = FailureKind.NONE
    error: str = ""
    files_changed: list[str] = field(default_factory=list)
    ran_commands: list[str] = field(default_factory=list)
    verdict: dict | None = None     # for review/edge_cases: {passed: bool, issues: [...]}
    usage: dict = field(default_factory=dict)
    duration_s: float = 0.0
    session_id: str = ""


ProgressCb = Callable[[str, str], None]        # (channel, text) -> None
CancelCheck = Callable[[], Awaitable[bool]]    # returns True if the step must abort


def scrub_env(prefixes: list[str], drop: list[str] | None = None) -> dict:
    """Environment for a child worker with host-agent variables removed, so a
    worker cannot mistake this orchestrator's session for its own."""
    env = dict(os.environ)
    drop = drop or []
    for k in list(env):
        if k in drop or any(k.startswith(p) for p in prefixes):
            env.pop(k, None)
    # Some Windows GUI launchers provide USERPROFILE but no HOME. Recent Codex
    # CLI builds require HOME even on Windows and otherwise fail before auth with
    # "Could not find home directory".
    if os.name == "nt" and not env.get("HOME") and env.get("USERPROFILE"):
        env["HOME"] = env["USERPROFILE"]
    env.setdefault("CI", "1")
    env.setdefault("GIT_TERMINAL_PROMPT", "0")
    return env


class Worker:
    provider = "generic"

    def __init__(self, name: str, model: str = "", capabilities: list[Capability] | None = None,
                 max_concurrency: int = 1):
        self.name = name
        self.model = model
        self.capabilities = capabilities or list(ALL_CAPABILITIES)
        self._sem = asyncio.Semaphore(max_concurrency)
        self.max_concurrency = max_concurrency
        self.last_error = ""

    def has(self, capability: Capability) -> bool:
        return capability in self.capabilities

    async def health(self) -> tuple[Availability, str]:
        """Cheap check: is this worker installed and authenticated right now?"""
        return Availability.READY, ""

    async def execute(self, task: WorkerTask, on_progress: ProgressCb,
                      should_cancel: CancelCheck | None = None) -> WorkerResult:
        raise NotImplementedError

    async def run(self, task: WorkerTask, on_progress: ProgressCb,
                  should_cancel: CancelCheck | None = None) -> WorkerResult:
        async with self._sem:
            start = time.monotonic()
            try:
                res = await self.execute(task, on_progress, should_cancel)
            except asyncio.CancelledError:
                res = WorkerResult(False, failure=FailureKind.CANCELLED, error="cancelled")
                res.duration_s = time.monotonic() - start
                raise
            except Exception as e:  # never let a worker crash take down the engine
                res = WorkerResult(False, failure=FailureKind.FATAL,
                                   error=f"{type(e).__name__}: {e}")
            res.duration_s = time.monotonic() - start
            self.last_error = res.error if not res.ok else ""
            return res


def match_any(text: str, patterns: list[str]) -> bool:
    low = text.lower()
    return any(p.lower() in low for p in patterns)


# Signals that a provider hit a usage/rate limit (checked in worker output).
RATE_LIMIT_SIGNALS = [
    "rate limit", "rate-limit", "429", "too many requests", "quota", "usage limit",
    "usage cap", "session limit", "resets at", "resets ", "overloaded", "capacity",
    "resource_exhausted", "insufficient_quota",
    "you've reached your", "limit reached", "please try again later", "plan limit",
    "upgrade your plan", "monthly limit",
]
AUTH_SIGNALS = [
    "not logged in", "please run /login", "please log in", "unauthorized", "401",
    "authentication", "invalid api key", "no api key", "login required", "session expired",
    "run `codex login`", "run codex login", "you are not signed in",
]


def classify_output(text: str, extra_rl: list[str] | None = None,
                    extra_auth: list[str] | None = None) -> FailureKind:
    if match_any(text, AUTH_SIGNALS + (extra_auth or [])):
        return FailureKind.AUTH
    if match_any(text, RATE_LIMIT_SIGNALS + (extra_rl or [])):
        return FailureKind.RATE_LIMIT
    return FailureKind.FATAL
