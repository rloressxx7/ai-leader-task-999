"""Generic CLI worker adapter.

Wraps any coding-agent CLI that takes a prompt (stdin or arg) and works on files in
a directory. Configure via [[workers.generic]] in config.toml. This is the extension
point for future compatible agents without touching the orchestrator.
"""
from __future__ import annotations

import time

from ..config import GenericWorkerSettings
from ..tools import terminal
from .base import (Availability, CancelCheck, FailureKind, ProgressCb, Worker, WorkerResult,
                   WorkerTask, classify_output, scrub_env)


class GenericWorker(Worker):
    def __init__(self, settings: GenericWorkerSettings, scrub_prefixes: list[str]):
        super().__init__(settings.name, model=settings.model,
                         capabilities=settings.capabilities,
                         max_concurrency=settings.max_concurrency)
        self.provider = settings.provider
        self.s = settings
        self.scrub_prefixes = scrub_prefixes

    def _env(self) -> dict:
        return scrub_env(self.scrub_prefixes)

    async def health(self) -> tuple[Availability, str]:
        if not self.s.enabled:
            return Availability.UNAVAILABLE, "disabled in config"
        if not self.s.command:
            return Availability.UNAVAILABLE, "no command configured"
        import shutil
        exe = self.s.command[0]
        if not (shutil.which(exe) or exe.startswith("/") or ":" in exe[:3]):
            return Availability.UNAVAILABLE, f"{exe} not found on PATH"
        return Availability.READY, f"generic CLI: {exe}"

    def _render(self, task: WorkerTask) -> tuple[list[str], str | None]:
        prompt = task.instruction
        if task.context:
            prompt = f"{task.instruction}\n\n## Context\n{task.context}"
        argv = []
        for part in self.s.command:
            part = part.replace("{workspace}", task.workspace)
            if "{prompt}" in part:
                part = part.replace("{prompt}", prompt)
            argv.append(part)
        stdin = prompt if self.s.prompt_via == "stdin" else None
        return argv, stdin

    async def execute(self, task: WorkerTask, on_progress: ProgressCb,
                      should_cancel: CancelCheck | None = None) -> WorkerResult:
        argv, stdin = self._render(task)
        on_progress("bash", " ".join(argv[:4]))
        start = time.monotonic()
        res = await terminal.run(argv, cwd=task.workspace, env=self._env(),
                                 timeout_s=min(task.timeout_s, task.extra.get("stall_s", 720) * 3),
                                 stdin_text=stdin)
        out = res.output
        if res.cancelled:
            return WorkerResult(False, failure=FailureKind.CANCELLED, error="cancelled", output=out[-8000:])
        if res.timed_out:
            return WorkerResult(False, failure=FailureKind.STALLED, error="timed out", output=out[-8000:])
        if not res.ok:
            kind = classify_output(out, self.s.rate_limit_patterns, self.s.auth_error_patterns)
            return WorkerResult(False, failure=kind, error=out.strip()[-1000:] or "nonzero exit",
                                output=out[-8000:])
        kind = classify_output(out, self.s.rate_limit_patterns, self.s.auth_error_patterns)
        if kind in (FailureKind.AUTH, FailureKind.RATE_LIMIT):
            return WorkerResult(False, failure=kind, error=f"{kind.value} detected in output",
                                output=out[-8000:])
        summary = out.strip().splitlines()[-1][:400] if out.strip() else "completed"
        result = WorkerResult(True, summary=summary, output=out[-16000:],
                              duration_s=time.monotonic() - start)
        if task.read_only:
            low = out.lower()
            idx = low.rfind("verdict:")
            result.verdict = {"passed": idx == -1 or "fail" not in low[idx:idx + 40],
                              "issues": [], "has_verdict": idx != -1}
        return result
