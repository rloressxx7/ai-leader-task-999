"""Claude Code worker — drives the real `claude` CLI in headless stream-json mode.

It inspects, reads, edits, creates files, runs allow-listed build/test commands,
debugs and reviews. It is NOT a chat wrapper: file edits and commands are executed
by Claude Code itself inside the workspace. The orchestrator still verifies results
independently and performs the git merge.

Write steps run in `acceptEdits` mode with a broad, user-configurable tool allow-list
(compilers, package managers, test runners, git read commands) so real work happens
without prompts; the policy deny-list (push/deploy/financial/…) is passed as
--disallowedTools so an autonomous loop cannot take irreversible/outward actions.
Read-only steps run in `plan` mode and cannot write at all.
"""
from __future__ import annotations

import asyncio
import json
import time

from ..config import ClaudeCodeSettings, discover_claude
from ..security.policy import CLAUDE_DISALLOWED, PolicyEngine
from ..tools import terminal
from .base import (Availability, CancelCheck, FailureKind, ProgressCb, Worker, WorkerResult,
                   WorkerTask, classify_output, scrub_env)

# Host-agent variables that make a nested `claude` think it is already in an SDK
# session (which makes it report "Not logged in"). These are stripped for the child.
_SCRUB_EXACT = [
    "CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION",
    "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN", "CLAUDE_CODE_OAUTH_SCOPES",
    "CLAUDE_CODE_SDK_HAS_HOST_AUTH_REFRESH", "CLAUDE_CODE_HOST_SESSION_ID", "CLAUDE_CODE_EXECPATH",
    "CLAUDE_AGENT_SDK_VERSION", "CLAUDE_PID", "CLAUDE_CODE_SESSION_ATTENDED",
    "CLAUDE_CODE_DESKTOP_APP_VERSION", "CLAUDE_CODE_TERMINAL_MCP_TOOLS", "ANTHROPIC_BASE_URL",
    "CLAUDE_EFFORT", "CLAUDE_CODE_REPORT_FINDINGS", "CLAUDE_CODE_ENABLE_ASK_USER_QUESTION_TOOL",
]
_SCRUB_PREFIX = ["CLAUDE_CODE_", "CLAUDE_AGENT_SDK", "CLAUDE_PREVIEW_"]

READ_ONLY_TOOLS = ["Read", "Glob", "Grep", "LS", "NotebookRead", "TodoWrite",
                   "Bash(git status:*)", "Bash(git diff:*)", "Bash(git log:*)", "Bash(git show:*)",
                   "Bash(ls:*)", "Bash(dir:*)", "Bash(cat:*)", "Bash(type:*)", "Bash(find:*)",
                   "Bash(rg:*)", "Bash(grep:*)"]
RESEARCH_TOOLS = ["Read", "Glob", "Grep", "LS", "TodoWrite", "WebSearch", "WebFetch"]


class ClaudeCodeWorker(Worker):
    provider = "anthropic"

    def __init__(self, settings: ClaudeCodeSettings, policy: PolicyEngine, scrub_prefixes: list[str],
                 instance: int = 0):
        name = "claude_code" if instance == 0 else f"claude_code#{instance}"
        super().__init__(name, model=settings.model or "default",
                         capabilities=["execute_task", "write_code", "edit_files", "create_files",
                                       "delete_files", "run_terminal", "run_tests", "build_project",
                                       "debug", "review_code", "inspect_project", "git_operations",
                                       "report_result"],
                         max_concurrency=settings.max_concurrency)
        self.s = settings
        self.policy = policy
        self.scrub_prefixes = list(set(scrub_prefixes) | set(_SCRUB_PREFIX))
        self.exe = discover_claude(settings.path)

    def _env(self) -> dict:
        return scrub_env(self.scrub_prefixes, drop=_SCRUB_EXACT)

    async def health(self) -> tuple[Availability, str]:
        if not self.s.enabled:
            return Availability.UNAVAILABLE, "disabled in config"
        self.exe = self.exe or discover_claude(self.s.path)
        if not self.exe:
            return Availability.UNAVAILABLE, "claude CLI not found"
        # `claude auth status` prints JSON to stdout but exits nonzero when logged out,
        # so parse stdout regardless of exit code.
        res = await terminal.run([self.exe, "auth", "status"], env=self._env(), timeout_s=30)
        data = None
        if "{" in res.stdout and "}" in res.stdout:
            try:
                data = json.loads(res.stdout[res.stdout.index("{"):res.stdout.rindex("}") + 1])
            except (ValueError, json.JSONDecodeError):
                data = None
        if data is None:
            return Availability.ERROR, f"could not read auth status: {res.tail(200)}"
        if data.get("loggedIn"):
            return Availability.READY, f"logged in ({data.get('authMethod', '?')})"
        return Availability.NEEDS_LOGIN, "not logged in — run: claude auth login (or: claude setup-token)"

    def _disallowed_tools(self) -> list[str]:
        # Workers never push; the leader owns version control. Plus any gated category.
        disallowed = list(CLAUDE_DISALLOWED["git_push"])
        for cat, pats in CLAUDE_DISALLOWED.items():
            if self.policy.level(cat).value != "AUTO":
                disallowed += [p for p in pats if p not in disallowed]
        return disallowed

    def _build_args(self, task: WorkerTask) -> list[str]:
        args = [self.exe, "-p", "--output-format", "stream-json", "--verbose",
                "--add-dir", task.workspace]
        model = (self.s.low_model if task.effort == "low" else self.s.model)
        if model:
            args += ["--model", model]
        if task.kind != "review":
            args += ["--max-turns", str(self.s.max_turns)]

        if task.kind == "research":
            args += ["--permission-mode", "plan", "--allowedTools", *RESEARCH_TOOLS]
            return args
        if task.read_only:
            args += ["--permission-mode", "plan", "--allowedTools", *READ_ONLY_TOOLS]
            return args

        # Write step: auto-accept edits + broad allow-list; deny-list still enforced.
        args += ["--permission-mode", self.s.permission_mode, "--allowedTools", *self.s.allowed_tools]
        disallowed = self._disallowed_tools()
        if disallowed:
            args += ["--disallowedTools", *disallowed]
        return args

    def _prompt(self, task: WorkerTask) -> str:
        header = {
            "research": "You are a senior research analyst. Research the question below using "
                        "web search and fetching sources. Do a DEEP GITHUB SCAN: search GitHub "
                        "for relevant repositories, open and read their code, READMEs and issues, "
                        "and note how each implements the thing (cite exact repo URLs and files). "
                        "Also fetch official docs and articles. Produce a thorough, well-structured "
                        "Markdown report: a short summary, key findings with details, a 'GitHub "
                        "repositories' section (repo, what it does, key files/approach), and a "
                        "'Sources' list of URLs. Be concrete and cite sources. "
                        "Do not modify files; output the full report as your final message.",
            "review": "You are a senior code reviewer. Review the change described below. "
                      "Do not modify files. End with a line 'VERDICT: PASS' or 'VERDICT: FAIL' "
                      "followed by a bullet list of concrete issues (file:line — problem).",
            "edge_cases": "You are a QA engineer hunting for bugs and missing edge cases. "
                          "Do not modify files. End with 'VERDICT: PASS' (no serious issues) or "
                          "'VERDICT: FAIL' and a bullet list of the edge cases/bugs found.",
        }.get(task.kind,
              "You are an expert software engineer working autonomously inside the given "
              "repository. Make the change directly in the files, then briefly verify it "
              "(build/tests if quick). Do not commit, push, or deploy — the orchestrator "
              "handles version control.")
        parts = [header, ""]
        if task.context:
            parts += ["## Context", task.context, ""]
        parts += ["## Task", task.instruction, "",
                  self.policy.worker_rules_text(),
                  "When done, output a one-line summary of exactly what you changed."]
        return "\n".join(parts)

    async def execute(self, task: WorkerTask, on_progress: ProgressCb,
                      should_cancel: CancelCheck | None = None) -> WorkerResult:
        if not self.exe:
            return WorkerResult(False, failure=FailureKind.AUTH, error="claude CLI not found")
        args = self._build_args(task)
        prompt = self._prompt(task)
        proc = await asyncio.create_subprocess_exec(
            *args, cwd=task.workspace, env=self._env(), stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            limit=8 * 1024 * 1024,
            **terminal.popen_kwargs())
        proc.stdin.write(prompt.encode("utf-8"))
        await proc.stdin.drain()
        proc.stdin.close()

        texts: list[str] = []
        files: set[str] = set()
        cmds: list[str] = []
        session_id = ""
        last_activity = time.monotonic()
        stderr_task = asyncio.create_task(proc.stderr.read())

        async def read_lines():
            nonlocal session_id, last_activity
            assert proc.stdout is not None
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                last_activity = time.monotonic()
                try:
                    ev = json.loads(line.decode("utf-8", errors="replace"))
                except json.JSONDecodeError:
                    continue
                self._handle_event(ev, texts, files, cmds, on_progress)
                if ev.get("session_id"):
                    session_id = ev["session_id"]

        reader = asyncio.create_task(read_lines())
        stall_s = task.extra.get("stall_s", 720)
        try:
            while not reader.done():
                _, pending = await asyncio.wait({reader}, timeout=2.0)
                if should_cancel and await should_cancel():
                    terminal.kill_tree(proc.pid)
                    reader.cancel()
                    return WorkerResult(False, failure=FailureKind.CANCELLED, error="cancelled",
                                        output="\n".join(texts)[-8000:])
                if time.monotonic() - last_activity > stall_s:
                    terminal.kill_tree(proc.pid)
                    reader.cancel()
                    return WorkerResult(False, failure=FailureKind.STALLED,
                                        error="no output past stall timeout",
                                        output="\n".join(texts)[-8000:],
                                        files_changed=sorted(files), ran_commands=cmds)
            await asyncio.wait_for(proc.wait(), timeout=60)
        except asyncio.TimeoutError:
            terminal.kill_tree(proc.pid)
            return WorkerResult(False, failure=FailureKind.STALLED, error="exceeded step timeout",
                                output="\n".join(texts)[-8000:], files_changed=sorted(files))
        finally:
            if not reader.done():
                reader.cancel()
            if proc.returncode is None:
                terminal.kill_tree(proc.pid)

        stderr = (await stderr_task).decode("utf-8", errors="replace")
        transcript = "\n".join(texts).strip()
        result = WorkerResult(True, output=transcript[-16000:], files_changed=sorted(files),
                              ran_commands=cmds, session_id=session_id,
                              summary=(texts[-1].strip()[:400] if texts else ""))

        if proc.returncode != 0:
            diagnostic = (stderr.strip() or transcript.strip() or
                          f"claude exited {proc.returncode}")
            return WorkerResult(False, failure=classify_output(diagnostic),
                                error=diagnostic[:1000],
                                output=(transcript + "\n" + stderr)[-8000:],
                                files_changed=sorted(files), ran_commands=cmds)
        low = transcript.lower()
        if "not logged in" in low or "please run /login" in low:
            return WorkerResult(False, failure=FailureKind.AUTH, error="claude not logged in",
                                output=result.output)
        if task.read_only:
            result.verdict = self._parse_verdict(transcript)
        if classify_output(low) == FailureKind.RATE_LIMIT and not files:
            return WorkerResult(False, failure=FailureKind.RATE_LIMIT,
                                error="provider rate/usage limit", output=result.output)
        return result

    def _handle_event(self, ev: dict, texts: list, files: set, cmds: list, on_progress: ProgressCb):
        if ev.get("type") != "assistant":
            return
        for block in ev.get("message", {}).get("content", []):
            bt = block.get("type")
            if bt == "text" and block.get("text", "").strip():
                texts.append(block["text"])
                on_progress("assistant", block["text"][:500])
            elif bt == "tool_use":
                name = block.get("name", "")
                inp = block.get("input", {})
                if name in ("Edit", "Write", "MultiEdit", "NotebookEdit") and inp.get("file_path"):
                    files.add(inp["file_path"])
                    on_progress("edit", f"{name} {inp['file_path']}")
                elif name == "Bash" and inp.get("command"):
                    cmds.append(inp["command"][:300])
                    on_progress("bash", inp["command"][:200])
                else:
                    on_progress("tool", name)

    @staticmethod
    def _parse_verdict(transcript: str) -> dict:
        low = transcript.lower()
        idx = low.rfind("verdict:")
        passed = True
        if idx != -1:
            tail = low[idx:idx + 40]
            passed = "pass" in tail and "fail" not in tail
        issues = [l.strip("-*• \t") for l in transcript.splitlines()
                  if l.strip().startswith(("-", "*", "•")) and l.strip()][:30]
        return {"passed": passed, "issues": issues, "has_verdict": idx != -1}
