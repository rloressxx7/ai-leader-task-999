"""Worker registry: builds workers from config, tracks live availability (persisted),
records performance stats, and selects the best worker for a step by capability,
availability and past success — never a hard-coded favourite."""
from __future__ import annotations

import time

from ..config import Settings
from ..database import Database
from ..security.policy import PolicyEngine
from .arena import ArenaWorker
from .base import Availability, Worker
from .claude_code import ClaudeCodeWorker
from .codex import CodexWorker
from .generic import GenericWorker

# Preferred worker per step kind when stats are tied/absent (order = preference).
KIND_PREFERENCE = {
    # Codex/Claude are the reliable coders; Arena writes code only if allow_implement
    # is on (and it advertises the capability), so it is last here and usually skipped.
    "implement": ["codex", "claude_code", "arena"],
    "fix": ["claude_code", "codex", "arena"],
    # Arena shines at review/edge-cases/research/analysis — it debates alongside the coders.
    "review": ["arena", "claude_code", "codex"],
    "edge_cases": ["arena", "codex", "claude_code"],
    "investigate": ["arena", "claude_code", "codex"],
    "research": ["arena", "claude_code", "codex"],   # deep research: Arena first
}
CAP_FOR_KIND = {
    "implement": "write_code", "fix": "write_code", "review": "review_code",
    "edge_cases": "debug", "investigate": "inspect_project", "research": "inspect_project",
}


class WorkerRegistry:
    def __init__(self, settings: Settings, db: Database, policy: PolicyEngine):
        self.settings = settings
        self.db = db
        self.policy = policy
        self.workers: dict[str, Worker] = {}
        self._build()

    def _build(self) -> None:
        s = self.settings
        prefixes = s.workers.scrub_env_prefixes
        if s.workers.claude_code.enabled:
            n = max(1, s.workers.claude_code.max_concurrency)
            # one logical worker; concurrency handled by its semaphore
            self._add(ClaudeCodeWorker(s.workers.claude_code, self.policy, prefixes))
        if s.workers.codex.enabled:
            self._add(CodexWorker(s.workers.codex, prefixes))
        for g in s.workers.generic:
            if g.enabled:
                self._add(GenericWorker(g, prefixes))
        if s.workers.arena.enabled:
            for i in range(1, max(1, s.workers.arena.count) + 1):
                profile = str(s.data_path / "arena" / f"profile-{i}")
                self._add(ArenaWorker(s.workers.arena, profile, instance=i))

    def _add(self, w: Worker) -> None:
        self.workers[w.name] = w
        row = self.db.query_one("SELECT name FROM workers_state WHERE name=?", (w.name,))
        if not row:
            self.db.execute(
                "INSERT INTO workers_state(name,enabled,availability,updated_at) VALUES(?,?,?,?)",
                (w.name, 1, Availability.READY.value, time.time()))
        for kind in ("write", "read", "test"):
            self.db.execute("INSERT OR IGNORE INTO worker_stats(worker,kind) VALUES(?,?)",
                            (w.name, kind))

    def register(self, w: Worker) -> None:
        self._add(w)

    def get(self, name: str) -> Worker | None:
        return self.workers.get(name)

    # ----------------------------------------------------------------- availability
    def set_availability(self, name: str, availability: Availability, *, reason: str = "",
                         until: float | None = None) -> None:
        self.db.execute(
            "UPDATE workers_state SET availability=?, unavailable_until=?, last_error=?, updated_at=? "
            "WHERE name=?",
            (availability.value, until, reason[:1000] or None, time.time(), name))

    def availability(self, name: str) -> tuple[Availability, float | None]:
        row = self.db.query_one("SELECT availability,unavailable_until FROM workers_state WHERE name=?",
                                (name,))
        if not row:
            return Availability.UNAVAILABLE, None
        return Availability(row["availability"] or "unavailable"), row["unavailable_until"]

    def mark_rate_limited(self, name: str, minutes: float) -> None:
        self.set_availability(name, Availability.RATE_LIMITED,
                              reason="provider usage/rate limit",
                              until=time.time() + minutes * 60)
        self.db.execute("UPDATE worker_stats SET limit_events=limit_events+1 WHERE worker=? AND kind='write'",
                        (name,))

    def mark_needs_login(self, name: str, reason: str = "") -> None:
        self.set_availability(name, Availability.NEEDS_LOGIN, reason=reason or "not logged in")

    def clear_availability(self, name: str) -> None:
        self.set_availability(name, Availability.READY)

    async def refresh_health(self) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for name, w in self.workers.items():
            try:
                avail, detail = await w.health()
            except Exception as e:
                avail, detail = Availability.ERROR, f"health error: {e}"
            cur, until = self.availability(name)
            # Don't override an active rate-limit cooldown that hasn't expired.
            if cur == Availability.RATE_LIMITED and until and until > time.time():
                out[name] = {"availability": cur.value, "detail": f"cooldown {int(until - time.time())}s"}
                continue
            self.set_availability(name, avail, reason=detail)
            out[name] = {"availability": avail.value, "detail": detail, "provider": w.provider,
                         "model": w.model, "capabilities": w.capabilities}
        return out

    def is_available_now(self, name: str) -> bool:
        w = self.workers.get(name)
        if not w:
            return False
        avail, until = self.availability(name)
        if avail == Availability.RATE_LIMITED and until and until <= time.time():
            self.clear_availability(name)
            return True
        return avail == Availability.READY

    # ----------------------------------------------------------------- stats
    @staticmethod
    def _stat_kind(step_kind: str) -> str:
        if step_kind in ("implement", "fix"):
            return "write"
        return "read"

    def record_result(self, name: str, step_kind: str, ok: bool, duration_s: float, *,
                       is_fix: bool = False) -> None:
        kind = self._stat_kind(step_kind)
        self.db.execute(
            f"UPDATE worker_stats SET completed=completed+?, failed=failed+?, "
            f"total_duration_s=total_duration_s+? WHERE worker=? AND kind=?",
            (1 if ok else 0, 0 if ok else 1, duration_s, name, kind))
        if is_fix:
            self.db.execute(
                "UPDATE worker_stats SET fixes_total=fixes_total+1, fixes_ok=fixes_ok+? "
                "WHERE worker=? AND kind='write'", (1 if ok else 0, name))

    def record_review_accuracy(self, name: str, accurate: bool) -> None:
        self.db.execute(
            "UPDATE worker_stats SET reviews_scored=reviews_scored+1, reviews_accurate=reviews_accurate+? "
            "WHERE worker=? AND kind='read'", (1 if accurate else 0, name))

    def stats(self, name: str) -> dict:
        rows = self.db.query("SELECT * FROM worker_stats WHERE worker=?", (name,))
        agg = {"completed": 0, "failed": 0, "total_duration_s": 0.0, "limit_events": 0,
               "fixes_ok": 0, "fixes_total": 0, "reviews_accurate": 0, "reviews_scored": 0}
        for r in rows:
            for k in agg:
                agg[k] += r.get(k, 0) or 0
        total = agg["completed"] + agg["failed"]
        agg["success_rate"] = agg["completed"] / total if total else None
        agg["avg_duration_s"] = agg["total_duration_s"] / agg["completed"] if agg["completed"] else None
        return agg

    def _score(self, name: str, step_kind: str) -> float:
        st = self.stats(name)
        sr = st["success_rate"]
        base = 0.5 if sr is None else sr  # unknown workers get a fair middle score
        # Among similarly reliable workers, prefer the one that has historically
        # finished sooner. Keep this bonus smaller than correctness so speed never
        # rewards a fast but failure-prone provider.
        avg = st["avg_duration_s"]
        speed_bonus = 0.05 if avg is None else 0.10 / (1.0 + avg / 300.0)
        pref = KIND_PREFERENCE.get(step_kind, list(self.workers))
        pref_bonus = 0.0
        for i, p in enumerate(pref):
            if name == p or name.startswith(p + "#"):
                pref_bonus = 0.15 * (len(pref) - i) / len(pref)
                break
        return base + pref_bonus + speed_bonus

    def select(self, step_kind: str, *, exclude: set[str] | None = None) -> Worker | None:
        exclude = exclude or set()
        cap = CAP_FOR_KIND.get(step_kind, "execute_task")
        candidates = [w for name, w in self.workers.items()
                      if name not in exclude and w.has(cap) and self.is_available_now(name)]
        if not candidates:
            return None
        return max(candidates, key=lambda w: self._score(w.name, step_kind))

    def candidates(self, step_kind: str, *, exclude: set[str] | None = None) -> list[str]:
        """Ordered failover list for a step kind."""
        exclude = exclude or set()
        cap = CAP_FOR_KIND.get(step_kind, "execute_task")
        avail = [w.name for name, w in self.workers.items()
                 if name not in exclude and w.has(cap) and self.is_available_now(name)]
        return sorted(avail, key=lambda n: self._score(n, step_kind), reverse=True)

    def summary_availability(self) -> str:
        parts = []
        for name in self.workers:
            avail, _ = self.availability(name)
            parts.append(f"{name}={avail.value}")
        return ", ".join(parts)

    def workers_hint(self) -> str:
        """Short description of available workers for the leader's planning prompt."""
        lines = []
        for name, w in self.workers.items():
            if self.is_available_now(name):
                lines.append(f"- {name} ({w.provider}): {', '.join(w.capabilities[:6])}")
        return "\n".join(lines) or "- (no workers currently available)"

    def snapshot(self) -> list[dict]:
        out = []
        for name, w in self.workers.items():
            avail, until = self.availability(name)
            st = self.stats(name)
            row = self.db.query_one("SELECT last_error FROM workers_state WHERE name=?", (name,))
            out.append({
                "name": name, "provider": w.provider, "model": w.model,
                "capabilities": w.capabilities, "availability": avail.value,
                "cooldown_s": int(until - time.time()) if until and until > time.time() else 0,
                "max_concurrency": w.max_concurrency,
                "completed": st["completed"], "failed": st["failed"],
                "success_rate": st["success_rate"], "avg_duration_s": st["avg_duration_s"],
                "limit_events": st["limit_events"], "last_error": (row or {}).get("last_error"),
            })
        return out
