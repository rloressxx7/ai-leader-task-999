"""OpenAI Codex worker — drives the real `codex exec --json` non-interactive interface.

Codex edits files and runs commands inside its own sandbox. Write steps use the
`workspace-write` sandbox (writes confined to the workspace, no approval prompts);
read-only steps use the `read-only` sandbox. The orchestrator runs the authoritative
build/test verification itself (Codex's sandbox may not see per-user runtimes).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path

from ..config import CodexSettings, discover_codex
from ..tools import terminal
from .base import (Availability, CancelCheck, FailureKind, ProgressCb, Worker, WorkerResult,
                   WorkerTask, classify_output, scrub_env)


class CodexWorker(Worker):
    provider = "openai"

    def __init__(self, settings: CodexSettings, scrub_prefixes: list[str], instance: int = 0):
        name = "codex" if instance == 0 else f"codex#{instance}"
        super().__init__(name, model=settings.model or "default",
                         capabilities=["execute_task", "write_code", "edit_files", "create_files",
                                       "delete_files", "run_terminal", "run_tests", "build_project",
                                       "debug", "review_code", "inspect_project", "report_result"],
                         max_concurrency=settings.max_concurrency)
        self.s = settings
        self.scrub_prefixes = scrub_prefixes
        self.exe = discover_codex(settings.path)

    def _env(self) -> dict:
        env = scrub_env(self.scrub_prefixes)
        # The desktop-bundled Windows CLI may not be able to derive its home from
        # a non-interactive GUI child process. An explicit CODEX_HOME makes auth
        # and config discovery deterministic (and matches Codex's normal default).
        if os.name == "nt" and not env.get("CODEX_HOME") and env.get("USERPROFILE"):
            default_home = Path(env["USERPROFILE"]) / ".codex"
            if default_home.exists():
                env["CODEX_HOME"] = str(default_home)
        return env

    async def health(self) -> tuple[Availability, str]:
        if not self.s.enabled:
            return Availability.UNAVAILABLE, "disabled in config"
        self.exe = self.exe or discover_codex(self.s.path)
        if not self.exe:
            return Availability.UNAVAILABLE, "codex CLI not found"
        res = await terminal.run([self.exe, "login", "status"], env=self._env(), timeout_s=30)
        out = res.output.lower()
        if "logged in" in out or "signed in" in out:
            return Availability.READY, res.output.strip()[:120]
        if "not logged in" in out or "not signed in" in out or "run" in out and "login" in out:
            return Availability.NEEDS_LOGIN, "not logged in — run: codex login"
        return (Availability.READY, "assumed ready") if res.ok else \
               (Availability.ERROR, res.tail(200))

    def _build_args(self, task: WorkerTask) -> list[str]:
        sandbox = "read-only" if task.read_only else self.s.sandbox
        args = [self.exe, "exec", "--json", "--skip-git-repo-check", "-C", task.workspace,
                "--sandbox", sandbox]
        if self.s.model:
            args += ["-m", self.s.model]
        effort = self.s.low_effort if task.effort == "low" else self.s.high_effort
        args += ["-c", f"model_reasoning_effort={effort}"]
        args += self.s.extra_args
        args += ["-"]  # read prompt from stdin
        return args

    def _prompt(self, task: WorkerTask) -> str:
        if task.kind in ("review", "edge_cases"):
            role = ("Review the change described below for correctness, security and style. "
                    if task.kind == "review" else
                    "Hunt for bugs and missing edge cases in the change described below. ")
            instr = (role + "Do NOT modify files. End your final message with 'VERDICT: PASS' or "
                     "'VERDICT: FAIL' followed by a bullet list of concrete issues.")
        else:
            instr = ("Work autonomously in this repository. Apply the change directly to the files. "
                     "Do not commit, push or deploy. Finish with a one-line summary of what you changed.")
        parts = [instr, ""]
        if task.context:
            parts += ["## Context", task.context, ""]
        parts += ["## Task", task.instruction]
        return "\n".join(parts)

    async def execute(self, task: WorkerTask, on_progress: ProgressCb,
                      should_cancel: CancelCheck | None = None) -> WorkerResult:
        if not self.exe:
            return WorkerResult(False, failure=FailureKind.AUTH, error="codex CLI not found")
        args = self._build_args(task)
        proc = await asyncio.create_subprocess_exec(
            *args, cwd=task.workspace, env=self._env(), stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            limit=8 * 1024 * 1024,
            **terminal.popen_kwargs())
        proc.stdin.write(self._prompt(task).encode("utf-8"))
        await proc.stdin.drain()
        proc.stdin.close()

        messages: list[str] = []
        files: set[str] = set()
        cmds: list[str] = []
        usage: dict = {}
        session_id = ""
        last_activity = time.monotonic()
        stderr_task = asyncio.create_task(proc.stderr.read())

        async def read_lines():
            nonlocal session_id, last_activity, usage
            assert proc.stdout is not None
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                last_activity = time.monotonic()
                try:
                    ev = json.loads(line.decode("utf-8", errors="replace"))
                except json.JSONDecodeError:
                    continue
                t = ev.get("type", "")
                if t == "thread.started":
                    session_id = ev.get("thread_id", "")
                elif t == "turn.completed":
                    usage = ev.get("usage", {})
                elif t in ("item.completed", "item.started"):
                    self._handle_item(ev.get("item", {}), t, messages, files, cmds, on_progress)

        reader = asyncio.create_task(read_lines())
        stall_s = task.extra.get("stall_s", 720)
        try:
            while not reader.done():
                await asyncio.wait({reader}, timeout=2.0)
                if should_cancel and await should_cancel():
                    terminal.kill_tree(proc.pid)
                    reader.cancel()
                    return WorkerResult(False, failure=FailureKind.CANCELLED, error="cancelled",
                                        output="\n".join(messages)[-8000:])
                if time.monotonic() - last_activity > stall_s:
                    terminal.kill_tree(proc.pid)
                    reader.cancel()
                    return WorkerResult(False, failure=FailureKind.STALLED,
                                        error="no output past stall timeout",
                                        output="\n".join(messages)[-8000:],
                                        files_changed=sorted(files), ran_commands=cmds)
            await asyncio.wait_for(proc.wait(), timeout=60)
        except asyncio.TimeoutError:
            terminal.kill_tree(proc.pid)
            return WorkerResult(False, failure=FailureKind.STALLED, error="exceeded step timeout",
                                output="\n".join(messages)[-8000:], files_changed=sorted(files))
        finally:
            if not reader.done():
                reader.cancel()
            else:
                # Retrieve parser exceptions so they never become an unhandled
                # background-task warning and can be diagnosed by the worker.
                try:
                    reader.result()
                except Exception as e:
                    if proc.returncode is None:
                        terminal.kill_tree(proc.pid)
                    return WorkerResult(False, failure=FailureKind.TRANSIENT,
                                        error=f"codex output parser failed: {e}",
                                        output="\n".join(messages)[-8000:],
                                        files_changed=sorted(files), ran_commands=cmds)
            if proc.returncode is None:
                terminal.kill_tree(proc.pid)

        stderr = (await stderr_task).decode("utf-8", errors="replace")
        transcript = "\n".join(messages).strip()
        result = WorkerResult(True, output=transcript[-16000:], files_changed=sorted(files),
                              ran_commands=cmds, usage=usage, session_id=session_id,
                              summary=(messages[-1].strip()[:400] if messages else ""))

        if proc.returncode != 0:
            diagnostic = (stderr.strip() or transcript.strip() or
                          f"codex exited {proc.returncode}")
            return WorkerResult(False, failure=classify_output(diagnostic),
                                error=diagnostic[:1000],
                                output=(transcript + "\n" + stderr)[-8000:],
                                files_changed=sorted(files), ran_commands=cmds)
        low = (transcript + " " + stderr).lower()
        kind = classify_output(low)
        if kind == FailureKind.AUTH:
            return WorkerResult(False, failure=FailureKind.AUTH, error="codex not logged in",
                                output=result.output)
        if kind == FailureKind.RATE_LIMIT and not files:
            return WorkerResult(False, failure=FailureKind.RATE_LIMIT,
                                error="provider rate/usage limit", output=result.output)
        if task.read_only:
            result.verdict = self._parse_verdict(transcript)
        return result

    def _handle_item(self, item: dict, phase: str, messages: list, files: set, cmds: list,
                     on_progress: ProgressCb):
        it = item.get("type")
        if it == "agent_message" and phase == "item.completed":
            txt = item.get("text", "").strip()
            if txt:
                messages.append(txt)
                on_progress("assistant", txt[:500])
        elif it == "command_execution" and phase == "item.started":
            cmd = item.get("command", "")
            if cmd:
                cmds.append(cmd[:300])
                on_progress("bash", cmd[:200])
        elif it == "file_change" and phase == "item.completed":
            for ch in item.get("changes", []):
                if ch.get("path"):
                    files.add(ch["path"])
                    on_progress("edit", f"{ch.get('kind', 'change')} {ch['path']}")

    @staticmethod
    def _parse_verdict(transcript: str) -> dict:
        low = transcript.lower()
        idx = low.rfind("verdict:")
        passed = True
        if idx != -1:
            passed = "pass" in low[idx:idx + 40] and "fail" not in low[idx:idx + 40]
        issues = [l.strip("-*• \t") for l in transcript.splitlines()
                  if l.strip().startswith(("-", "*", "•")) and l.strip()][:30]
        return {"passed": passed, "issues": issues, "has_verdict": idx != -1}
