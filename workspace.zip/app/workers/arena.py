"""Arena.ai Agent worker (browser adapter).

Arena has no public/official API (api.arena.ai does not resolve; the help docs
describe only the web UI), so this is a browser-automation adapter behind the same
Worker interface — replaceable without touching the orchestrator if an API appears.

Because Arena runs in its own cloud sandbox and cannot touch local files, this worker:
  * read-only steps (review/edge_cases/investigate): sends the task + redacted code
    context, reads Arena's reply, parses a verdict/findings.
  * write steps (implement/fix): asks Arena to return each changed file as a fenced
    block tagged with its path; we parse those blocks, secret-scan them, and write
    them into the local worktree ourselves.

Login is performed once by the human in a visible window (see `arena-login`); the
session persists in a per-worker profile dir. We never type credentials or solve
CAPTCHAs — if a challenge appears, the worker fails cleanly and asks for a human.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import re
import time
import zipfile
from pathlib import Path
from urllib.parse import quote

import httpx

from ..config import ArenaSettings
from ..security.secrets import redact, scan
from ..tools import filesystem as fs
from ..tools.browser import BrowserOptions, BrowserSession, playwright_available
from .base import (Availability, CancelCheck, FailureKind, ProgressCb, Worker, WorkerResult,
                   WorkerTask)

log = logging.getLogger("leader.arena")

_FENCE_RE = re.compile(r"```([^\n]*)\n(.*?)```", re.S)
_PATH_IN_INFO_RE = re.compile(r"(?:path|file)\s*[=:]\s*([^\s`]+)", re.I)
_BARE_PATH_RE = re.compile(r"[\w./\\-]+\.\w{1,10}")
_BODY_PATH_RE = re.compile(r"^\s*(?:FILE|PATH)\s*:\s*([^\r\n]+)\s*(?:\r?\n|$)", re.I)
CHALLENGE_MARKERS = ["captcha", "verify you are human", "unusual traffic", "are you a robot",
                     "recaptcha", "cloudflare", "checking your browser"]
_UPLOAD_BLOCKED_PARTS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache"}
_UPLOAD_BLOCKED_NAMES = {".env", "secrets.env", "dashboard_token.txt", "credentials.json",
                         "id_rsa", "id_ed25519", "keypair.json"}
_UPLOAD_MAX_FILE_BYTES = 200_000
_UPLOAD_MAX_TOTAL_BYTES = 5_000_000


def _norm_path(p: str) -> str:
    p = p.strip().strip("`\"'*: ").replace("\\", "/")
    p = re.sub(r"/{2,}", "/", p)
    while p.startswith("./"):
        p = p[2:]
    return p


def _path_from_line(line: str) -> str | None:
    """Pull a file path out of a header line like '### File: foo.py' or '**bar.py**'."""
    s = line.strip().lstrip("#").strip()
    s = re.sub(r"(?i)^\**\s*file\s*[:=]\s*", "", s).strip().strip("`*: ")
    if _BARE_PATH_RE.fullmatch(s):
        return s
    m = _BARE_PATH_RE.search(s)
    # only trust an embedded token if the line is short (a header, not prose)
    return m.group(0) if m and len(s) < 80 else None


def parse_file_blocks(text: str) -> list[tuple[str, str]]:
    """Extract (relative_path, content) pairs from an Arena reply.

    Handles ```lang path=foo.py fences, bare ```foo.py fences, and a
    '### File: foo.py' / '**foo.py**' header line immediately before a fence.
    """
    out: dict[str, str] = {}
    for m in _FENCE_RE.finditer(text):
        info, body = m.group(1).strip(), m.group(2)
        path = None
        pm = _PATH_IN_INFO_RE.search(info)
        if pm:
            path = pm.group(1)
        elif _BARE_PATH_RE.fullmatch(info):        # ```src/app.py
            path = info
        else:
            for line in reversed([l for l in text[:m.start()].splitlines()[-3:] if l.strip()][-1:]):
                path = _path_from_line(line)
        # Browser-rendered Markdown normally drops the fence info string. Arena is
        # therefore also instructed to put `FILE: path` inside the code block; strip
        # that transport marker before writing the file.
        bm = _BODY_PATH_RE.match(body)
        if not path and bm:
            path = bm.group(1)
        if bm:
            body = body[bm.end():]
        if not path:
            continue
        np = _norm_path(path)
        if "." in np and np not in out:
            out[np] = body[:-1] if body.endswith("\n") else body
    return list(out.items())


def parse_verdict(text: str) -> dict:
    low = text.lower()
    idx = low.rfind("verdict:")
    passed = True
    if idx != -1:
        passed = "pass" in low[idx:idx + 40] and "fail" not in low[idx:idx + 40]
    issues = [l.strip("-*• \t") for l in text.splitlines()
              if l.strip().startswith(("-", "*", "•")) and l.strip()][:30]
    return {"passed": passed, "issues": issues, "has_verdict": idx != -1}


def looks_like_challenge(text: str) -> bool:
    low = text.lower()
    return any(m in low for m in CHALLENGE_MARKERS)


class ArenaWorker(Worker):
    provider = "arena"

    def __init__(self, settings: ArenaSettings, profile_dir: str, instance: int = 1):
        # Arena's strengths are research/review/analysis. Writing code via scraping is
        # unreliable, so it only advertises write capabilities when explicitly allowed.
        caps = ["execute_task", "review_code", "edge_cases", "debug", "inspect_project",
                "report_result"]
        if settings.allow_implement:
            caps += ["write_code", "edit_files", "create_files"]
        super().__init__(f"arena#{instance}", model="arena-agent",
                         capabilities=caps,
                         max_concurrency=1)  # one browser tab per Arena worker
        self.s = settings
        self.profile_dir = profile_dir
        self.instance = instance

    def _opts(self, headless: bool | None = None) -> BrowserOptions:
        return BrowserOptions(profile_dir=self.profile_dir,
                              headless=self.s.headless if headless is None else headless,
                              channel=self.s.browser_channel)

    async def health(self) -> tuple[Availability, str]:
        # Cheap check only (no browser): opening Arena's SPA per health tick would pop
        # a window every cycle. A saved session dir => optimistically READY; the real
        # login check happens in execute() (composer presence), which fails over on AUTH.
        if not self.s.enabled:
            return Availability.UNAVAILABLE, "disabled in config"
        if not playwright_available():
            return Availability.UNAVAILABLE, "playwright not installed"
        if not Path(self.profile_dir).exists() or not any(Path(self.profile_dir).iterdir()):
            return Availability.NEEDS_LOGIN, f"no saved session — run: arena-login --profile {self.instance}"
        return Availability.READY, "session saved"

    # ------------------------------------------------------------------ prompt
    def build_prompt(self, task: WorkerTask, github_url: str = "") -> str:
        parts: list[str] = []
        if task.kind == "research":
            parts.append("You are a research analyst. Research the question below thoroughly using "
                         "your web tools AND a DEEP GitHub scan: search GitHub for relevant "
                         "repositories, read their code/READMEs/issues, and explain how each "
                         "implements it (cite exact repo URLs + key files). Produce a well-structured "
                         "Markdown report: a short summary, detailed key findings, a 'GitHub "
                         "repositories' section, and a 'Sources' list of URLs. Cite sources. "
                         "Output only the report.")
            parts.append("\n## Question\n" + task.instruction)
            return redact("\n".join(parts))[: self.s.max_context_chars]
        if task.kind in ("review", "edge_cases"):
            parts.append("Review the code/change below. Do not rewrite everything; identify concrete "
                         "issues. End with 'VERDICT: PASS' or 'VERDICT: FAIL' and a bullet list.")
        else:
            parts.append("You are an expert engineer. Produce the code changes for the task below. "
                         "Return the FULL final content of every file you change or create, each in "
                         "its own fenced block. The FIRST LINE INSIDE every block must be "
                         "`FILE: <relative/path>` (this marker is required because the browser "
                         "removes Markdown fence metadata), e.g.\n"
                         "```python\nFILE: src/app.py\n<full file>\n```\n"
                         "Return only such file blocks plus a one-line summary. Do not use git.")
        if self.s.allow_sending_code:
            parts.append("A ZIP attachment may contain the current shared workspace snapshot. "
                         "Inspect it as the source of truth and build on the existing files; do not "
                         "start the project over. The inline context is a fallback if attachments "
                         "are unavailable.")
        if github_url:
            parts.append("The latest sanitized workspace snapshot is available at this GitHub "
                         f"link: {github_url} . Open/download workspace.zip and inspect it before "
                         "making changes. This link is newer than any inline snippet.")
        parts.append("\n## Task\n" + task.instruction)
        if task.context:
            parts.append("\n## Project context\n" + task.context)
        if self.s.allow_sending_code:
            snippet = self._workspace_snippet(task.workspace, task.instruction)
            if snippet:
                parts.append("\n## Current files\n" + snippet)
        prompt = "\n".join(parts)
        return redact(prompt)[: self.s.max_context_chars]

    def _workspace_snippet(self, workspace: str, instruction: str = "",
                           max_files: int = 12, max_bytes: int = 2600) -> str:
        files = [p for p in fs.list_files(workspace, max_files=200) if fs.is_text_file(p)]
        words = {w.lower() for w in re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", instruction)}

        def relevance(rel: str) -> tuple[int, str]:
            low = rel.lower()
            score = sum(1 for w in words if w in low)
            if Path(rel).name.lower() in ("readme.md", "pyproject.toml", "package.json",
                                         "requirements.txt"):
                score += 2
            return (-score, low)

        files.sort(key=relevance)
        out = ["### Complete workspace file manifest\n" + "\n".join(f"- {p}" for p in files)]
        for rel in files:
            try:
                content = fs.read_text(workspace, rel, max_bytes=max_bytes)
            except Exception:
                continue
            out.append(f"### {rel}\n```\n{content}\n```")
            if len(out) >= max_files + 1:
                break
        return "\n".join(out)

    def build_workspace_archive(self, workspace: str) -> tuple[Path, list[str], list[str]]:
        """Create a bounded, secret-filtered snapshot that Arena can inspect."""
        upload_dir = Path(self.profile_dir).parent / "uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        archive = upload_dir / f"arena-{self.instance}-workspace.zip"
        included: list[str] = []
        skipped: list[str] = []
        total = 0
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for rel in fs.list_files(workspace, max_files=500):
                parts = {part.lower() for part in Path(rel).parts}
                if (parts & _UPLOAD_BLOCKED_PARTS or Path(rel).name.lower() in _UPLOAD_BLOCKED_NAMES
                        or not fs.is_text_file(rel)):
                    skipped.append(rel)
                    continue
                try:
                    content = fs.read_text(workspace, rel, max_bytes=_UPLOAD_MAX_FILE_BYTES + 1)
                except Exception:
                    skipped.append(rel)
                    continue
                raw = content.encode("utf-8")
                if len(raw) > _UPLOAD_MAX_FILE_BYTES or total + len(raw) > _UPLOAD_MAX_TOTAL_BYTES:
                    skipped.append(rel)
                    continue
                if scan(content):
                    skipped.append(rel)
                    continue
                zf.writestr(rel.replace("\\", "/"), content)
                included.append(rel)
                total += len(raw)
            manifest = [
                "# Arena workspace handoff",
                "This archive is a current snapshot of the shared task workspace.",
                "Build on these files and return only complete files that must change.",
                "",
                "## Included files",
                *[f"- {p}" for p in included],
                "",
                "## Omitted by safety/size policy",
                *([f"- {p}" for p in skipped] or ["- none"]),
            ]
            zf.writestr("WORKSPACE_MANIFEST.md", "\n".join(manifest) + "\n")
        return archive, included, skipped

    async def _publish_workspace_github(self, task: WorkerTask, archive: Path,
                                        on_progress: ProgressCb) -> str:
        """Publish the safe archive through GitHub's API and return its folder URL."""
        if not self.s.github_handoff:
            return ""
        token = os.environ.get("GITHUB_HANDOFF_TOKEN", "").strip()
        if not token:
            on_progress("browser", "GitHub handoff not configured: add GITHUB_HANDOFF_TOKEN to secrets.env")
            return ""
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        async with httpx.AsyncClient(base_url="https://api.github.com", headers=headers,
                                     timeout=60, follow_redirects=True) as client:
            me = await client.get("/user")
            me.raise_for_status()
            login = me.json()["login"]
            configured = self.s.github_repo.strip().strip("/") or "ai-leader-handoffs"
            configured_owner = configured.split("/", 1)[0] if "/" in configured else login
            if self.s.github_repo_per_task:
                safe_prefix = re.sub(r"[^A-Za-z0-9_.-]+", "-",
                                     self.s.github_repo_prefix).strip("-.") or "ai-leader-task"
                full_repo = f"{configured_owner}/{safe_prefix}-{task.task_id}"
            else:
                full_repo = configured if "/" in configured else f"{login}/{configured}"
            owner, repo = full_repo.split("/", 1)
            repo_response = await client.get(f"/repos/{owner}/{repo}")
            per_task_repo = self.s.github_repo_per_task
            if repo_response.status_code == 404:
                if owner.lower() != login.lower():
                    raise RuntimeError(f"GitHub repository does not exist: {full_repo}")
                created = await client.post("/user/repos", json={
                    "name": repo,
                    "description": "Sanitized workspace handoffs for Ollama Leader agents",
                    "private": False,
                    "auto_init": True,
                })
                if created.status_code in (200, 201):
                    default_branch = created.json().get("default_branch", "main")
                elif self.s.github_repo_per_task:
                    # Fine-grained tokens may write selected repositories but not
                    # create new ones. Keep delivery working in the configured
                    # shared repository and make the fallback visible.
                    fallback = configured if "/" in configured else f"{login}/{configured}"
                    owner, repo = fallback.split("/", 1)
                    repo_response = await client.get(f"/repos/{owner}/{repo}")
                    repo_response.raise_for_status()
                    default_branch = repo_response.json().get("default_branch", "main")
                    per_task_repo = False
                    on_progress("browser", "GitHub could not create a task repository; "
                                f"using {fallback}/task-{task.task_id}")
                else:
                    created.raise_for_status()
            else:
                repo_response.raise_for_status()
                default_branch = repo_response.json().get("default_branch", "main")

            folder = "" if per_task_repo else f"task-{task.task_id}"
            remote_path = "workspace.zip" if not folder else f"{folder}/workspace.zip"
            endpoint = f"/repos/{owner}/{repo}/contents/{quote(remote_path, safe='/')}"
            current = await client.get(endpoint, params={"ref": default_branch})
            payload = {
                "message": f"handoff: task {task.task_id} step {task.step_id}",
                "content": base64.b64encode(archive.read_bytes()).decode("ascii"),
                "branch": default_branch,
            }
            if current.status_code == 200:
                payload["sha"] = current.json()["sha"]
            elif current.status_code != 404:
                current.raise_for_status()
            uploaded = await client.put(endpoint, json=payload)
            uploaded.raise_for_status()
            url = (f"https://github.com/{owner}/{repo}" if not folder else
                   f"https://github.com/{owner}/{repo}/tree/{default_branch}/{folder}")
            on_progress("browser", f"published current workspace to GitHub: {url}")
            return url

    async def _upload_workspace(self, page, workspace: str, on_progress: ProgressCb) -> bool:
        if not self.s.allow_sending_code:
            return False
        archive, included, skipped = self.build_workspace_archive(workspace)
        inputs = page.locator("input[type='file']")
        if await inputs.count() == 0:
            # Some Arena versions create the hidden file input only after the
            # attachment button is opened.
            for selector in ("button[aria-label*='attach' i]", "button[aria-label*='upload' i]",
                             "button[title*='attach' i]", "button[title*='upload' i]"):
                button = page.locator(selector)
                if await button.count():
                    try:
                        await button.first.click(timeout=5000)
                        await asyncio.sleep(0.5)
                        break
                    except Exception:
                        continue
            inputs = page.locator("input[type='file']")
            if await inputs.count() == 0:
                on_progress("browser", "Arena file upload unavailable; using embedded workspace context")
                return False
        try:
            await inputs.last.set_input_files(str(archive), timeout=30000)
            on_progress("browser", f"uploaded current workspace snapshot ({len(included)} files; "
                        f"{len(skipped)} safely omitted)")
            await asyncio.sleep(2)
            return True
        except Exception as e:
            log.info("Arena workspace upload unavailable, falling back to prompt context: %s", e)
            on_progress("browser", "Arena upload failed; using embedded workspace context")
            return False

    # ------------------------------------------------------------------ apply
    def apply_file_blocks(self, workspace: str, blocks: list[tuple[str, str]]) -> tuple[list[str], list[str]]:
        written, rejected = [], []
        for rel, content in blocks:
            if scan(content):
                rejected.append(f"{rel} (contains a possible secret)")
                continue
            try:
                p = fs.safe_path(workspace, rel)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
                written.append(rel)
            except Exception as e:
                rejected.append(f"{rel} ({e})")
        return written, rejected

    # ------------------------------------------------------------------ execute
    async def execute(self, task: WorkerTask, on_progress: ProgressCb,
                      should_cancel: CancelCheck | None = None) -> WorkerResult:
        if not playwright_available():
            return WorkerResult(False, failure=FailureKind.FATAL, error="playwright not installed")
        github_url = ""
        if self.s.allow_sending_code:
            try:
                archive, _, _ = self.build_workspace_archive(task.workspace)
                github_url = await self._publish_workspace_github(task, archive, on_progress)
            except Exception as e:
                log.warning("GitHub handoff failed: %s", e)
                on_progress("browser", f"GitHub handoff failed ({type(e).__name__}); using embedded context")
        prompt = self.build_prompt(task, github_url=github_url)
        deadline = time.monotonic() + self.s.response_timeout_min * 60
        try:
            async with BrowserSession(self._opts()) as bs:
                page = await bs.page()
                on_progress("browser", "opening arena")
                await page.goto(self.s.url, wait_until="domcontentloaded", timeout=60000)
                await asyncio.sleep(7)  # let the SPA hydrate
                body = (await page.inner_text("body"))[:8000]
                if looks_like_challenge(body):
                    return WorkerResult(False, failure=FailureKind.AUTH,
                                        error="bot-check present; a human must clear it via arena-login")
                # Login is determined by the composer's presence (Arena keeps a dismissable
                # "Connect your GitHub" promo even when logged in, so text markers lie).
                if await self._find_composer(page) is None:
                    return WorkerResult(False, failure=FailureKind.AUTH,
                                        error=f"arena#{self.instance} not logged in (no composer) — "
                                              f"run: arena-login --profile {self.instance}")
                # GitHub is preferred because Arena's upload input is not present
                # consistently. Direct upload remains the fallback.
                if not github_url:
                    await self._upload_workspace(page, task.workspace, on_progress)
                reply = await self._converse(page, prompt, deadline, on_progress, should_cancel)
        except asyncio.CancelledError:
            return WorkerResult(False, failure=FailureKind.CANCELLED, error="cancelled")
        except Exception as e:
            return WorkerResult(False, failure=FailureKind.FATAL, error=f"arena browser error: {e}")

        if reply is None:
            return WorkerResult(False, failure=FailureKind.STALLED, error="no response from Arena")
        reply = reply.strip()
        result = WorkerResult(True, output=reply[-16000:], summary=reply.splitlines()[-1][:300] if reply else "")
        if task.read_only:
            result.verdict = parse_verdict(reply)
            return result
        blocks = parse_file_blocks(reply)
        if not blocks:
            return WorkerResult(False, failure=FailureKind.FATAL,
                                error="Arena returned no file blocks to apply", output=reply[-8000:])
        written, rejected = self.apply_file_blocks(task.workspace, blocks)
        if not written:
            return WorkerResult(False, failure=FailureKind.FATAL,
                                error="no files applied: " + "; ".join(rejected), output=reply[-8000:])
        result.files_changed = written
        result.summary = f"applied {len(written)} file(s) from Arena" + (
            f"; rejected {len(rejected)}" if rejected else "")
        # Arena's returned files are now part of the local shared worktree. Publish
        # that updated state immediately so the repository never lags one Arena step.
        if self.s.github_handoff:
            try:
                updated_archive, _, _ = self.build_workspace_archive(task.workspace)
                updated_url = await self._publish_workspace_github(task, updated_archive, on_progress)
                if updated_url:
                    result.summary += f"; synced to {updated_url}"
            except Exception as e:
                log.warning("post-Arena GitHub sync failed: %s", e)
                on_progress("browser", f"post-Arena GitHub sync failed ({type(e).__name__})")
        return result

    async def _converse(self, page, prompt: str, deadline: float, on_progress: ProgressCb,
                        should_cancel: CancelCheck | None):
        composer = await self._find_composer(page)
        if composer is None:
            raise RuntimeError("could not find Arena's message input")
        before = await self._page_text(page)
        before_pre_count = await page.locator("pre").count()
        # IMPORTANT: newlines in a chat contenteditable submit the message early, so
        # the whole prompt must go in on ONE line, then a single Enter to send.
        oneline = " ".join(prompt.split())[:45000]
        await composer.click()
        # Playwright's fill() supports textarea, input and contenteditable and sets
        # long prompts atomically. Typing 45k characters with a per-key delay used
        # to exceed the default 30s timeout before Arena ever received the task.
        try:
            await composer.fill(oneline, timeout=60000)
        except Exception:
            await composer.click()
            await page.keyboard.press("Control+A")
            await page.keyboard.insert_text(oneline)
        on_progress("browser", "submitting task to arena")
        await asyncio.sleep(0.3)
        await page.keyboard.press("Enter")
        # Wait for the reply to appear and settle.
        last_text = before
        stable_since = None
        await asyncio.sleep(2)
        while time.monotonic() < deadline:
            if should_cancel and await should_cancel():
                raise asyncio.CancelledError()
            cur = await self._page_text(page)
            if cur != last_text and len(cur) > len(before) + 20:
                last_text = cur
                stable_since = time.monotonic()
                on_progress("browser", "arena responding…")
            elif stable_since and time.monotonic() - stable_since >= self.s.idle_settle_s:
                break
            await asyncio.sleep(1.5)
        # Prefer actual rendered <pre> blocks. `inner_text(body)` cannot preserve
        # Markdown backticks, so reconstruct fences from newly added code blocks.
        rendered_blocks = await self._rendered_code_blocks(page, before_pre_count)
        added = last_text[len(before):] if last_text.startswith(before) else last_text
        cleaned = self._clean_response(added or last_text, prompt)
        if rendered_blocks:
            cleaned = (cleaned + "\n\n" + rendered_blocks).strip()
        return cleaned

    async def _rendered_code_blocks(self, page, before_count: int) -> str:
        """Serialize code blocks added by Arena after submission back to Markdown.

        Arena renders Markdown before Playwright reads it, which removes the literal
        triple backticks. Keeping the `FILE:` line inside each block lets the normal
        parser recover the target path without depending on Arena's changing DOM.
        """
        blocks: list[str] = []
        pres = page.locator("pre")
        count = await pres.count()
        for i in range(before_count, count):
            try:
                body = (await pres.nth(i).inner_text()).strip("\r\n")
            except Exception:
                continue
            if body and _BODY_PATH_RE.match(body + "\n"):
                blocks.append(f"```\n{body}\n```")
        return "\n\n".join(blocks)

    _NOISE_LINES = {
        "agent", "workspace", "skip", "submit", "surprise me", "new", "connect",
        "i'll type my question", "use the free-text box below", "connect your github",
        "pick a current topic in the news", "dismiss github promotion", "stop", "regenerate",
        "all files that are created or uploaded in this session will be saved here",
        "what would you like to do?", "sources", "copy", "share",
    }

    def _clean_response(self, text: str, prompt: str) -> str:
        pfx = " ".join(prompt.split())[:60].lower()
        out: list[str] = []
        prev = None
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line == prev:
                continue
            low = line.lower()
            if low in self._NOISE_LINES:
                continue
            if low.startswith("you are a research analyst") or low.startswith(pfx):
                continue
            if low.startswith("thought for ") or low.startswith("## question") or low == "question":
                continue
            out.append(line)
            prev = line
        return "\n".join(out).strip()

    async def _find_composer(self, page):
        if self.s.composer_selector:
            el = await page.query_selector(self.s.composer_selector)
            if el:
                return el
        for sel in ["textarea", "[contenteditable='true']", "[role='textbox']",
                    "input[type='text']"]:
            el = await page.query_selector(sel)
            if el and await el.is_visible():
                return el
        return None

    async def _page_text(self, page) -> str:
        try:
            if self.s.response_selector:
                els = await page.query_selector_all(self.s.response_selector)
                if els:
                    return "\n".join([await e.inner_text() for e in els])
            return await page.inner_text("body")
        except Exception:
            return ""
