"""Secret detection and redaction.

Used before anything is written to memory, events, outgoing messages, or sent to
third-party workers, and to scan diffs before they are merged or pushed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# (name, regex, confidence). "high" findings in a diff gate merges via policy.
_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    ("private_key_pem", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|$)"), "high"),
    ("anthropic_key", re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{20,}"), "high"),
    ("openai_key", re.compile(r"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_\-]{32,}"), "high"),
    ("github_token", re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{22,})"), "high"),
    ("aws_access_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "high"),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), "high"),
    ("slack_token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}"), "high"),
    ("meta_token", re.compile(r"\b(?:EAA|IGAA|IGQV)[A-Za-z0-9]{40,}"), "high"),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"), "high"),
    ("solana_keypair_json", re.compile(r"\[\s*\d{1,3}(?:\s*,\s*\d{1,3}){63}\s*\]"), "high"),
    ("url_api_key", re.compile(r"(?i)([?&](?:api[-_]?key|apikey|token|access_token)=)[A-Za-z0-9\-_.]{12,}"), "high"),
    ("assigned_secret", re.compile(
        r"(?i)((?:api[_-]?key|secret|token|passw(?:or)?d|private[_-]?key|auth)[\"']?\s*[:=]\s*[\"']?)"
        r"([A-Za-z0-9_\-/+=.]{16,})"), "medium"),
    # 64-byte base58 strings: private keys, but also Solana tx signatures -> medium.
    ("base58_64", re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{86,90}\b"), "medium"),
]


@dataclass
class SecretFinding:
    kind: str
    confidence: str
    line: int
    preview: str


def redact(text: str | None) -> str:
    if not text:
        return text or ""
    out = text
    for name, rx, _ in _PATTERNS:
        if name in ("url_api_key", "assigned_secret"):
            out = rx.sub(lambda m: m.group(1) + f"[REDACTED:{name}]", out)
        else:
            out = rx.sub(f"[REDACTED:{name}]", out)
    return out


def scan(text: str) -> list[SecretFinding]:
    findings: list[SecretFinding] = []
    for name, rx, conf in _PATTERNS:
        for m in rx.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            s = m.group(0)
            findings.append(SecretFinding(name, conf, line, s[:6] + "…" if len(s) > 6 else "…"))
    return findings


def scan_added_lines(diff: str) -> list[SecretFinding]:
    """Scan only lines added by a unified diff."""
    added = "\n".join(l[1:] for l in diff.splitlines() if l.startswith("+") and not l.startswith("+++"))
    return scan(added)
