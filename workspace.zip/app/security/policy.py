"""Policy engine for high-risk actions: AUTO / CONFIRM / BLOCK.

Autonomy covers normal development work. Destructive or outward-facing actions
are classified here and gated. Enforcement points:
  * commands the orchestrator itself runs (verification, merge, push),
  * Claude Code workers (translated into --disallowedTools patterns),
  * post-hoc diff inspection before merge (bulk deletes, added secrets),
  * messaging (replies only go to allow-listed peers).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class Level(str, Enum):
    AUTO = "AUTO"
    CONFIRM = "CONFIRM"
    BLOCK = "BLOCK"


DEFAULT_RULES: dict[str, Level] = {
    # Local, reversible, and heavily guarded (verified + secret-scanned + clean tree +
    # no conflict), so autonomous by default. Remote/irreversible actions stay gated.
    "merge_to_base": Level.AUTO,
    "git_push": Level.CONFIRM,
    "git_force_push": Level.BLOCK,
    "deploy": Level.CONFIRM,
    "delete_repository": Level.BLOCK,
    "destructive_system": Level.BLOCK,
    "destroy_database": Level.BLOCK,
    "bulk_delete": Level.CONFIRM,
    "commit_secrets": Level.CONFIRM,
    "publish_credentials": Level.BLOCK,
    "mass_messages": Level.BLOCK,
    "financial": Level.BLOCK,
    "init_git_repo": Level.AUTO,
    "install_dependencies": Level.AUTO,
}

# Categories that MANUAL / ASSISTED modes escalate from AUTO to CONFIRM.
_ASSISTED_ESCALATE = {"merge_to_base", "init_git_repo", "git_push", "deploy"}

_I = re.IGNORECASE
COMMAND_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("git_force_push", re.compile(r"\bgit\s+push\b.*(?:--force\b|--force-with-lease|\s-f\b|\s\+\S)", _I)),
    ("git_push", re.compile(r"\bgit\s+push\b", _I)),
    ("deploy", re.compile(
        r"\b(?:(?:npm|pnpm|yarn)\s+publish|cargo\s+publish|docker\s+push|twine\s+upload|"
        r"solana\s+program\s+deploy|anchor\s+(?:deploy|upgrade)|kubectl\s+(?:apply|delete|rollout)|"
        r"terraform\s+(?:apply|destroy)|fly\s+deploy|vercel\b.*--prod|netlify\s+deploy|"
        r"gcloud\s+\S+\s+deploy|heroku\s+\S*\s*(?:deploy|push)|serverless\s+deploy)\b", _I)),
    ("financial", re.compile(
        r"\b(?:solana\s+(?:transfer|pay|withdraw-stake|delegate-stake)|spl-token\s+(?:transfer|withdraw|burn)|"
        r"cast\s+send|stripe\s+(?:charges|payouts|transfers)\b)", _I)),
    ("destroy_database", re.compile(
        r"\b(?:drop\s+(?:database|schema)|dropdb|flushall|flushdb|truncate\s+table)\b", _I)),
    ("delete_repository", re.compile(
        r"(?:\brm\s+-\w*r\w*\s+[^\n;&|]*\.git\b|\brmdir\s+/s\b[^\n;&|]*\.git\b|"
        r"Remove-Item\b[^\n;&|]*\.git\b[^\n;&|]*-Recurse|Remove-Item\b[^\n;&|]*-Recurse[^\n;&|]*\.git\b)", _I)),
    ("destructive_system", re.compile(
        r"(?:\brm\s+-\w*r\w*\s+(?:/|~|\$HOME|/\*|C:\\?)\s*(?:$|[;&|])|\bformat\s+[a-z]:|"
        r"\bmkfs\.|\bdd\s+if=.*\bof=/dev/|\bdiskpart\b|\bRemove-Item\b[^\n]*\b(?:C:\\\s|C:\\\*)|"
        r"\bshutdown\b|\breg\s+delete\b|\bbcdedit\b|\bcipher\s+/w)", _I)),
    ("bulk_delete", re.compile(
        r"(?:\brm\s+-\w*r|\brmdir\s+/s|\bdel\s+/s|\bRemove-Item\b[^\n]*-Recurse|\bgit\s+clean\s+-\w*f)", _I)),
]

CLAUDE_DISALLOWED = {
    "git_push": ["Bash(git push:*)"],
    "deploy": ["Bash(npm publish:*)", "Bash(pnpm publish:*)", "Bash(yarn publish:*)",
               "Bash(cargo publish:*)", "Bash(docker push:*)", "Bash(twine upload:*)",
               "Bash(solana program deploy:*)", "Bash(anchor deploy:*)", "Bash(anchor upgrade:*)",
               "Bash(kubectl apply:*)", "Bash(terraform apply:*)", "Bash(terraform destroy:*)",
               "Bash(vercel:*)", "Bash(fly deploy:*)"],
    "financial": ["Bash(solana transfer:*)", "Bash(solana pay:*)", "Bash(spl-token transfer:*)",
                  "Bash(spl-token withdraw:*)", "Bash(cast send:*)"],
    "destroy_database": ["Bash(dropdb:*)"],
    "delete_repository": ["Bash(rm -rf .git:*)", "Bash(rm -rf ./.git:*)"],
}


@dataclass
class Decision:
    level: Level
    categories: list[str] = field(default_factory=list)
    reason: str = ""

    @property
    def allowed(self) -> bool:
        return self.level == Level.AUTO


_ORDER = {Level.AUTO: 0, Level.CONFIRM: 1, Level.BLOCK: 2}


class PolicyEngine:
    def __init__(self, overrides: dict[str, str] | None = None, mode: str = "AUTONOMOUS",
                 bulk_delete_threshold: int = 25,
                 extra_patterns: dict[str, list[str]] | None = None):
        self.rules = dict(DEFAULT_RULES)
        for k, v in (overrides or {}).items():
            self.rules[k] = Level(v)
        self.mode = mode
        self.bulk_delete_threshold = bulk_delete_threshold
        self.patterns = list(COMMAND_PATTERNS)
        for cat, pats in (extra_patterns or {}).items():
            self.rules.setdefault(cat, Level.CONFIRM)
            for p in pats:
                self.patterns.append((cat, re.compile(p, _I)))

    def level(self, category: str) -> Level:
        lvl = self.rules.get(category, Level.CONFIRM)
        if lvl == Level.AUTO:
            if self.mode == "MANUAL":
                return Level.CONFIRM
            if self.mode == "ASSISTED" and category in _ASSISTED_ESCALATE:
                return Level.CONFIRM
        return lvl

    def classify_command(self, command: str) -> list[str]:
        cats: list[str] = []
        for cat, rx in self.patterns:
            if rx.search(command) and cat not in cats:
                cats.append(cat)
        if "git_force_push" in cats and "git_push" in cats:
            cats.remove("git_push")
        return cats

    def decide(self, categories: list[str], reason: str = "") -> Decision:
        if not categories:
            return Decision(Level.AUTO, [], reason)
        worst = max((self.level(c) for c in categories), key=lambda l: _ORDER[l])
        return Decision(worst, categories, reason or ", ".join(categories))

    def check_command(self, command: str) -> Decision:
        return self.decide(self.classify_command(command), f"command: {command[:200]}")

    def check_diff(self, deleted_files: int, secret_findings: list) -> Decision:
        cats = []
        if deleted_files >= self.bulk_delete_threshold:
            cats.append("bulk_delete")
        if any(f.confidence == "high" for f in secret_findings):
            cats.append("commit_secrets")
        return self.decide(cats, f"deleted_files={deleted_files}, secrets={len(secret_findings)}")

    def claude_disallowed_tools(self) -> list[str]:
        out: list[str] = list(CLAUDE_DISALLOWED["git_push"])  # workers never push; the leader does
        for cat, pats in CLAUDE_DISALLOWED.items():
            if self.level(cat) != Level.AUTO:
                out.extend(p for p in pats if p not in out)
        return out

    def worker_rules_text(self) -> str:
        blocked = sorted(c for c in self.rules if self.level(c) == Level.BLOCK)
        confirm = sorted(c for c in self.rules if self.level(c) == Level.CONFIRM)
        return ("Forbidden for you (the orchestrator enforces these): " + ", ".join(blocked) +
                ". Never do these without the leader (they need human confirmation): " +
                ", ".join(confirm) + ".")
