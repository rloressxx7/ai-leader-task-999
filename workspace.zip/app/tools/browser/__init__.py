"""Playwright browser helper for browser-driven workers (Arena).

Uses a PERSISTENT context per profile directory, so a human login (e.g. Google)
performed once is reused on every later run. We never type the user's password and
never attempt to solve CAPTCHAs/bot-checks — the human authenticates in the visible
window; automation only drives the app's own UI afterwards.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger("leader.browser")


def playwright_available() -> bool:
    import importlib.util
    return importlib.util.find_spec("playwright") is not None


@dataclass
class BrowserOptions:
    profile_dir: str
    headless: bool = False
    channel: str = "chrome"        # "chrome" uses installed Chrome; "" uses bundled chromium
    viewport_w: int = 1400
    viewport_h: int = 900
    slow_mo_ms: int = 0


class BrowserSession:
    """Async wrapper around a persistent Playwright context (one browser profile)."""

    def __init__(self, opts: BrowserOptions):
        self.opts = opts
        self._pw = None
        self._ctx = None

    async def __aenter__(self) -> "BrowserSession":
        from playwright.async_api import async_playwright
        Path(self.opts.profile_dir).mkdir(parents=True, exist_ok=True)
        self._pw = await async_playwright().start()
        launch_kwargs = dict(
            user_data_dir=self.opts.profile_dir,
            headless=self.opts.headless,
            viewport={"width": self.opts.viewport_w, "height": self.opts.viewport_h},
            args=["--disable-blink-features=AutomationControlled", "--no-first-run",
                  "--no-default-browser-check"],
        )
        if self.opts.slow_mo_ms:
            launch_kwargs["slow_mo"] = self.opts.slow_mo_ms
        # Prefer real Chrome; fall back to bundled chromium if the channel is missing.
        try:
            if self.opts.channel:
                launch_kwargs["channel"] = self.opts.channel
            self._ctx = await self._pw.chromium.launch_persistent_context(**launch_kwargs)
        except Exception as e:
            log.warning("chrome channel unavailable (%s); using bundled chromium", e)
            launch_kwargs.pop("channel", None)
            self._ctx = await self._pw.chromium.launch_persistent_context(**launch_kwargs)
        return self

    async def __aexit__(self, *exc) -> None:
        try:
            if self._ctx:
                await self._ctx.close()
        finally:
            if self._pw:
                await self._pw.stop()

    async def page(self):
        if self._ctx.pages:
            return self._ctx.pages[0]
        return await self._ctx.new_page()
