"""Tool registry: every tool reports real health from an actual probe.
Nothing is reported as available unless the probe succeeded."""
from __future__ import annotations

import asyncio
import importlib.util
import os
import re
import shutil
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import httpx

from ..config import Settings, discover_chrome, discover_git_bash
from . import terminal
from .computer import is_admin, screenshot_backend


@dataclass
class ToolStatus:
    name: str
    kind: str
    available: bool
    version: str = ""
    path: str = ""
    detail: str = ""
    checked_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)


def _first_version(text: str) -> str:
    m = re.search(r"\d+\.\d+(?:\.\d+)?(?:[-.\w]*)?", text)
    return m.group(0) if m else text.strip().splitlines()[0][:60] if text.strip() else ""


class Tool:
    name = "tool"
    kind = "generic"

    async def check(self) -> ToolStatus:
        raise NotImplementedError


class ProbeTool(Tool):
    """Probe an executable with a version command."""

    def __init__(self, name: str, kind: str, exe: str | None, args: list[str] | None = None,
                 timeout_s: float = 20):
        self.name, self.kind = name, kind
        self.exe = exe
        self.args = args if args is not None else ["--version"]
        self.timeout_s = timeout_s

    def resolve(self) -> str | None:
        if not self.exe:
            return None
        if os.path.isabs(self.exe):
            return self.exe if os.path.exists(self.exe) else None
        return shutil.which(self.exe)

    async def check(self) -> ToolStatus:
        path = self.resolve()
        if not path:
            return ToolStatus(self.name, self.kind, False, detail=f"{self.exe or self.name} not found")
        res = await terminal.run([path, *self.args], timeout_s=self.timeout_s)
        if res.ok:
            return ToolStatus(self.name, self.kind, True, _first_version(res.output), path)
        return ToolStatus(self.name, self.kind, False, path=path,
                          detail=f"probe failed (exit {res.exit_code}): {res.tail(300)}")


class DockerTool(ProbeTool):
    def __init__(self):
        super().__init__("docker", "container", "docker", ["version", "--format", "{{.Server.Version}}"])

    async def check(self) -> ToolStatus:
        st = await super().check()
        if not st.available and st.path:
            st.detail = "docker CLI present but daemon not reachable (is Docker Desktop running?)"
        return st


class WslTool(ProbeTool):
    def __init__(self):
        super().__init__("wsl", "shell", "wsl.exe" if sys.platform == "win32" else None, ["-l", "-q"])

    async def check(self) -> ToolStatus:
        path = self.resolve()
        if not path:
            return ToolStatus(self.name, self.kind, False, detail="wsl not present")
        res = await terminal.run([path, "-l", "-q"], timeout_s=20)
        # wsl -l prints UTF-16; strip NULs
        distros = [d.strip() for d in res.stdout.replace("\x00", "").splitlines() if d.strip()]
        if res.ok and distros:
            return ToolStatus(self.name, self.kind, True, "", path, "distros: " + ", ".join(distros))
        return ToolStatus(self.name, self.kind, False, path=path, detail="no WSL distribution installed")


class FilesystemTool(Tool):
    name, kind = "filesystem", "filesystem"

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir

    async def check(self) -> ToolStatus:
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            probe = self.data_dir / ".write_probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            usage = shutil.disk_usage(self.data_dir)
            return ToolStatus(self.name, self.kind, True, "", str(self.data_dir),
                              f"free {usage.free / 1e9:.1f} GB")
        except OSError as e:
            return ToolStatus(self.name, self.kind, False, detail=str(e))


class OllamaTool(Tool):
    name, kind = "ollama", "llm"

    def __init__(self, url: str, model: str):
        self.url, self.model = url.rstrip("/"), model

    async def check(self) -> ToolStatus:
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                v = (await c.get(f"{self.url}/api/version")).json().get("version", "")
                tags = (await c.get(f"{self.url}/api/tags")).json().get("models", [])
            names = [m.get("name") for m in tags]
            ok = self.model in names
            return ToolStatus(self.name, self.kind, ok, v, self.url,
                              f"leader model {self.model} {'present' if ok else 'MISSING'}; models: {len(names)}")
        except Exception as e:
            return ToolStatus(self.name, self.kind, False, detail=f"unreachable: {e}")


class BrowserTool(Tool):
    """Playwright-driven browser (used by the Arena adapter)."""
    name, kind = "browser", "browser"

    async def check(self) -> ToolStatus:
        if importlib.util.find_spec("playwright") is None:
            return ToolStatus(self.name, self.kind, False,
                              detail="playwright not installed (pip install playwright)")
        chrome = discover_chrome()
        if not chrome:
            return ToolStatus(self.name, self.kind, False, detail="no Chrome found for channel=chrome")
        return ToolStatus(self.name, self.kind, True, "", chrome, "playwright + installed Chrome")


class StaticTool(Tool):
    def __init__(self, name: str, kind: str, fn):
        self.name, self.kind, self.fn = name, kind, fn

    async def check(self) -> ToolStatus:
        ok, detail = self.fn()
        return ToolStatus(self.name, self.kind, ok, detail=detail)


class ToolRegistry:
    def __init__(self, settings: Settings):
        win = sys.platform == "win32"
        self.tools: dict[str, Tool] = {}
        for t in [
            FilesystemTool(settings.data_path),
            ProbeTool("powershell", "shell", "powershell.exe" if win else "pwsh",
                      ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"]),
            ProbeTool("cmd", "shell", "cmd.exe" if win else None, ["/c", "ver"]),
            ProbeTool("bash", "shell", discover_git_bash(), ["--version"]),
            WslTool(),
            ProbeTool("git", "vcs", "git"),
            ProbeTool("github", "vcs", "gh"),
            ProbeTool("python", "runtime", sys.executable if not win else "python"),
            ProbeTool("node", "runtime", "node"),
            ProbeTool("npm", "runtime", "npm.cmd" if win else "npm"),
            ProbeTool("rust", "runtime", "cargo"),
            ProbeTool("go", "runtime", "go", ["version"]),
            DockerTool(),
            OllamaTool(settings.leader.ollama_url, settings.leader.model),
            BrowserTool(),
            ProbeTool("chrome", "browser", discover_chrome(), None, 5),
            StaticTool("screenshots", "computer",
                       lambda: (screenshot_backend() is not None, screenshot_backend() or "Pillow not installed")),
            StaticTool("process_manager", "computer",
                       lambda: (True, "taskkill/tasklist" if win else "signals/procfs")),
            StaticTool("elevation", "computer",
                       lambda: (True, "running elevated" if is_admin() else "running as normal user")),
        ]:
            self.tools[t.name] = t
        # chrome.exe has no --version on Windows; existence is the probe
        if win and discover_chrome():
            self.tools["chrome"] = StaticTool("chrome", "browser", lambda: (True, discover_chrome()))
        self.status: dict[str, ToolStatus] = {}

    async def check_all(self) -> dict[str, ToolStatus]:
        names = list(self.tools)
        results = await asyncio.gather(*(self.tools[n].check() for n in names), return_exceptions=True)
        for n, r in zip(names, results):
            if isinstance(r, Exception):
                r = ToolStatus(n, self.tools[n].kind, False, detail=f"probe error: {r}")
            self.status[n] = r
        return self.status

    def available(self, name: str) -> bool:
        st = self.status.get(name)
        return bool(st and st.available)

    def summary_for_llm(self) -> str:
        parts = []
        for n, st in sorted(self.status.items()):
            parts.append(f"{n}: {'ok ' + st.version if st.available else 'UNAVAILABLE'}")
        return "; ".join(parts)
