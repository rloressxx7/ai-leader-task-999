"""Computer-level facts: elevation, processes, screenshots (when a backend exists)."""
from __future__ import annotations

import ctypes
import os
import sys


def is_admin() -> bool:
    """True if this process runs elevated (Windows) or as root (POSIX)."""
    try:
        if sys.platform == "win32":
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def screenshot_backend() -> str | None:
    try:
        from PIL import ImageGrab  # noqa: F401
        return "PIL.ImageGrab"
    except Exception:
        return None


def take_screenshot(path: str) -> str:
    from PIL import ImageGrab  # raises ImportError if unavailable; callers check health first
    img = ImageGrab.grab(all_screens=True)
    img.save(path)
    return path
