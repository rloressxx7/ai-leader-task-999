"""Terminal execution: PowerShell, cmd, Git Bash, WSL, or a raw argv.

Every child runs in its own process group so the whole tree can be killed on
timeout, cancellation or emergency stop.
"""
from __future__ import annotations

import asyncio
import base64
import os
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from ...config import discover_git_bash

IS_WINDOWS = sys.platform == "win32"
CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200


def popen_kwargs() -> dict:
    if IS_WINDOWS:
        return {"creationflags": CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def kill_tree(pid: int) -> bool:
    """Kill a process and all its descendants. Returns True if something was killed."""
    if not pid:
        return False
    try:
        if IS_WINDOWS:
            r = subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True,
                               creationflags=CREATE_NO_WINDOW, timeout=30)
            return r.returncode == 0
        os.killpg(os.getpgid(pid), signal.SIGKILL)
        return True
    except (ProcessLookupError, PermissionError, subprocess.TimeoutExpired, OSError):
        return False


def process_image(pid: int) -> str | None:
    """Executable name of a live pid (used to avoid killing a recycled pid)."""
    try:
        if IS_WINDOWS:
            r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                               capture_output=True, text=True, creationflags=CREATE_NO_WINDOW, timeout=15)
            line = r.stdout.strip().splitlines()[0] if r.stdout.strip() else ""
            if line.startswith('"'):
                return line.split('","')[0].strip('"')
            return None
        with open(f"/proc/{pid}/comm") as f:
            return f.read().strip()
    except Exception:
        return None


@dataclass
class CommandResult:
    command: str
    exit_code: int | None
    stdout: str = ""
    stderr: str = ""
    duration_s: float = 0.0
    timed_out: bool = False
    cancelled: bool = False
    extra: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out and not self.cancelled

    @property
    def output(self) -> str:
        return (self.stdout + ("\n" + self.stderr if self.stderr else "")).strip()

    def tail(self, n: int = 4000) -> str:
        o = self.output
        return o[-n:] if len(o) > n else o


def _decode(b: bytes | None) -> str:
    if not b:
        return ""
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("utf-8", errors="replace")


def build_argv(command: str, shell: str | None) -> tuple[list[str] | str, bool]:
    """Return (argv_or_cmdline, use_shell)."""
    shell = shell or ("cmd" if IS_WINDOWS else "bash")
    if shell == "cmd":
        return (command, True) if IS_WINDOWS else (["bash", "-lc", command], False)
    if shell == "powershell":
        enc = base64.b64encode(command.encode("utf-16-le")).decode()
        exe = "powershell.exe" if IS_WINDOWS else "pwsh"
        return ([exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                 "-EncodedCommand", enc], False)
    if shell == "bash":
        bash = discover_git_bash() or "bash"
        return ([bash, "-lc", command], False)
    if shell == "wsl":
        return (["wsl.exe", "-e", "bash", "-lc", command], False)
    raise ValueError(f"unknown shell {shell}")


async def run(command: str | list[str], *, cwd: str | Path | None = None, shell: str | None = None,
              env: dict | None = None, timeout_s: float = 600, stdin_text: str | None = None,
              max_output: int = 400_000) -> CommandResult:
    """Run a command to completion (or timeout) and capture its output."""
    started = time.monotonic()
    if isinstance(command, list):
        argv, use_shell, shown = command, False, subprocess.list2cmdline(command)
    else:
        argv, use_shell = build_argv(command, shell)
        shown = command
    kwargs = dict(cwd=str(cwd) if cwd else None, env=env, stdin=asyncio.subprocess.PIPE,
                  stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, **popen_kwargs())
    try:
        if use_shell:
            proc = await asyncio.create_subprocess_shell(argv, **kwargs)
        else:
            proc = await asyncio.create_subprocess_exec(*argv, **kwargs)
    except (FileNotFoundError, NotADirectoryError, PermissionError) as e:
        return CommandResult(shown, None, "", f"failed to start: {e}", time.monotonic() - started)
    data = stdin_text.encode("utf-8") if stdin_text is not None else None
    try:
        out, err = await asyncio.wait_for(proc.communicate(data), timeout=timeout_s)
        res = CommandResult(shown, proc.returncode, _decode(out), _decode(err))
    except asyncio.TimeoutError:
        kill_tree(proc.pid)
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=15)
        except Exception:
            out, err = b"", b""
        res = CommandResult(shown, proc.returncode, _decode(out), _decode(err), timed_out=True)
    except asyncio.CancelledError:
        kill_tree(proc.pid)
        raise
    res.duration_s = time.monotonic() - started
    if len(res.stdout) > max_output:
        res.stdout = "…[truncated]…\n" + res.stdout[-max_output:]
    if len(res.stderr) > max_output:
        res.stderr = "…[truncated]…\n" + res.stderr[-max_output:]
    return res
