"""Screenshot a local HTML file or a URL via headless Chromium (Playwright).

Used to send visual deliverables (a built web page, a game, a chart) to Telegram so
the user can see results from their phone.
"""
from __future__ import annotations

import logging
from pathlib import Path

from .browser import playwright_available

log = logging.getLogger("leader.screenshot")

VIEWABLE = {".html", ".htm", ".svg"}


def find_viewable(workspace: str, result_text: str = "") -> str | None:
    """Pick a viewable artifact in a workspace (prefer one named in the result)."""
    root = Path(workspace)
    if not root.exists():
        return None
    # Prefer a file explicitly named in the result text.
    for token in (result_text or "").replace("[", " ").replace("]", " ").split():
        if token.lower().endswith(tuple(VIEWABLE)):
            cand = root / Path(token).name
            if cand.exists():
                return str(cand)
    for name in ("index.html", "index.htm", "main.html"):
        if (root / name).exists():
            return str(root / name)
    cands = [p for ext in VIEWABLE for p in root.rglob(f"*{ext}")]
    cands = [p for p in cands if ".git" not in p.parts and "node_modules" not in p.parts]
    return str(max(cands, key=lambda p: p.stat().st_mtime)) if cands else None


async def capture(target: str, out_path: str, *, width: int = 1280, height: int = 800,
                  full_page: bool = True, timeout_ms: int = 20000) -> str | None:
    """Screenshot a file path or URL to out_path (PNG). Returns the path or None."""
    if not playwright_available():
        log.warning("screenshot: playwright not installed")
        return None
    url = target
    if not target.startswith(("http://", "https://", "file://")):
        p = Path(target)
        if not p.exists():
            return None
        url = p.resolve().as_uri()
    try:
        from playwright.async_api import async_playwright
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            try:
                page = await browser.new_page(viewport={"width": width, "height": height})
                await page.goto(url, wait_until="load", timeout=timeout_ms)
                await page.wait_for_timeout(900)  # let JS/canvas render
                await page.screenshot(path=out_path, full_page=full_page)
            finally:
                await browser.close()
        return out_path if Path(out_path).exists() else None
    except Exception as e:
        log.warning("screenshot failed for %s: %s", target, e)
        return None
