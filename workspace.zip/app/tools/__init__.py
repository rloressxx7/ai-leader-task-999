"""Tool layer: terminal, git, filesystem, browser, computer — each with real health probes."""
