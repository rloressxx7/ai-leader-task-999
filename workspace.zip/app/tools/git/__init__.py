"""Git operations: repository detection, isolated worktrees, checkpoints, diffs,
recovery and a conservative merge back into the user's branch."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from .. import terminal
from ..terminal import CommandResult

IDENTITY = ["-c", "user.name=Ollama Leader", "-c", "user.email=leader@localhost"]

# Written to .git/info/exclude (never to the user's .gitignore) when the leader
# has to initialise a repository for a project that had none.
DEFAULT_EXCLUDES = [
    "# added by ollama-leader", "target/", "node_modules/", ".venv/", "venv/", "__pycache__/",
    "dist/", "build/", ".next/", "*.log", ".env", ".env.*", "*.pem", "*.key", "*keypair*.json",
    "id.json", "wallet*.json", "secrets.*", "*.sqlite", "*.db",
]


class GitError(RuntimeError):
    def __init__(self, message: str, result: CommandResult | None = None):
        super().__init__(message)
        self.result = result


def _norm(p: str | Path) -> str:
    return os.path.normcase(os.path.realpath(str(p)))


def is_within(path: str | Path, root: str | Path) -> bool:
    p, r = _norm(path), _norm(root)
    return p == r or p.startswith(r.rstrip("\\/") + os.sep)


@dataclass
class Change:
    status: str  # A, M, D, R...
    path: str


class Git:
    def __init__(self, exe: str = "git", timeout_s: float = 300):
        self.exe = exe
        self.timeout_s = timeout_s

    async def run(self, cwd: str | Path, *args: str, check: bool = True,
                  timeout_s: float | None = None) -> CommandResult:
        env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
        res = await terminal.run([self.exe, *args], cwd=cwd, env=env,
                                 timeout_s=timeout_s or self.timeout_s)
        if check and not res.ok:
            raise GitError(f"git {' '.join(args[:3])} failed: {res.tail(1500)}", res)
        return res

    # ----------------------------------------------------------------- inspection
    async def toplevel(self, path: str | Path) -> Path | None:
        res = await self.run(path, "rev-parse", "--show-toplevel", check=False)
        return Path(res.stdout.strip()) if res.ok and res.stdout.strip() else None

    async def is_own_repo(self, path: str | Path) -> bool:
        """True only if ``path`` is the root of its repository (a project nested in
        some parent repo, e.g. a home directory under git, does not count)."""
        top = await self.toplevel(path)
        return top is not None and _norm(top) == _norm(path)

    async def head(self, path: str | Path) -> str | None:
        res = await self.run(path, "rev-parse", "--verify", "-q", "HEAD", check=False)
        return res.stdout.strip() or None if res.ok else None

    async def current_branch(self, path: str | Path) -> str | None:
        res = await self.run(path, "symbolic-ref", "--short", "-q", "HEAD", check=False)
        return res.stdout.strip() or None if res.ok else None

    async def status(self, path: str | Path) -> list[Change]:
        res = await self.run(path, "status", "--porcelain=v1", "--untracked-files=all")
        out = []
        for line in res.stdout.splitlines():
            if len(line) > 3:
                out.append(Change(line[:2].strip() or "?", line[3:].strip().strip('"')))
        return out

    async def is_dirty(self, path: str | Path, include_untracked: bool = True) -> bool:
        args = ["status", "--porcelain=v1"] + ([] if include_untracked else ["--untracked-files=no"])
        res = await self.run(path, *args)
        return bool(res.stdout.strip())

    async def stash_create(self, path: str | Path) -> str | None:
        """Commit object capturing uncommitted tracked changes, without touching
        the user's working tree or stash list."""
        res = await self.run(path, "stash", "create", check=False)
        return res.stdout.strip() or None if res.ok else None

    async def branch_exists(self, repo: str | Path, branch: str) -> bool:
        res = await self.run(repo, "rev-parse", "--verify", "-q", f"refs/heads/{branch}", check=False)
        return res.ok and bool(res.stdout.strip())

    async def is_ancestor(self, repo: str | Path, a: str, b: str) -> bool:
        res = await self.run(repo, "merge-base", "--is-ancestor", a, b, check=False)
        return res.exit_code == 0

    async def log(self, path: str | Path, n: int = 10, ref: str = "HEAD") -> list[str]:
        res = await self.run(path, "log", f"-{n}", "--pretty=%h %s", ref, check=False)
        return res.stdout.splitlines() if res.ok else []

    # ----------------------------------------------------------------- repo setup
    async def init_repo(self, path: str | Path, max_file_mb: float = 5.0) -> str:
        path = Path(path)
        await self.run(path, "init", "-q")
        excludes = list(DEFAULT_EXCLUDES)
        limit = max_file_mb * 1024 * 1024
        skip_dirs = {"target", "node_modules", ".venv", "venv", ".git", "__pycache__", "dist", "build"}
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for f in files:
                fp = Path(root) / f
                try:
                    if fp.stat().st_size > limit:
                        excludes.append("/" + fp.relative_to(path).as_posix())
                except OSError:
                    pass
        info = path / ".git" / "info"
        info.mkdir(parents=True, exist_ok=True)
        (info / "exclude").write_text("\n".join(excludes) + "\n", encoding="utf-8")
        await self.run(path, "add", "-A")
        await self.run(path, *IDENTITY, "commit", "-q", "--allow-empty", "-m",
                       "leader: baseline snapshot")
        return (await self.head(path)) or ""

    # ----------------------------------------------------------------- worktrees
    async def worktree_add(self, repo: str | Path, path: str | Path, branch: str, base: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        await self.run(repo, "worktree", "prune", check=False)
        if await self.branch_exists(repo, branch):
            await self.run(repo, "worktree", "add", "-f", str(path), branch)
        else:
            await self.run(repo, "worktree", "add", "-f", "-b", branch, str(path), base)

    async def worktree_remove(self, repo: str | Path, path: str | Path) -> None:
        await self.run(repo, "worktree", "remove", "--force", str(path), check=False)
        await self.run(repo, "worktree", "prune", check=False)

    async def is_valid_worktree(self, path: str | Path, branch: str | None = None) -> bool:
        p = Path(path)
        if not (p / ".git").exists():
            return False
        if branch:
            return (await self.current_branch(p)) == branch
        return (await self.head(p)) is not None

    # ----------------------------------------------------------------- checkpoints
    async def checkpoint(self, path: str | Path, message: str) -> str | None:
        """Commit everything in the worktree. Returns the new sha, or None if clean."""
        await self.run(path, "add", "-A")
        staged = await self.run(path, "diff", "--cached", "--quiet", check=False)
        if staged.exit_code == 0:
            return None
        await self.run(path, *IDENTITY, "commit", "-q", "-m", message)
        return await self.head(path)

    async def changes_between(self, path: str | Path, a: str, b: str = "HEAD") -> list[Change]:
        res = await self.run(path, "diff", "--name-status", "--no-renames", a, b)
        out = []
        for line in res.stdout.splitlines():
            parts = line.split("\t", 1)
            if len(parts) == 2:
                out.append(Change(parts[0][:1], parts[1]))
        return out

    async def diff(self, path: str | Path, a: str, b: str = "HEAD", max_chars: int = 60_000) -> str:
        res = await self.run(path, "diff", "--no-color", a, b, check=False)
        d = res.stdout
        return d if len(d) <= max_chars else d[:max_chars] + "\n…[diff truncated]…"

    async def diff_stat(self, path: str | Path, a: str, b: str = "HEAD") -> str:
        res = await self.run(path, "diff", "--stat", a, b, check=False)
        return res.stdout.strip()

    async def reset_hard(self, path: str | Path, sha: str, allowed_root: str | Path) -> None:
        """Hard reset — only ever inside a leader-owned worktree."""
        if not is_within(path, allowed_root):
            raise GitError(f"refusing to reset {path}: not inside {allowed_root}")
        await self.run(path, "reset", "-q", "--hard", sha)
        await self.run(path, "clean", "-q", "-fd")

    async def apply_patch(self, path: str | Path, patch: str) -> CommandResult:
        res = await terminal.run([self.exe, "apply", "--3way", "--whitespace=nowarn", "-"],
                                 cwd=path, stdin_text=patch, timeout_s=120)
        if not res.ok:
            res = await terminal.run([self.exe, "apply", "--whitespace=nowarn", "--recount", "-"],
                                     cwd=path, stdin_text=patch, timeout_s=120)
        return res

    # ----------------------------------------------------------------- merge back
    async def merge_into_current(self, repo: str | Path, branch: str, message: str) -> tuple[bool, str]:
        """Merge ``branch`` into the repo's checked-out branch, only if that tree
        has no uncommitted tracked changes. Aborts cleanly on conflict."""
        if await self.is_dirty(repo, include_untracked=False):
            return False, "working tree has uncommitted changes; merge it manually"
        cur = await self.current_branch(repo)
        if not cur:
            return False, "repository is in detached HEAD state"
        res = await self.run(repo, *IDENTITY, "merge", "--no-ff", "--no-edit", "-m", message, branch,
                             check=False)
        if not res.ok:
            await self.run(repo, "merge", "--abort", check=False)
            return False, f"merge conflict, aborted: {res.tail(800)}"
        return True, f"merged {branch} into {cur}"
