"""Filesystem helpers with containment checks (used for context building and inspection)."""
from __future__ import annotations

import os
from pathlib import Path

from ..git import is_within

TEXT_EXT = {".py", ".rs", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".go", ".java", ".kt",
            ".c", ".h", ".cpp", ".hpp", ".cs", ".rb", ".php", ".swift", ".sql", ".sh", ".ps1",
            ".toml", ".yaml", ".yml", ".json", ".md", ".txt", ".html", ".css", ".scss", ".vue",
            ".svelte", ".ini", ".cfg", ".proto", ".graphql", ".gradle"}
SKIP_DIRS = {".git", "node_modules", "target", ".venv", "venv", "__pycache__", "dist", "build",
             ".next", ".idea", ".vscode", ".pytest_cache", ".mypy_cache"}


class PathOutsideWorkspace(PermissionError):
    pass


def safe_path(root: str | Path, rel: str) -> Path:
    p = (Path(root) / rel).resolve()
    if not is_within(p, root):
        raise PathOutsideWorkspace(f"{rel} escapes {root}")
    return p


def read_text(root: str | Path, rel: str, max_bytes: int = 200_000) -> str:
    p = safe_path(root, rel)
    return p.read_bytes()[:max_bytes].decode("utf-8", errors="replace")


def list_files(root: str | Path, max_files: int = 5000) -> list[str]:
    """Relative paths of files, skipping vendored/build/hidden directories."""
    root = Path(root)
    out: list[str] = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
        for f in sorted(files):
            out.append((Path(dirpath) / f).relative_to(root).as_posix())
            if len(out) >= max_files:
                return out
    return out


def tree_summary(root: str | Path, max_lines: int = 200) -> str:
    files = list_files(root, max_files=max_lines)
    return "\n".join(files) + ("\n…" if len(files) >= max_lines else "")


def is_text_file(path: str) -> bool:
    p = Path(path)
    return p.suffix.lower() in TEXT_EXT or p.name in {"Dockerfile", "Makefile", "README", "LICENSE"}
