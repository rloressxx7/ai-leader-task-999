"""UTF-8-safe structured logging (Windows consoles are often cp125x and choke on emoji)."""
from __future__ import annotations

import logging
import sys
from pathlib import Path


class SafeStreamHandler(logging.StreamHandler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            super().emit(record)
        except UnicodeEncodeError:
            try:
                msg = self.format(record)
                enc = getattr(self.stream, "encoding", "utf-8") or "utf-8"
                self.stream.write(msg.encode(enc, "replace").decode(enc) + self.terminator)
                self.flush()
            except Exception:
                self.handleError(record)


def setup_logging(logfile: Path | None = None, level: int = logging.INFO) -> None:
    root = logging.getLogger()
    if root.handlers:
        return
    root.setLevel(level)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%H:%M:%S")

    # Try to switch stdout/stderr to UTF-8 (Python 3.7+).
    for stream in (sys.stdout, sys.stderr):
        with_reconfig = getattr(stream, "reconfigure", None)
        if with_reconfig:
            try:
                with_reconfig(encoding="utf-8", errors="replace")
            except Exception:
                pass

    sh = SafeStreamHandler(sys.stderr)
    sh.setFormatter(fmt)
    root.addHandler(sh)

    if logfile:
        logfile.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(logfile, encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
