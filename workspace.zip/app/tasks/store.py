from __future__ import annotations

import json
import time
from typing import Any, Iterable

from ..database import Database
from .models import (ACTIVE_STATUSES, READ_ONLY_KINDS, InvalidTransition, StepKind,
                     StepStatus, TaskStatus, can_transition)

_TASK_JSON = {"plan_json", "flags_json", "tests_json", "errors_json"}
_STEP_JSON = {"tried_json", "verdict_json"}


def _decode(row: dict | None, json_cols: set[str]) -> dict | None:
    if row is None:
        return None
    for c in json_cols:
        if c in row:
            row[c[:-5]] = json.loads(row[c]) if row[c] else None
    return row


class TaskStore:
    def __init__(self, db: Database):
        self.db = db

    # ------------------------------------------------------------------ tasks
    def create_task(self, user_request: str, *, source: str | None = None, priority: int = 5,
                    project_id: int | None = None, status: TaskStatus = TaskStatus.QUEUED) -> int:
        now = time.time()
        return self.db.execute(
            "INSERT INTO tasks(user_request,status,priority,source,project_id,created_at,updated_at,"
            "flags_json,errors_json) VALUES(?,?,?,?,?,?,?,?,?)",
            (user_request, status.value, priority, source, project_id, now, now, "{}", "[]"))

    def get(self, task_id: int) -> dict | None:
        return _decode(self.db.query_one("SELECT * FROM tasks WHERE id=?", (task_id,)), _TASK_JSON)

    def list(self, statuses: Iterable[TaskStatus] | None = None, limit: int = 200) -> list[dict]:
        if statuses:
            vals = [s.value for s in statuses]
            q = f"SELECT * FROM tasks WHERE status IN ({','.join('?' * len(vals))}) " \
                "ORDER BY priority ASC, id ASC LIMIT ?"
            rows = self.db.query(q, (*vals, limit))
        else:
            rows = self.db.query("SELECT * FROM tasks ORDER BY id DESC LIMIT ?", (limit,))
        return [_decode(r, _TASK_JSON) for r in rows]

    def update(self, task_id: int, **fields: Any) -> None:
        if not fields:
            return
        for k in list(fields):
            if k + "_json" in _TASK_JSON:
                fields[k + "_json"] = json.dumps(fields.pop(k))
        fields["updated_at"] = time.time()
        cols = ",".join(f"{k}=?" for k in fields)
        self.db.execute(f"UPDATE tasks SET {cols} WHERE id=?", (*fields.values(), task_id))

    def set_status(self, task_id: int, status: TaskStatus, reason: str | None = None,
                   *, force: bool = False) -> TaskStatus:
        task = self.get(task_id)
        if task is None:
            raise KeyError(task_id)
        cur = TaskStatus(task["status"])
        if not force and not can_transition(cur, status):
            raise InvalidTransition(f"task {task_id}: {cur.value} -> {status.value}")
        fields: dict[str, Any] = {"status": status.value, "status_reason": reason}
        if status in ACTIVE_STATUSES and not task["started_at"]:
            fields["started_at"] = time.time()
        if status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
            fields["finished_at"] = time.time()
        if status == TaskStatus.QUEUED:
            fields["finished_at"] = None
        self.update(task_id, **fields)
        return cur

    def add_error(self, task_id: int, message: str) -> None:
        task = self.get(task_id)
        errs = (task or {}).get("errors") or []
        errs.append({"at": time.time(), "error": message[:2000]})
        self.update(task_id, errors=errs[-50:])

    def set_flag(self, task_id: int, key: str, value: Any) -> None:
        task = self.get(task_id)
        flags = (task or {}).get("flags") or {}
        flags[key] = value
        self.update(task_id, flags=flags)

    # ------------------------------------------------------------------ steps
    def add_step(self, task_id: int, kind: StepKind, instruction: str, *,
                 parallel_group: str | None = None, origin: str = "plan",
                 after_seq: int | None = None) -> int:
        """Append a step, or insert it directly after ``after_seq`` (renumbering later steps)."""
        with self.db.transaction() as c:
            if after_seq is None:
                row = c.execute("SELECT COALESCE(MAX(seq),0) FROM steps WHERE task_id=?",
                                (task_id,)).fetchone()
                seq = row[0] + 1
            else:
                c.execute("UPDATE steps SET seq=seq+1 WHERE task_id=? AND seq>?", (task_id, after_seq))
                seq = after_seq + 1
            cur = c.execute(
                "INSERT INTO steps(task_id,seq,kind,instruction,status,read_only,parallel_group,origin,"
                "tried_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (task_id, seq, kind.value, instruction, StepStatus.PENDING.value,
                 int(kind in READ_ONLY_KINDS), parallel_group, origin, "[]", time.time()))
            return cur.lastrowid

    def steps(self, task_id: int) -> list[dict]:
        rows = self.db.query("SELECT * FROM steps WHERE task_id=? ORDER BY seq", (task_id,))
        return [_decode(r, _STEP_JSON) for r in rows]

    def step(self, step_id: int) -> dict | None:
        return _decode(self.db.query_one("SELECT * FROM steps WHERE id=?", (step_id,)), _STEP_JSON)

    def next_steps(self, task_id: int) -> list[dict]:
        """Next pending step, plus following pending steps in the same parallel group."""
        pending = [s for s in self.steps(task_id) if s["status"] == StepStatus.PENDING.value]
        if not pending:
            return []
        first = pending[0]
        group = first["parallel_group"]
        if not group or not first["read_only"]:
            return [first]
        out = [first]
        for s in pending[1:]:
            if s["parallel_group"] == group and s["read_only"]:
                out.append(s)
            else:
                break
        return out

    def update_step(self, step_id: int, **fields: Any) -> None:
        if not fields:
            return
        for k in list(fields):
            if k + "_json" in _STEP_JSON:
                fields[k + "_json"] = json.dumps(fields.pop(k))
        cols = ",".join(f"{k}=?" for k in fields)
        self.db.execute(f"UPDATE steps SET {cols} WHERE id=?", (*fields.values(), step_id))

    def reset_running_steps(self, task_id: int) -> list[dict]:
        """After a crash: steps that were RUNNING go back to PENDING. Returns them."""
        running = [s for s in self.steps(task_id) if s["status"] == StepStatus.RUNNING.value]
        for s in running:
            self.update_step(s["id"], status=StepStatus.PENDING.value, pid=None,
                             error=(s.get("error") or "") + " [interrupted by restart]")
        return running

    # ------------------------------------------------------------------ approvals
    def create_approval(self, task_id: int | None, action: str, detail: str,
                        payload: dict | None = None) -> int:
        existing = self.db.query_one(
            "SELECT id FROM approvals WHERE task_id IS ? AND action=? AND status='pending'",
            (task_id, action))
        if existing:
            return existing["id"]
        return self.db.execute(
            "INSERT INTO approvals(task_id,action,detail,payload_json,status,created_at) "
            "VALUES(?,?,?,?, 'pending', ?)",
            (task_id, action, detail, json.dumps(payload or {}), time.time()))

    def approvals(self, status: str | None = "pending") -> list[dict]:
        if status:
            rows = self.db.query("SELECT * FROM approvals WHERE status=? ORDER BY id", (status,))
        else:
            rows = self.db.query("SELECT * FROM approvals ORDER BY id DESC LIMIT 200")
        for r in rows:
            r["payload"] = json.loads(r["payload_json"] or "{}")
        return rows

    def decide_approval(self, approval_id: int, approved: bool, by: str) -> dict | None:
        row = self.db.query_one("SELECT * FROM approvals WHERE id=?", (approval_id,))
        if not row or row["status"] != "pending":
            return None
        self.db.execute("UPDATE approvals SET status=?, decided_at=?, decided_by=? WHERE id=?",
                        ("approved" if approved else "denied", time.time(), by, approval_id))
        row["status"] = "approved" if approved else "denied"
        row["payload"] = json.loads(row["payload_json"] or "{}")
        return row
