from __future__ import annotations

from enum import Enum


class TaskStatus(str, Enum):
    QUEUED = "QUEUED"
    PLANNING = "PLANNING"
    RUNNING = "RUNNING"
    WAITING_WORKER = "WAITING_WORKER"
    REVIEWING = "REVIEWING"
    TESTING = "TESTING"
    FIXING = "FIXING"
    PAUSED = "PAUSED"
    RECOVERING = "RECOVERING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class StepStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    DONE = "DONE"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class StepKind(str, Enum):
    INVESTIGATE = "investigate"   # read-only analysis
    IMPLEMENT = "implement"       # writes code
    REVIEW = "review"             # read-only review with verdict
    EDGE_CASES = "edge_cases"     # read-only bug/edge-case hunt with verdict
    FIX = "fix"                   # writes code to address failures/review issues
    VERIFY = "verify"             # run by the orchestrator itself: build + tests
    RESEARCH = "research"         # read-only web/deep research producing a report


READ_ONLY_KINDS = {StepKind.INVESTIGATE, StepKind.REVIEW, StepKind.EDGE_CASES, StepKind.RESEARCH}
WRITE_KINDS = {StepKind.IMPLEMENT, StepKind.FIX}

TERMINAL_STATUSES = {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED}
# Statuses in which the engine owns the task and should be driving it.
ACTIVE_STATUSES = {TaskStatus.PLANNING, TaskStatus.RUNNING, TaskStatus.WAITING_WORKER,
                   TaskStatus.REVIEWING, TaskStatus.TESTING, TaskStatus.FIXING,
                   TaskStatus.RECOVERING}
RUNNABLE_STATUSES = {TaskStatus.QUEUED, TaskStatus.RECOVERING, TaskStatus.WAITING_WORKER}


class InvalidTransition(ValueError):
    pass


def can_transition(src: TaskStatus, dst: TaskStatus) -> bool:
    if src == dst:
        return True
    if src == TaskStatus.COMPLETED:
        return False
    if src in (TaskStatus.FAILED, TaskStatus.CANCELLED):
        return dst == TaskStatus.QUEUED  # explicit retry only
    if src == TaskStatus.PAUSED:
        return dst in (TaskStatus.QUEUED, TaskStatus.RECOVERING, TaskStatus.CANCELLED)
    if src == TaskStatus.QUEUED:
        return dst in (TaskStatus.PLANNING, TaskStatus.RUNNING, TaskStatus.PAUSED,
                       TaskStatus.CANCELLED, TaskStatus.RECOVERING, TaskStatus.FAILED)
    # any active status can move to any non-QUEUED status
    return dst != TaskStatus.QUEUED or src == TaskStatus.PLANNING
