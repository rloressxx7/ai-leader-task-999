"""Persistent project memory + discovery.

Avoids rediscovering the same project each time. Stores non-secret facts only:
tech stack, entry points, build/test commands, known issues, recent changes,
git state, and which workers have worked on it.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from ..config import Settings
from ..database import Database
from ..security.secrets import redact
from ..tools import filesystem as fs
from ..tools.git import Git


def _detect_stack(root: Path) -> list[str]:
    stack = []
    checks = {
        "Rust": ["Cargo.toml"], "Node/TS": ["package.json"], "Python": ["pyproject.toml", "setup.py", "requirements.txt"],
        "Go": ["go.mod"], "Java": ["pom.xml", "build.gradle"], "Docker": ["Dockerfile", "docker-compose.yml"],
        "C/C++": ["CMakeLists.txt", "Makefile"], "Anchor/Solana": ["Anchor.toml"],
    }
    for name, files in checks.items():
        if any((root / f).exists() for f in files):
            stack.append(name)
    if not stack and list(root.glob("*.py")):
        stack.append("Python")
    return stack


class MemoryStore:
    def __init__(self, db: Database, settings: Settings, git: Git):
        self.db = db
        self.s = settings
        self.git = git

    # ------------------------------------------------------------------ projects
    def get_project(self, project_id: int) -> dict | None:
        return self.db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))

    def get_project_by_path(self, path: str) -> dict | None:
        return self.db.query_one("SELECT * FROM projects WHERE path=?",
                                 (os.path.normcase(os.path.abspath(path)),))

    def list_projects(self) -> list[dict]:
        return self.db.query("SELECT id,name,path,project_summary,updated_at FROM projects ORDER BY updated_at DESC")

    def upsert_project(self, path: str, **fields) -> int:
        path = os.path.normcase(os.path.abspath(path))
        existing = self.get_project_by_path(path)
        name = fields.pop("name", None) or Path(path).name
        now = time.time()
        json_fields = {k: v for k, v in fields.items()}
        cols = {"name": name, "path": path, "updated_at": now, **json_fields}
        if existing:
            import json as _j
            sets = ",".join(f"{k}=?" for k in cols)
            vals = [(_j.dumps(v) if k.endswith("_json") else v) for k, v in cols.items()]
            self.db.execute(f"UPDATE projects SET {sets} WHERE id=?", (*vals, existing["id"]))
            return existing["id"]
        import json as _j
        keys = list(cols)
        vals = [(_j.dumps(cols[k]) if k.endswith("_json") else cols[k]) for k in keys]
        ph = ",".join("?" * len(keys))
        return self.db.execute(f"INSERT INTO projects({','.join(keys)}) VALUES({ph})", tuple(vals))

    async def discover(self, path: str) -> dict:
        """Inspect a project directory and persist a fresh summary."""
        root = Path(path)
        stack = _detect_stack(root)
        from ..orchestrator.verify import detect_checks
        checks = detect_checks(str(root))
        build = [c.command for c in checks if c.kind == "build"]
        test = [c.command for c in checks if c.kind == "test"]
        files = fs.list_files(root, max_files=400)
        entry_points = [f for f in files if Path(f).name in
                        ("main.py", "main.rs", "index.ts", "index.js", "app.py", "server.py",
                         "main.go", "lib.rs", "__main__.py", "cli.py")]
        important = [f for f in files if Path(f).name in
                     ("Cargo.toml", "package.json", "pyproject.toml", "go.mod", "README.md",
                      "Anchor.toml", "docker-compose.yml", "Dockerfile")]
        git_state = {}
        if await self.git.is_own_repo(root):
            git_state = {"branch": await self.git.current_branch(root),
                         "head": (await self.git.head(root) or "")[:12],
                         "recent": await self.git.log(root, 5)}
        summary = f"{Path(path).name}: {', '.join(stack) or 'unknown stack'}; {len(files)} files"
        pid = self.upsert_project(
            str(root), name=Path(path).name, project_summary=redact(summary),
            tech_stack_json=stack, important_files_json=important[:20],
            entry_points_json=entry_points[:10], build_commands_json=build,
            test_commands_json=test, git_state_json=git_state, fingerprint=str(len(files)))
        return self.get_project(pid)

    def project_context(self, project_id: int | None) -> str:
        if not project_id:
            return ""
        p = self.get_project(project_id)
        if not p:
            return ""
        import json as _j
        def j(k):
            try:
                return _j.loads(p.get(k) or "null")
            except Exception:
                return None
        lines = [f"Name: {p['name']}", f"Path: {p['path']}"]
        if p.get("project_summary"):
            lines.append(f"Summary: {p['project_summary']}")
        stack = j("tech_stack_json")
        if stack:
            lines.append("Stack: " + ", ".join(stack))
        ep = j("entry_points_json")
        if ep:
            lines.append("Entry points: " + ", ".join(ep))
        build = j("build_commands_json"); test = j("test_commands_json")
        if build:
            lines.append("Build: " + "; ".join(build))
        if test:
            lines.append("Test: " + "; ".join(test))
        ki = j("known_issues_json")
        if ki:
            lines.append("Known issues: " + "; ".join(ki[:5]))
        return redact("\n".join(lines))

    def add_known_issue(self, project_id: int, issue: str) -> None:
        import json as _j
        p = self.get_project(project_id)
        if not p:
            return
        issues = _j.loads(p.get("known_issues_json") or "[]")
        issues.append(redact(issue)[:300])
        self.db.execute("UPDATE projects SET known_issues_json=? WHERE id=?",
                        (_j.dumps(issues[-20:]), project_id))

    def note_worker_history(self, project_id: int | None, worker: str, ok: bool) -> None:
        if not project_id:
            return
        import json as _j
        p = self.get_project(project_id)
        if not p:
            return
        hist = _j.loads(p.get("worker_history_json") or "{}")
        h = hist.setdefault(worker, {"ok": 0, "fail": 0})
        h["ok" if ok else "fail"] += 1
        self.db.execute("UPDATE projects SET worker_history_json=? WHERE id=?",
                        (_j.dumps(hist), project_id))

    # ------------------------------------------------------------------ generic memory
    def remember(self, scope: str, kind: str, content: str, task_id: int | None = None) -> int:
        return self.db.execute(
            "INSERT INTO memory(scope,kind,content,task_id,created_at) VALUES(?,?,?,?,?)",
            (scope, kind, redact(content)[:2000], task_id, time.time()))

    def recall(self, scope: str, kind: str | None = None, limit: int = 20) -> list[dict]:
        if kind:
            return self.db.query(
                "SELECT * FROM memory WHERE scope=? AND kind=? ORDER BY id DESC LIMIT ?",
                (scope, kind, limit))
        return self.db.query("SELECT * FROM memory WHERE scope=? ORDER BY id DESC LIMIT ?",
                             (scope, limit))
