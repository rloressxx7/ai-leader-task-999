"""SQLite persistence. All durable state (tasks, steps, events, logs, memory) lives here."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_request TEXT NOT NULL,
    title TEXT,
    status TEXT NOT NULL,
    status_reason TEXT,
    priority INTEGER NOT NULL DEFAULT 5,
    source TEXT,
    project_id INTEGER,
    plan_json TEXT,
    current_step INTEGER,
    worker TEXT,
    workspace TEXT,
    branch TEXT,
    base_commit TEXT,
    checkpoint TEXT,
    fix_iterations INTEGER NOT NULL DEFAULT 0,
    recoveries INTEGER NOT NULL DEFAULT 0,
    wake_at REAL,
    flags_json TEXT,
    tests_json TEXT,
    result TEXT,
    errors_json TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    started_at REAL,
    finished_at REAL
);
CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status);

CREATE TABLE IF NOT EXISTS steps(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    seq INTEGER NOT NULL,
    kind TEXT NOT NULL,
    instruction TEXT NOT NULL,
    status TEXT NOT NULL,
    read_only INTEGER NOT NULL DEFAULT 0,
    parallel_group TEXT,
    origin TEXT,
    worker TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    tried_json TEXT,
    pid INTEGER,
    log_path TEXT,
    summary TEXT,
    output TEXT,
    verdict_json TEXT,
    error TEXT,
    checkpoint_before TEXT,
    checkpoint_after TEXT,
    created_at REAL NOT NULL,
    started_at REAL,
    finished_at REAL,
    last_activity_at REAL
);
CREATE INDEX IF NOT EXISTS ix_steps_task ON steps(task_id, seq);

CREATE TABLE IF NOT EXISTS events(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    type TEXT NOT NULL,
    message TEXT NOT NULL,
    data_json TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_events_task ON events(task_id, id);

CREATE TABLE IF NOT EXISTS action_log(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    task_id INTEGER,
    step_id INTEGER,
    worker TEXT,
    action TEXT NOT NULL,
    tool TEXT,
    command TEXT,
    result TEXT,
    duration_ms INTEGER,
    error TEXT
);
CREATE INDEX IF NOT EXISTS ix_actions_task ON action_log(task_id, id);

CREATE TABLE IF NOT EXISTS workers_state(
    name TEXT PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 1,
    availability TEXT,
    unavailable_until REAL,
    last_error TEXT,
    health_json TEXT,
    updated_at REAL
);

CREATE TABLE IF NOT EXISTS worker_stats(
    worker TEXT NOT NULL,
    kind TEXT NOT NULL,
    completed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    total_duration_s REAL NOT NULL DEFAULT 0,
    limit_events INTEGER NOT NULL DEFAULT 0,
    fixes_ok INTEGER NOT NULL DEFAULT 0,
    fixes_total INTEGER NOT NULL DEFAULT 0,
    reviews_accurate INTEGER NOT NULL DEFAULT 0,
    reviews_scored INTEGER NOT NULL DEFAULT 0,
    tests_passed INTEGER NOT NULL DEFAULT 0,
    tests_run INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(worker, kind)
);

CREATE TABLE IF NOT EXISTS projects(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    path TEXT NOT NULL UNIQUE,
    project_summary TEXT,
    tech_stack_json TEXT,
    architecture TEXT,
    important_files_json TEXT,
    entry_points_json TEXT,
    build_commands_json TEXT,
    test_commands_json TEXT,
    known_issues_json TEXT,
    recent_changes_json TEXT,
    git_state_json TEXT,
    worker_history_json TEXT,
    fingerprint TEXT,
    updated_at REAL
);

CREATE TABLE IF NOT EXISTS memory(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope TEXT NOT NULL,
    kind TEXT NOT NULL,
    content TEXT NOT NULL,
    task_id INTEGER,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_memory_scope ON memory(scope, kind);

CREATE TABLE IF NOT EXISTS approvals(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    action TEXT NOT NULL,
    detail TEXT,
    payload_json TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at REAL NOT NULL,
    decided_at REAL,
    decided_by TEXT
);

CREATE TABLE IF NOT EXISTS messages(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    direction TEXT NOT NULL,
    peer TEXT NOT NULL,
    text TEXT NOT NULL,
    status TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    error TEXT,
    external_id TEXT,
    created_at REAL NOT NULL,
    sent_at REAL
);
CREATE INDEX IF NOT EXISTS ix_messages_status ON messages(direction, status);

CREATE TABLE IF NOT EXISTS subscribers(
    channel TEXT NOT NULL,
    peer TEXT NOT NULL,
    last_event_id INTEGER NOT NULL DEFAULT 0,
    last_inbound_at REAL,
    PRIMARY KEY(channel, peer)
);

CREATE TABLE IF NOT EXISTS kv(
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


class Database:
    """Thread-safe wrapper around one SQLite connection (WAL mode).

    Queries are short, so they are executed synchronously from async code.
    """

    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None,
                                     timeout=30)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(SCHEMA)
            self._conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")

    def execute(self, sql: str, params: tuple | dict = ()) -> int:
        """Execute a write; return lastrowid (for INSERT) or rowcount."""
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.lastrowid if sql.lstrip().upper().startswith("INSERT") else cur.rowcount

    def query(self, sql: str, params: tuple | dict = ()) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def query_one(self, sql: str, params: tuple | dict = ()) -> dict[str, Any] | None:
        with self._lock:
            r = self._conn.execute(sql, params).fetchone()
            return dict(r) if r else None

    # ----------------------------------------------------------------- key/value
    def kv_get(self, key: str, default: Any = None) -> Any:
        row = self.query_one("SELECT value FROM kv WHERE key=?", (key,))
        return json.loads(row["value"]) if row else default

    def kv_set(self, key: str, value: Any) -> None:
        self.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                     (key, json.dumps(value)))

    # ----------------------------------------------------------------- action log
    def log_action(self, action: str, *, task_id: int | None = None, step_id: int | None = None,
                   worker: str | None = None, tool: str | None = None, command: str | None = None,
                   result: str | None = None, duration_ms: int | None = None,
                   error: str | None = None) -> None:
        self.execute(
            "INSERT INTO action_log(ts,task_id,step_id,worker,action,tool,command,result,duration_ms,error)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (time.time(), task_id, step_id, worker, action, tool,
             (command or "")[:4000] or None, (result or "")[:4000] or None, duration_ms,
             (error or "")[:4000] or None))
