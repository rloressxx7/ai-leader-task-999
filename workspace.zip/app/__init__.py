"""Ollama Leader — a local LLM that orchestrates real coding agents."""

__version__ = "0.1.0"
