"""Event bus: every important state change is persisted and fanned out to live
subscribers (dashboard SSE, messaging gateway). Reports are derived from these
events, so the user never has to ask for status."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from enum import Enum
from typing import Any

from ..database import Database
from ..security.secrets import redact

log = logging.getLogger("leader.events")


class EventType(str, Enum):
    TASK_QUEUED = "TASK_QUEUED"
    TASK_STARTED = "TASK_STARTED"
    PLAN_READY = "PLAN_READY"
    WORKSPACE_READY = "WORKSPACE_READY"
    WORKER_ASSIGNED = "WORKER_ASSIGNED"
    WORKER_SAYS = "WORKER_SAYS"          # live per-agent activity summaries, edits, commands
    DISCUSSION = "DISCUSSION"            # inter-agent debate (a review, a rebuttal, a fix response)
    WORKER_COMPLETED = "WORKER_COMPLETED"
    WORKER_FAILED = "WORKER_FAILED"
    FAILOVER = "FAILOVER"
    WORKER_UNAVAILABLE = "WORKER_UNAVAILABLE"
    QUOTA_WARNING = "QUOTA_WARNING"
    REVIEW_RESULT = "REVIEW_RESULT"
    CHECKPOINT = "CHECKPOINT"
    TEST_STARTED = "TEST_STARTED"
    TEST_FAILED = "TEST_FAILED"
    TEST_PASSED = "TEST_PASSED"
    FIX_STARTED = "FIX_STARTED"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"
    APPROVAL_DECIDED = "APPROVAL_DECIDED"
    MERGED = "MERGED"
    TASK_COMPLETED = "TASK_COMPLETED"
    TASK_BLOCKED = "TASK_BLOCKED"
    TASK_FAILED = "TASK_FAILED"
    TASK_PAUSED = "TASK_PAUSED"
    TASK_RESUMED = "TASK_RESUMED"
    TASK_ADJUSTED = "TASK_ADJUSTED"
    TASK_CANCELLED = "TASK_CANCELLED"
    TASK_RECOVERING = "TASK_RECOVERING"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    SYSTEM = "SYSTEM"


ICONS = {
    EventType.TASK_QUEUED: "📥", EventType.TASK_STARTED: "🟢", EventType.PLAN_READY: "🗺️",
    EventType.WORKSPACE_READY: "📂", EventType.WORKER_ASSIGNED: "🔵",
    EventType.WORKER_SAYS: "💬", EventType.DISCUSSION: "🗣️",
    EventType.WORKER_COMPLETED: "☑️", EventType.WORKER_FAILED: "🔴", EventType.FAILOVER: "🔁",
    EventType.WORKER_UNAVAILABLE: "⛔", EventType.REVIEW_RESULT: "🟡", EventType.CHECKPOINT: "💾",
    EventType.QUOTA_WARNING: "⚠️",
    EventType.TEST_STARTED: "🧪", EventType.TEST_FAILED: "🔴", EventType.TEST_PASSED: "🟢",
    EventType.FIX_STARTED: "🔧", EventType.APPROVAL_REQUIRED: "✋", EventType.APPROVAL_DECIDED: "👍",
    EventType.MERGED: "🔀", EventType.TASK_COMPLETED: "✅", EventType.TASK_BLOCKED: "🚧",
    EventType.TASK_FAILED: "❌", EventType.TASK_PAUSED: "⏸️", EventType.TASK_RESUMED: "▶️",
    EventType.TASK_CANCELLED: "🛑", EventType.TASK_RECOVERING: "♻️",
    EventType.TASK_ADJUSTED: "🎛️",
    EventType.EMERGENCY_STOP: "🚨", EventType.SYSTEM: "ℹ️",
}


def format_event(ev: dict) -> str:
    try:
        icon = ICONS[EventType(ev["type"])]
    except (ValueError, KeyError):
        icon = "•"
    prefix = f"[#{ev['task_id']}] " if ev.get("task_id") else ""
    return f"{icon} {prefix}{ev['message']}"


class EventBus:
    def __init__(self, db: Database):
        self.db = db
        self._subs: set[asyncio.Queue] = set()

    def publish(self, type_: EventType, message: str, *, task_id: int | None = None,
                **data: Any) -> dict:
        message = redact(message)
        now = time.time()
        payload = json.dumps(data, default=str) if data else None
        eid = self.db.execute(
            "INSERT INTO events(task_id,type,message,data_json,created_at) VALUES(?,?,?,?,?)",
            (task_id, type_.value, message, payload, now))
        ev = {"id": eid, "task_id": task_id, "type": type_.value, "message": message,
              "data": data or {}, "created_at": now}
        log.info(format_event(ev), extra={"event": type_.value, "task_id": task_id})
        for q in list(self._subs):
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                pass  # slow consumer; it can re-read from the DB by id
        return ev

    def subscribe(self, maxsize: int = 1000) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def since(self, after_id: int = 0, task_id: int | None = None, limit: int = 500) -> list[dict]:
        if task_id is None:
            rows = self.db.query("SELECT * FROM events WHERE id>? ORDER BY id LIMIT ?", (after_id, limit))
        else:
            rows = self.db.query("SELECT * FROM events WHERE id>? AND task_id=? ORDER BY id LIMIT ?",
                                 (after_id, task_id, limit))
        for r in rows:
            r["data"] = json.loads(r.pop("data_json") or "{}")
        return rows

    def recent(self, limit: int = 100, task_id: int | None = None) -> list[dict]:
        if task_id is None:
            rows = self.db.query("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))
        else:
            rows = self.db.query("SELECT * FROM events WHERE task_id=? ORDER BY id DESC LIMIT ?",
                                 (task_id, limit))
        for r in rows:
            r["data"] = json.loads(r.pop("data_json") or "{}")
        return list(reversed(rows))
