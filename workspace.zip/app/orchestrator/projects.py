"""Resolve which project a natural-language request refers to, and scan roots."""
from __future__ import annotations

import os
import re
import time
from pathlib import Path

from ..config import Settings

PROJECT_MARKERS = ["Cargo.toml", "package.json", "pyproject.toml", "go.mod", ".git",
                   "Anchor.toml", "requirements.txt", "setup.py", "pom.xml", "build.gradle",
                   "CMakeLists.txt", "Makefile", "tsconfig.json", "composer.json"]
# Source extensions that make a plain folder count as a code project.
CODE_EXT = {".py", ".rs", ".ts", ".tsx", ".js", ".jsx", ".go", ".java", ".kt", ".c", ".h",
            ".cpp", ".hpp", ".cs", ".rb", ".php", ".swift", ".scala", ".sol"}


def looks_like_project(path: Path) -> bool:
    try:
        if any((path / m).exists() for m in PROJECT_MARKERS):
            return True
        # A folder holding source files is a project even without a manifest.
        for e in os.scandir(path):
            if e.is_file() and os.path.splitext(e.name)[1].lower() in CODE_EXT:
                return True
    except OSError:
        return False
    return False


def scan_projects(settings: Settings) -> list[dict]:
    """Find candidate project directories under configured roots."""
    out: dict[str, dict] = {}
    exclude = set(settings.projects.exclude)
    for root in settings.projects.roots:
        root_path = Path(os.path.expanduser(root))
        if not root_path.exists():
            continue
        _walk(root_path, settings.projects.scan_depth, exclude, out)
    return sorted(out.values(), key=lambda d: d["mtime"], reverse=True)


def _walk(base: Path, depth: int, exclude: set, out: dict) -> None:
    try:
        entries = list(os.scandir(base))
    except OSError:
        return
    for e in entries:
        if not e.is_dir(follow_symlinks=False) or e.name in exclude or e.name.startswith("."):
            continue
        p = Path(e.path)
        if looks_like_project(p):
            try:
                mtime = e.stat().st_mtime
            except OSError:
                mtime = 0
            out[os.path.normcase(str(p))] = {"name": p.name, "path": str(p), "mtime": mtime}
        elif depth > 0:
            _walk(p, depth - 1, exclude, out)


_TOKEN = re.compile(r"[a-z0-9]+")


def _tokens(text: str) -> set[str]:
    return set(_TOKEN.findall(text.lower()))


def resolve_project(request: str, candidates: list[dict], known: list[dict]) -> tuple[dict | None, float]:
    """Best-matching project for a request. Returns (project_dict, confidence 0..1).

    Matches request tokens against project names (and known summaries). An explicit
    path or quoted name in the request wins.
    """
    # Explicit path mention.
    m = re.search(r"[A-Za-z]:\\[^\s\"']+|(?:/[^\s\"']+){2,}|~[/\\][^\s\"']+", request)
    if m:
        p = Path(os.path.expanduser(m.group(0)))
        if p.exists():
            return {"name": p.name, "path": str(p)}, 1.0

    req_tokens = _tokens(request)
    if not req_tokens:
        return None, 0.0

    by_path = {os.path.normcase(k["path"]): k for k in candidates}
    for k in known:
        by_path.setdefault(os.path.normcase(k["path"]), {"name": k["name"], "path": k["path"],
                                                         "summary": k.get("project_summary", "")})

    best, best_score = None, 0.0
    for info in by_path.values():
        name_tokens = _tokens(info["name"])
        score = 0.0
        # Whole project name appearing in request is a strong signal.
        if info["name"].lower() in request.lower() and len(info["name"]) >= 3:
            score += 0.7
        overlap = req_tokens & name_tokens
        if overlap:
            score += 0.5 * len(overlap) / max(len(name_tokens), 1)
        summ = info.get("summary") or ""
        if summ:
            score += 0.1 * len(req_tokens & _tokens(summ)) / max(len(req_tokens), 1)
        if score > best_score:
            best, best_score = info, score
    return best, min(best_score, 0.99)
