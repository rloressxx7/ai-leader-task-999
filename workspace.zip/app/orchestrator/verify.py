"""Independent verification. A worker saying "done" is not trusted: the orchestrator
detects the project's build and test commands, runs them itself, and parses the
outcome. Completion requires the build to succeed and tests to pass (when they exist)."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from ..tools import terminal
from ..tools.terminal import CommandResult


@dataclass
class Check:
    name: str
    command: str
    shell: str | None
    kind: str            # "build" | "test"


@dataclass
class CheckOutcome:
    name: str
    command: str
    kind: str
    ok: bool
    exit_code: int | None
    passed: int | None = None
    failed: int | None = None
    total: int | None = None
    duration_s: float = 0.0
    timed_out: bool = False
    tail: str = ""


@dataclass
class VerifyReport:
    ran: bool = False
    build_ok: bool | None = None
    tests_ok: bool | None = None
    outcomes: list[CheckOutcome] = field(default_factory=list)
    passed: int = 0
    failed: int = 0
    total: int = 0
    detail: str = ""

    @property
    def ok(self) -> bool:
        if not self.ran:
            return False
        if self.build_ok is False or self.tests_ok is False:
            return False
        return True

    def summary(self) -> str:
        if not self.ran:
            return "no build/test commands detected"
        parts = []
        if self.build_ok is not None:
            parts.append("build " + ("ok" if self.build_ok else "FAILED"))
        if self.tests_ok is not None:
            if self.total:
                parts.append(f"tests {self.passed}/{self.total} passed" +
                             ("" if self.tests_ok else " — FAILED"))
            else:
                parts.append("tests " + ("ok" if self.tests_ok else "FAILED"))
        return ", ".join(parts) or self.detail


def _has(root: Path, *names: str) -> bool:
    return any((root / n).exists() for n in names)


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def detect_checks(workspace: str) -> list[Check]:
    """Detect build+test commands from project manifests. Ordered: build then test."""
    root = Path(workspace)
    checks: list[Check] = []

    # ---- Rust
    if _has(root, "Cargo.toml"):
        checks.append(Check("cargo build", "cargo build --quiet", "cmd", "build"))
        checks.append(Check("cargo test", "cargo test --quiet", "cmd", "test"))
        return checks

    # ---- Node / JS / TS
    if _has(root, "package.json"):
        pkg = _read_json(root / "package.json")
        scripts = pkg.get("scripts", {})
        runner = "npm run"
        if _has(root, "pnpm-lock.yaml"):
            runner = "pnpm run"
        elif _has(root, "yarn.lock"):
            runner = "yarn"
        if "build" in scripts:
            checks.append(Check("build", f"{runner} build", "cmd", "build"))
        elif "tsc" in json.dumps(scripts) or _has(root, "tsconfig.json"):
            checks.append(Check("tsc", "npx tsc --noEmit", "cmd", "build"))
        if "test" in scripts and "no test specified" not in scripts.get("test", ""):
            checks.append(Check("test", f"{runner} test", "cmd", "test"))
        return checks

    # ---- Python
    py = bool(list(root.glob("*.py"))) or _has(root, "pyproject.toml", "setup.py", "requirements.txt",
                                               "tox.ini", "pytest.ini")
    if py:
        has_tests = _has(root, "tests", "test") or bool(list(root.glob("test_*.py"))) or \
            bool(list(root.glob("*_test.py"))) or bool(list(root.rglob("test_*.py")))
        launcher = _python_launcher(root)
        if has_tests:
            checks.append(Check("pytest", f"{launcher} -m pytest -q", "cmd", "test"))
        else:
            # At least import-compile every module as a smoke build.
            checks.append(Check("py-compile", f"{launcher} -m compileall -q .", "cmd", "build"))
        return checks

    # ---- Go
    if _has(root, "go.mod"):
        checks.append(Check("go build", "go build ./...", "cmd", "build"))
        checks.append(Check("go test", "go test ./...", "cmd", "test"))
        return checks

    # ---- Make fallback
    if _has(root, "Makefile", "makefile"):
        checks.append(Check("make", "make", "bash", "build"))
    return checks


def _python_launcher(workspace: Path | str | None = None) -> str:
    """Pick a Python that actually has the project's/leader's deps.

    Priority: a project-local virtualenv, then the interpreter running the leader
    (guaranteed to exist and to have pytest, since the leader depends on it), then
    a PATH fallback. The Windows ``py`` launcher is avoided because it targets the
    bare system Python, which typically lacks pytest.
    """
    import shutil
    import sys
    if workspace:
        root = Path(workspace)
        for venv in (".venv", "venv", "env"):
            cand = (root / venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python"))
            if cand.exists():
                return _quote(str(cand))
    if sys.executable:
        return _quote(sys.executable)
    return shutil.which("python3") or shutil.which("python") or "python"


def _quote(p: str) -> str:
    return f'"{p}"' if " " in p and not p.startswith('"') else p


# --------------------------------------------------------------------------- parsing

_PYTEST = re.compile(r"(?:(\d+) failed)?[,\s]*(?:(\d+) passed)?(?:[,\s]*(\d+) error)?", re.I)
_CARGO = re.compile(r"test result:\s+\w+\.\s+(\d+) passed;\s+(\d+) failed", re.I)
_GOTEST_FAIL = re.compile(r"^(FAIL|--- FAIL)", re.M)
_JEST = re.compile(r"Tests:\s+(?:(\d+) failed,\s+)?(?:(\d+) passed,\s+)?(\d+) total", re.I)
_MOCHA = re.compile(r"(\d+) passing(?:.*?(\d+) failing)?", re.S)


def parse_counts(kind: str, res: CommandResult) -> tuple[int | None, int | None, int | None]:
    """Return (passed, failed, total) if parseable, else (None, None, None)."""
    out = res.output
    m = _CARGO.search(out)
    if m:
        p, f = int(m.group(1)), int(m.group(2))
        return p, f, p + f
    m = _JEST.search(out)
    if m:
        f = int(m.group(1) or 0); p = int(m.group(2) or 0); t = int(m.group(3))
        return p, f, t
    # pytest summary line, e.g. "= 3 failed, 5 passed in 0.2s ="
    for line in reversed(out.splitlines()):
        if ("passed" in line or "failed" in line or "error" in line) and "==" in line:
            failed = _int(re.search(r"(\d+) failed", line))
            passed = _int(re.search(r"(\d+) passed", line))
            errors = _int(re.search(r"(\d+) error", line))
            if passed is not None or failed is not None or errors is not None:
                p = passed or 0; f = (failed or 0) + (errors or 0)
                return p, f, p + f
    m = _MOCHA.search(out)
    if m:
        p = int(m.group(1)); f = int(m.group(2) or 0)
        return p, f, p + f
    if kind == "test" and "go test" in res.command:
        if _GOTEST_FAIL.search(out):
            return None, 1, None
        if res.ok:
            return None, 0, None
    return None, None, None


def _int(m) -> int | None:
    return int(m.group(1)) if m else None


class Verifier:
    def __init__(self, timeout_s: float = 1500):
        self.timeout_s = timeout_s

    async def run(self, workspace: str, env: dict | None = None,
                  on_progress=None) -> VerifyReport:
        checks = detect_checks(workspace)
        report = VerifyReport()
        if not checks:
            report.detail = "no recognised build/test setup"
            return report
        report.ran = True
        for chk in checks:
            if on_progress:
                on_progress("verify", f"{chk.name}: {chk.command}")
            res = await terminal.run(chk.command, cwd=workspace, shell=chk.shell, env=env,
                                     timeout_s=self.timeout_s)
            p, f, t = parse_counts(chk.kind, res)
            ok = res.ok if f is None else (res.ok and f == 0)
            outcome = CheckOutcome(chk.name, chk.command, chk.kind, ok, res.exit_code,
                                   passed=p, failed=f, total=t, duration_s=res.duration_s,
                                   timed_out=res.timed_out, tail=res.tail(2500))
            report.outcomes.append(outcome)
            if chk.kind == "build":
                report.build_ok = ok and report.build_ok is not False
            else:
                report.tests_ok = ok and report.tests_ok is not False
                report.passed += p or 0
                report.failed += f or 0
                report.total += t or 0
            # Stop at first build failure — tests won't be meaningful.
            if chk.kind == "build" and not ok:
                report.detail = f"build failed: {chk.name}"
                break
        return report
