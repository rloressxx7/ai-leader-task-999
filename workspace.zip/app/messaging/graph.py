"""Meta Graph API helpers for Instagram + WhatsApp Cloud API.

Only transport lives here: verifying webhook signatures, parsing inbound messages,
and sending replies. Secrets come from the environment (never config/DB/logs).
"""
from __future__ import annotations

import hashlib
import hmac
import logging
from dataclasses import dataclass

import httpx

from ..config import secret

log = logging.getLogger("leader.graph")


@dataclass
class InboundMessage:
    channel: str          # "instagram" | "whatsapp"
    peer: str             # sender id / phone number
    text: str
    external_id: str = ""


def verify_signature(app_secret: str | None, raw_body: bytes, header: str | None) -> bool:
    """Verify X-Hub-Signature-256. If no app secret is configured, fail closed."""
    if not app_secret or not header:
        return False
    if not header.startswith("sha256="):
        return False
    expected = hmac.new(app_secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header.split("=", 1)[1])


def verify_subscription(mode: str | None, token: str | None, expected_token: str | None) -> bool:
    return mode == "subscribe" and bool(expected_token) and token == expected_token


def parse_instagram(payload: dict) -> list[InboundMessage]:
    out: list[InboundMessage] = []
    if payload.get("object") != "instagram":
        return out
    for entry in payload.get("entry", []):
        for ev in entry.get("messaging", []):
            msg = ev.get("message", {})
            if msg.get("is_echo"):
                continue
            text = msg.get("text")
            sender = (ev.get("sender") or {}).get("id")
            if text and sender:
                out.append(InboundMessage("instagram", str(sender), text, msg.get("mid", "")))
    return out


def parse_whatsapp(payload: dict) -> list[InboundMessage]:
    out: list[InboundMessage] = []
    if payload.get("object") != "whatsapp_business_account":
        return out
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            for msg in value.get("messages", []):
                if msg.get("type") != "text":
                    continue
                body = (msg.get("text") or {}).get("body")
                frm = msg.get("from")
                if body and frm:
                    out.append(InboundMessage("whatsapp", str(frm), body, msg.get("id", "")))
    return out


class GraphSender:
    def __init__(self, settings):
        self.s = settings

    async def send(self, channel: str, peer: str, text: str) -> tuple[bool, str]:
        try:
            if channel == "instagram":
                return await self._send_instagram(peer, text)
            if channel == "whatsapp":
                return await self._send_whatsapp(peer, text)
        except httpx.HTTPError as e:
            return False, f"http error: {e}"
        return False, f"unknown channel {channel}"

    async def _send_instagram(self, peer: str, text: str) -> tuple[bool, str]:
        token = secret("IG_ACCESS_TOKEN")
        if not token:
            return False, "IG_ACCESS_TOKEN not set"
        cfg = self.s.messaging.instagram
        url = f"{cfg.api_base}/{cfg.graph_version}/me/messages"
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post(url, params={"access_token": token},
                             json={"recipient": {"id": peer}, "message": {"text": text}})
        return (r.status_code < 300, f"{r.status_code}: {r.text[:200]}")

    async def _send_whatsapp(self, peer: str, text: str) -> tuple[bool, str]:
        token = secret("WHATSAPP_ACCESS_TOKEN")
        cfg = self.s.messaging.whatsapp
        if not token or not cfg.phone_number_id:
            return False, "WHATSAPP_ACCESS_TOKEN or phone_number_id not set"
        url = f"{cfg.api_base}/{cfg.graph_version}/{cfg.phone_number_id}/messages"
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post(url, headers={"Authorization": f"Bearer {token}"},
                             json={"messaging_product": "whatsapp", "to": peer,
                                   "type": "text", "text": {"body": text}})
        return (r.status_code < 300, f"{r.status_code}: {r.text[:200]}")
