"""Telegram bot channel — the simplest reliable remote control.

Long-polling (getUpdates) means it works from localhost/behind NAT with no tunnel,
no public IP and no browser. You message the bot from your phone; the leader answers
and pushes progress reports. Only allow-listed chat ids are answered (fail-closed);
if the allowlist is empty, the bot only tells a sender their chat id so you can add it.

Token comes from env TELEGRAM_BOT_TOKEN (never config/DB/logs).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import time
import zipfile
from pathlib import Path

import httpx

from ..config import Settings, secret
from ..orchestrator import Orchestrator
from ..orchestrator.events import EventType, format_event
from ..tools import screenshot

log = logging.getLogger("leader.telegram")

_ACTIVITY_LABELS = {
    "assistant": "durum özeti",
    "edit": "dosya değişikliği",
    "bash": "komut",
    "browser": "tarayıcı",
    "tool": "araç",
    "verify": "doğrulama",
}


def format_telegram_event(ev: dict) -> str:
    """Format operational telemetry without exposing private chain-of-thought."""
    if ev.get("type") != EventType.WORKER_SAYS.value:
        return format_event(ev)
    data = ev.get("data") or {}
    worker = data.get("worker") or "AI"
    channel = _ACTIVITY_LABELS.get(data.get("channel"), "çalışma özeti")
    message = str(ev.get("message") or "")
    # The persisted message already starts with the worker name; avoid repeating it.
    if message.startswith(worker):
        message = message[len(worker):].lstrip(" :—-")
    tid = f" [#{ev['task_id']}]" if ev.get("task_id") else ""
    return f"🤖 {worker}{tid} · {channel}\n└ {message}"


def chunk_event_lines(lines: list[str], limit: int) -> list[str]:
    """Keep every event while respecting Telegram message limits."""
    chunks: list[str] = []
    current = ""
    for raw in lines:
        line = raw[:limit]
        candidate = line if not current else current + "\n\n" + line
        if current and len(candidate) > limit:
            chunks.append(current)
            current = line
        else:
            current = candidate
    if current:
        chunks.append(current)
    return chunks


def parse_updates(data: dict) -> list[dict]:
    """Extract text and photo messages from a getUpdates response."""
    out = []
    for u in data.get("result", []):
        msg = u.get("message") or u.get("edited_message")
        if not msg:
            continue
        chat = (msg.get("chat") or {}).get("id")
        if chat is None:
            continue
        base = {"update_id": u["update_id"], "chat_id": chat,
                "from": ((msg.get("from") or {}).get("username")
                         or (msg.get("from") or {}).get("first_name") or "")}
        if msg.get("text"):
            out.append({**base, "kind": "text", "text": msg["text"]})
        elif msg.get("photo"):
            fid = (msg["photo"][-1] or {}).get("file_id")  # last = highest resolution
            if fid:
                out.append({**base, "kind": "photo", "file_id": fid,
                            "text": msg.get("caption", "") or ""})
        elif msg.get("document"):
            doc = msg["document"]
            fid = doc.get("file_id")
            if fid:
                mime = str(doc.get("mime_type") or "")
                out.append({**base, "kind": "photo" if mime.startswith("image/") else "document",
                            "file_id": fid, "file_name": doc.get("file_name") or "upload.bin",
                            "mime_type": mime, "text": msg.get("caption", "") or ""})
    return out


class TelegramBot:
    def __init__(self, orch: Orchestrator, settings: Settings):
        self.orch = orch
        self.settings = settings
        self.s = settings.messaging.telegram
        self.token = secret("TELEGRAM_BOT_TOKEN")
        self.base = f"https://api.telegram.org/bot{self.token}" if self.token else ""
        self.allowed = set(self.s.allowed_chat_ids)

    def _allowed(self, chat_id: int) -> bool:
        return chat_id in self.allowed

    async def run(self) -> None:
        if not self.token:
            log.warning("telegram: TELEGRAM_BOT_TOKEN not set; channel disabled")
            return
        # Verify the token and learn the bot's name.
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                me = (await c.get(f"{self.base}/getMe")).json()
            if not me.get("ok"):
                log.warning("telegram: invalid token (getMe failed)")
                return
            log.info("telegram: connected as @%s; allowlist=%s",
                     me["result"].get("username"), sorted(self.allowed) or "(empty)")
        except httpx.HTTPError as e:
            log.warning("telegram: cannot reach Telegram: %s", e)
            return
        await asyncio.gather(self._poll_loop(), self._report_loop())

    async def _poll_loop(self) -> None:
        offset = self.orch.db.kv_get("telegram_offset", 0)
        timeout = self.s.poll_timeout_s
        async with httpx.AsyncClient(timeout=timeout + 15) as c:
            while not self.orch._stopping:
                try:
                    r = await c.get(f"{self.base}/getUpdates",
                                    params={"offset": offset, "timeout": timeout})
                    data = r.json()
                except httpx.HTTPError as e:
                    log.debug("telegram getUpdates error: %s", e)
                    await asyncio.sleep(3)
                    continue
                if not data.get("ok"):
                    await asyncio.sleep(3)
                    continue
                for m in parse_updates(data):
                    offset = m["update_id"] + 1
                    self.orch.db.kv_set("telegram_offset", offset)
                    await self._handle(m)

    async def _handle(self, m: dict) -> None:
        chat_id, text = m["chat_id"], m.get("text", "")
        if not self._allowed(chat_id):
            # Discovery: help the user allowlist themselves, but do no work.
            await self.send(chat_id,
                            f"🔒 This leader isn't configured for you yet.\nYour chat id is: {chat_id}\n"
                            f"Add it to config.toml → [messaging.telegram] allowed_chat_ids = [{chat_id}] "
                            f"and restart.")
            log.info("telegram: message from non-allowlisted chat %s (%s)", chat_id, m.get("from"))
            return
        await self.chat_action(chat_id)
        # A caption containing #<task> attaches the upload to that task and turns
        # the caption into authoritative live-edit guidance.
        if m.get("kind") in ("photo", "document"):
            path = await self.download_file(m["file_id"], m.get("file_name"))
            if not path:
                await self.send(chat_id, "Dosyayı indiremedim.")
                return
            match = re.search(r"(?:#|(?:task|görev|gorev)\s*#?)(\d+)", text, re.I)
            if match:
                tid = int(match.group(1))
                task = self.orch.tasks.get(tid)
                if not task or not task.get("workspace"):
                    await self.send(chat_id, f"Görev #{tid} veya çalışma alanı bulunamadı.")
                    return
                safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", Path(path).name)[:120]
                target_dir = Path(task["workspace"]) / "user_uploads"
                target_dir.mkdir(parents=True, exist_ok=True)
                target = target_dir / f"{int(time.time())}-{safe_name}"
                shutil.copy2(path, target)
                rel = target.relative_to(Path(task["workspace"])).as_posix()
                analysis = ""
                if m.get("kind") == "photo":
                    analysis = await self.orch.leader.analyze_image(str(target), text)
                guidance = re.sub(r"(?:#|(?:task|görev|gorev)\s*#?)\d+", "", text,
                                  count=1, flags=re.I).strip(" :-")
                if not guidance:
                    guidance = "Bu dosyayı/görseli referans alarak mevcut uygulamayı düzenle."
                detail = f"\nEklenen referans dosyası: {rel}"
                if analysis:
                    detail += f"\nGörsel analizi: {analysis[:1800]}"
                reply = await self.orch.adjust_task(tid, guidance + detail)
                await self.send(chat_id, f"📎 {rel} göreve eklendi.\n{reply}")
            elif m.get("kind") == "photo":
                analysis = await self.orch.leader.analyze_image(path, text)
                await self.send(chat_id, "🖼️ " + analysis +
                                "\n\nBir görevi düzenlemek için açıklamaya #7 gibi görev numarası ekle.")
            else:
                await self.send(chat_id, "Dosyayı bir göreve eklemek için açıklamaya görev numarası "
                                "ve talimat yaz: #7 bu dosyaya göre arayüzü düzenle")
            return
        if text.strip().startswith("/"):
            await self._command(chat_id, text.strip())
            return
        try:
            reply = await self.orch.handle_message(text, source="telegram")
        except Exception as e:
            reply = f"error: {e}"
        await self.send(chat_id, reply)

    async def _command(self, chat_id: int, text: str) -> None:
        cmd = text[1:].split()[0].lower().split("@")[0]
        arg = text[len(cmd) + 1:].strip()
        if cmd in ("start", "help"):
            await self.send(chat_id, self._help_text())
        elif cmd == "status":
            await self.send(chat_id, self.orch.status_report(int(arg) if arg.isdigit() else None))
        elif cmd in ("tasks", "list"):
            await self.send(chat_id, self.orch.list_report())
        elif cmd == "workers":
            rows = self.orch.workers.snapshot()
            await self.send(chat_id, "👷 Workers:\n" + "\n".join(
                f"• {w['name']} [{w['availability']}] {w['completed']}✓/{w['failed']}✗"
                + (f" cooldown {w['cooldown_s']}s" if w['cooldown_s'] else "") for w in rows))
        elif cmd == "tools":
            st = self.orch.tools.status
            ok = [n for n, s in st.items() if s.available]
            await self.send(chat_id, "🧰 Tools OK: " + ", ".join(sorted(ok)))
        elif cmd in ("stop", "stopall", "stop_all"):
            if arg.isdigit():
                await self.orch.cancel_task(int(arg)); await self.send(chat_id, f"🛑 #{arg} cancelled")
            else:
                n = await self.orch.emergency_stop(); await self.send(chat_id, f"🚨 Emergency stop. {n} halted.")
        elif cmd in ("pause", "resume", "continue") and arg.isdigit():
            await self.send(chat_id, await self.orch._control(cmd, int(arg)))
        elif cmd in ("adjust", "edit", "modify"):
            parts = arg.split(maxsplit=1)
            if len(parts) == 2 and parts[0].lstrip("#").isdigit():
                await self.send(chat_id, await self.orch.adjust_task(
                    int(parts[0].lstrip("#")), parts[1]))
            else:
                await self.send(chat_id, "Kullanım: /adjust <görev no> <düzenleme talimatı>")
        elif cmd == "research" and arg:
            tid = await self.orch.submit(arg, source="telegram", research=True)
            await self.send(chat_id, f"🔬 Research #{tid} started.")
        elif cmd == "mode":
            await self.send(chat_id,
                            "🧠 The leader auto-picks a mode per task:\n"
                            "• solo — one quick change (low effort)\n"
                            "• standard — a normal feature/fix\n"
                            "• team — several AIs build ONE project together, review each "
                            "other and debate, then integrate.\nJust describe what you want; "
                            "I choose the mode + which models (low/high) to use.")
        else:
            await self.send(chat_id, "Unknown command. " + self._help_text())

    def _help_text(self) -> str:
        return ("🧠 *Ollama Leader* — your AI engineering team.\n\n"
                "Just tell me what to do in plain language:\n"
                "• “solana-arb-bot'taki reconnect'i düzelt ve testleri geçir”\n"
                "• “bana bir yılan oyunu yap” (görsel/ekran görüntüsü gönderirim)\n"
                "• “araştır: en iyi rust web framework'leri” (rapor dosyası gelir)\n"
                "• görsel/dosya gönder; açıklamaya '#7 ...' yaz → göreve eklerim\n"
                "• “#7’de app.py dosyasını değiştir: ...”\n\n"
                "Commands:\n"
                "/status [id] · /tasks · /workers · /tools\n"
                "/research <konu> · /mode\n"
                "/adjust <id> <istediğin düzenleme>\n"
                "/stop <id> · /pause <id> · /resume <id> · /stopall")

    async def _report_loop(self) -> None:
        if not self.allowed:
            return
        q = self.orch.events.subscribe()
        verbose = self.settings.messaging.verbose
        notify = None if verbose else set(self.settings.messaging.notify_events)
        coalesce = self.settings.messaging.coalesce_seconds
        try:
            while not self.orch._stopping:
                ev = await q.get()
                if notify is not None and ev["type"] not in notify:
                    continue
                batch = [ev]
                deadline = asyncio.get_event_loop().time() + coalesce
                while True:
                    remaining = deadline - asyncio.get_event_loop().time()
                    if remaining <= 0:
                        break
                    try:
                        nxt = await asyncio.wait_for(q.get(), timeout=remaining)
                        if notify is None or nxt["type"] in notify:
                            batch.append(nxt)
                    except asyncio.TimeoutError:
                        break
                chunks = chunk_event_lines(
                    [format_telegram_event(e) for e in batch],
                    self.settings.messaging.max_message_chars)
                for chat_id in sorted(self.allowed):
                    for text in chunks:
                        await self.send(chat_id, text)
                # On completion, deliver artifacts: research report doc and/or a screenshot.
                for e in batch:
                    if (e["type"] == EventType.WORKER_COMPLETED.value
                            and (e.get("data") or {}).get("files")):
                        await self._deliver_step_files(e)
                    if e["type"] == EventType.TASK_COMPLETED.value and e.get("task_id"):
                        await self._deliver_completion(e["task_id"])
        except asyncio.CancelledError:
            pass
        finally:
            self.orch.events.unsubscribe(q)

    async def _deliver_step_files(self, ev: dict) -> None:
        """Send the exact files produced by one worker step as a portable ZIP."""
        tid = ev.get("task_id")
        task = self.orch.tasks.get(tid) if tid else None
        data = ev.get("data") or {}
        if not task or not task.get("workspace"):
            return
        root = Path(task["workspace"]).resolve()
        files: list[str] = []
        for rel in data.get("files") or []:
            try:
                p = (root / rel).resolve()
                p.relative_to(root)
                if p.is_file():
                    files.append(rel)
            except (OSError, ValueError):
                continue
        if not files:
            return
        out_dir = self.orch.settings.data_path / "artifacts"
        out_dir.mkdir(parents=True, exist_ok=True)
        step = data.get("step") or "x"
        worker = str(data.get("worker") or "worker").replace("#", "-")
        archive = out_dir / f"task-{tid}-step-{step}-{worker}.zip"
        manifest = [f"Task: #{tid}", f"Step: {step}", f"Worker: {data.get('worker')}",
                    f"Branch: {task.get('branch')}", f"Checkpoint: {data.get('checkpoint') or '-'}",
                    "", "Files:", *[f"- {p}" for p in files]]
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("HANDOFF.txt", "\n".join(manifest) + "\n")
            for rel in files:
                zf.write(root / rel, arcname=rel)
        caption = (f"📦 #{tid} adım {step} · {data.get('worker')}\n"
                   f"{len(files)} dosya · checkpoint {str(data.get('checkpoint') or '-')[:10]}")
        for chat_id in sorted(self.allowed):
            await self.send_document(chat_id, str(archive), caption)

    async def _deliver_completion(self, task_id: int) -> None:
        task = self.orch.tasks.get(task_id)
        if not task:
            return
        # Research report -> send the .md file and a short summary.
        report_path = (task.get("flags") or {}).get("report_path")
        if report_path and os.path.exists(report_path):
            for chat_id in sorted(self.allowed):
                await self.send_document(chat_id, report_path, f"#{task_id} research report")
            return
        await self._send_artifact(task_id)

    async def _send_artifact(self, task_id: int) -> None:
        try:
            task = self.orch.tasks.get(task_id)
            if not task:
                return
            # Look in the merged project first, then the worktree.
            roots = []
            if task.get("project_id"):
                p = self.orch.memory.get_project(task["project_id"])
                if p:
                    roots.append(p["path"])
            if task.get("workspace"):
                roots.append(task["workspace"])
            target = None
            for r in roots:
                target = screenshot.find_viewable(r, task.get("result") or "")
                if target:
                    break
            if not target:
                return
            out = str(self.orch.settings.data_path / "shots" / f"task-{task_id}-{int(time.time())}.png")
            shot = await screenshot.capture(target, out)
            if shot:
                cap = f"#{task_id} {os.path.basename(target)}"
                for chat_id in sorted(self.allowed):
                    await self.send_photo(chat_id, shot, cap)
        except Exception as e:
            log.debug("artifact screenshot skipped: %s", e)

    async def send_document(self, chat_id: int, path: str, caption: str = "") -> bool:
        try:
            with open(path, "rb") as f:
                files = {"document": (os.path.basename(path), f, "text/markdown")}
                data = {"chat_id": str(chat_id), "caption": caption[:1024]}
                async with httpx.AsyncClient(timeout=90) as c:
                    r = await c.post(f"{self.base}/sendDocument", data=data, files=files)
            return r.json().get("ok", False)
        except (httpx.HTTPError, OSError) as e:
            log.warning("telegram sendDocument failed: %s", e)
            return False

    async def send_photo(self, chat_id: int, path: str, caption: str = "") -> bool:
        try:
            with open(path, "rb") as f:
                files = {"photo": (os.path.basename(path), f, "image/png")}
                data = {"chat_id": str(chat_id), "caption": caption[:1024]}
                async with httpx.AsyncClient(timeout=90) as c:
                    r = await c.post(f"{self.base}/sendPhoto", data=data, files=files)
            return r.json().get("ok", False)
        except (httpx.HTTPError, OSError) as e:
            log.warning("telegram sendPhoto failed: %s", e)
            return False

    async def chat_action(self, chat_id: int, action: str = "typing") -> None:
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                await c.post(f"{self.base}/sendChatAction", json={"chat_id": chat_id, "action": action})
        except httpx.HTTPError:
            pass

    async def download_file(self, file_id: str, preferred_name: str | None = None) -> str | None:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                d = (await c.get(f"{self.base}/getFile", params={"file_id": file_id})).json()
                if not d.get("ok"):
                    return None
                fp = d["result"]["file_path"]
                img = await c.get(f"https://api.telegram.org/file/bot{self.token}/{fp}")
                name = preferred_name or os.path.basename(fp)
                name = re.sub(r"[^A-Za-z0-9_.-]+", "-", os.path.basename(name))[:120]
                out = self.orch.settings.data_path / "telegram" / f"{int(time.time())}-{name}"
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(img.content)
                return str(out)
        except (httpx.HTTPError, OSError) as e:
            log.warning("telegram download failed: %s", e)
            return None

    async def send(self, chat_id: int, text: str, retries: int = 2) -> bool:
        if not text or not text.strip():
            return False
        text = text[:4096]  # Telegram's hard per-message limit
        for attempt in range(retries + 1):
            try:
                async with httpx.AsyncClient(timeout=25) as c:
                    r = await c.post(f"{self.base}/sendMessage",
                                     json={"chat_id": chat_id, "text": text,
                                           "disable_web_page_preview": True})
                data = r.json()
                if data.get("ok"):
                    return True
                if r.status_code == 429:  # rate limited -> wait the requested time and retry
                    wait = min((data.get("parameters") or {}).get("retry_after", 2), 15)
                    await asyncio.sleep(wait)
                    continue
                log.warning("telegram send not ok (%s): %s", r.status_code, str(data)[:200])
                return False
            except httpx.HTTPError as e:
                log.warning("telegram send error (attempt %d): %r", attempt + 1, e)
                await asyncio.sleep(1.5)
        return False


async def run_telegram(orch: Orchestrator, settings: Settings) -> None:
    await TelegramBot(orch, settings).run()
