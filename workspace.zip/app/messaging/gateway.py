"""Messaging gateway: Instagram + WhatsApp webhooks in, leader replies + auto-reports out.

The gateway is pure transport — it verifies the sender, enforces an allowlist, and
hands text to the orchestrator; it contains no orchestration logic. It binds its own
port; only the webhook routes are exposed. Webhooks are HMAC-verified and only
allowlisted senders can command the leader or receive reports.
"""
from __future__ import annotations

import asyncio
import logging
import time

from fastapi import FastAPI, Request, Response

from ..config import Settings, secret
from ..orchestrator import Orchestrator
from ..orchestrator.events import EventType, format_event
from .graph import (GraphSender, parse_instagram, parse_whatsapp, verify_signature,
                    verify_subscription)

log = logging.getLogger("leader.gateway")


class MessagingGateway:
    def __init__(self, orch: Orchestrator, settings: Settings):
        self.orch = orch
        self.settings = settings
        self.sender = GraphSender(settings)
        self.db = orch.db

    def _allowed(self, channel: str, peer: str) -> bool:
        if channel == "instagram":
            allow = self.settings.messaging.instagram.allowed_sender_ids
        else:
            allow = self.settings.messaging.whatsapp.allowed_numbers
        return bool(allow) and peer in allow

    def _register_subscriber(self, channel: str, peer: str) -> None:
        self.db.execute(
            "INSERT INTO subscribers(channel,peer,last_event_id,last_inbound_at) VALUES(?,?,?,?) "
            "ON CONFLICT(channel,peer) DO UPDATE SET last_inbound_at=excluded.last_inbound_at",
            (channel, peer, self._max_event_id(), time.time()))

    def _max_event_id(self) -> int:
        row = self.db.query_one("SELECT COALESCE(MAX(id),0) AS m FROM events")
        return row["m"] if row else 0

    def _record(self, channel: str, direction: str, peer: str, text: str, status: str,
                external_id: str = "", error: str = "") -> int:
        return self.db.execute(
            "INSERT INTO messages(channel,direction,peer,text,status,external_id,error,created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (channel, direction, peer, text[:4000], status, external_id or None, error or None, time.time()))

    async def _handle_inbound(self, channel: str, peer: str, text: str, external_id: str) -> None:
        if not self._allowed(channel, peer):
            self._record(channel, "in", peer, text, "ignored_not_allowlisted", external_id)
            log.warning("ignoring %s message from non-allowlisted %s", channel, peer)
            return
        self._record(channel, "in", peer, text, "received", external_id)
        self._register_subscriber(channel, peer)
        try:
            reply = await self.orch.handle_message(text, source=channel)
        except Exception as e:
            reply = f"error handling your request: {e}"
            log.exception("handle_message failed")
        await self._send(channel, peer, reply)

    async def _send(self, channel: str, peer: str, text: str) -> None:
        text = text[: self.settings.messaging.max_message_chars]
        ok, detail = await self.sender.send(channel, peer, text)
        self._record(channel, "out", peer, text, "sent" if ok else "failed", error="" if ok else detail)
        if not ok:
            log.warning("send to %s/%s failed: %s", channel, peer, detail)

    # ------------------------------------------------------------------ reporter
    async def run_reporter(self) -> None:
        """Push important events to subscribers, coalesced into short bursts."""
        q = self.orch.events.subscribe()
        notify = set(self.settings.messaging.notify_events)
        coalesce = self.settings.messaging.coalesce_seconds
        try:
            while True:
                ev = await q.get()
                if ev["type"] not in notify:
                    continue
                batch = [ev]
                deadline = time.monotonic() + coalesce
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    try:
                        nxt = await asyncio.wait_for(q.get(), timeout=remaining)
                        if nxt["type"] in notify:
                            batch.append(nxt)
                    except asyncio.TimeoutError:
                        break
                await self._broadcast(batch)
        except asyncio.CancelledError:
            pass
        finally:
            self.orch.events.unsubscribe(q)

    async def _broadcast(self, batch: list[dict]) -> None:
        subs = self.db.query("SELECT channel,peer,last_event_id FROM subscribers")
        if not subs:
            return
        lines = [format_event(e) for e in batch]
        max_id = max(e["id"] for e in batch)
        text = "\n".join(lines)[: self.settings.messaging.max_message_chars]
        for sub in subs:
            if not self._allowed(sub["channel"], sub["peer"]):
                continue
            if max_id <= (sub["last_event_id"] or 0):
                continue
            await self._send(sub["channel"], sub["peer"], text)
            self.db.execute("UPDATE subscribers SET last_event_id=? WHERE channel=? AND peer=?",
                            (max_id, sub["channel"], sub["peer"]))


def build_gateway_app(gw: MessagingGateway) -> FastAPI:
    app = FastAPI(title="Leader Messaging Gateway", docs_url=None, redoc_url=None)
    s = gw.settings.messaging

    @app.get("/health")
    async def health():
        return {"ok": True}

    # ---- Instagram
    @app.get("/webhook/instagram")
    async def ig_verify(request: Request):
        p = request.query_params
        if verify_subscription(p.get("hub.mode"), p.get("hub.verify_token"),
                               secret("IG_VERIFY_TOKEN")):
            return Response(content=p.get("hub.challenge", ""), media_type="text/plain")
        return Response(status_code=403, content="forbidden")

    @app.post("/webhook/instagram")
    async def ig_inbound(request: Request):
        raw = await request.body()
        if not verify_signature(secret("IG_APP_SECRET"), raw,
                                request.headers.get("X-Hub-Signature-256")):
            return Response(status_code=403, content="bad signature")
        payload = await request.json()
        for m in parse_instagram(payload):
            asyncio.create_task(gw._handle_inbound(m.channel, m.peer, m.text, m.external_id))
        return {"ok": True}   # ack fast; processing happens in the background

    # ---- WhatsApp
    @app.get("/webhook/whatsapp")
    async def wa_verify(request: Request):
        p = request.query_params
        if verify_subscription(p.get("hub.mode"), p.get("hub.verify_token"),
                               secret("WHATSAPP_VERIFY_TOKEN")):
            return Response(content=p.get("hub.challenge", ""), media_type="text/plain")
        return Response(status_code=403, content="forbidden")

    @app.post("/webhook/whatsapp")
    async def wa_inbound(request: Request):
        raw = await request.body()
        if not verify_signature(secret("WHATSAPP_APP_SECRET"), raw,
                                request.headers.get("X-Hub-Signature-256")):
            return Response(status_code=403, content="bad signature")
        payload = await request.json()
        for m in parse_whatsapp(payload):
            asyncio.create_task(gw._handle_inbound(m.channel, m.peer, m.text, m.external_id))
        return {"ok": True}

    return app


async def run_gateway(orch: Orchestrator, settings: Settings) -> None:
    import uvicorn
    gw = MessagingGateway(orch, settings)
    app = build_gateway_app(gw)
    reporter = asyncio.create_task(gw.run_reporter())
    config = uvicorn.Config(app, host=settings.messaging.gateway_host,
                            port=settings.messaging.gateway_port, log_level="warning",
                            access_log=False)
    server = uvicorn.Server(config)
    try:
        await server.serve()
    finally:
        reporter.cancel()
