"""Instagram via browser scraping (no Meta API).

You log in ONCE in a visible window with your own account (cookies saved to a
persistent profile); the leader then watches a single DM conversation and replies
in it by driving the web UI. Because it watches one thread, only that person is
answered. It never types your password and never solves CAPTCHAs/challenges — if one
appears it pauses and asks you to handle it in the window.

WARNING: automating Instagram may violate Instagram's Terms of Use and can lead to
rate-limiting or account action. Use your own account, keep the poll interval
conservative, and run this at your own risk.
"""
from __future__ import annotations

import asyncio
import logging
import time

from ..config import InstagramScrapeSettings, Settings
from ..orchestrator import Orchestrator
from ..orchestrator.events import EventType, format_event
from ..security.secrets import redact
from ..tools.browser import BrowserOptions, BrowserSession, playwright_available

log = logging.getLogger("leader.ig_scrape")

CHALLENGE_MARKERS = ["suspicious", "we detected", "confirm it's you", "confirm its you",
                     "challenge_required", "captcha", "unusual activity", "help us confirm",
                     "your account has been", "try again later", "action blocked"]
LOGIN_MARKERS = ["log in", "phone number, username", "forgot password", "sign up"]

# JS that returns the text of the last visible message bubble in the open thread.
DEFAULT_EXTRACT_JS = r"""
() => {
  const main = document.querySelector('main') || document.body;
  const nodes = [...main.querySelectorAll('div[dir="auto"], span[dir="auto"]')]
    .filter(n => n.offsetParent !== null && n.innerText && n.innerText.trim().length);
  if (!nodes.length) return "";
  return nodes[nodes.length - 1].innerText.trim();
}
"""


def is_new_incoming(latest: str, last_seen: str, recent_sent: list[str]) -> bool:
    """True if `latest` is a fresh message from the other person (not our own echo)."""
    latest = (latest or "").strip()
    if not latest:
        return False
    if latest == (last_seen or "").strip():
        return False
    if latest in [s.strip() for s in recent_sent]:
        return False
    return True


def looks_like(markers: list[str], text: str) -> bool:
    low = (text or "").lower()
    return any(m in low for m in markers)


class InstagramScraper:
    def __init__(self, orch: Orchestrator, settings: Settings):
        self.orch = orch
        self.settings = settings
        self.s: InstagramScrapeSettings = settings.messaging.instagram_scrape
        self.profile = self.s.profile_dir or str(settings.data_path / "instagram" / "profile")
        self.last_seen = ""
        self.recent_sent: list[str] = []
        self._paused = False

    def _opts(self, headless: bool | None = None) -> BrowserOptions:
        return BrowserOptions(profile_dir=self.profile,
                              headless=self.s.headless if headless is None else headless,
                              channel=self.s.browser_channel)

    async def run(self) -> None:
        if not playwright_available():
            log.warning("instagram scraper: playwright not installed; channel disabled")
            return
        if not self.s.thread_url:
            log.warning("instagram scraper: no thread_url configured; channel disabled")
            return
        report_q = self.orch.events.subscribe() if self.s.push_reports else None
        notify = set(self.settings.messaging.notify_events)
        try:
            async with BrowserSession(self._opts()) as bs:
                page = await bs.page()
                await page.goto(self.s.thread_url, wait_until="domcontentloaded", timeout=60000)
                await asyncio.sleep(4)
                if not await self._logged_in(page):
                    log.warning("instagram scraper: not logged in — run: leader instagram-login")
                    return
                log.info("instagram scraper: watching thread, poll=%ss", self.s.poll_interval_s)
                # Prime last_seen so we don't reply to the pre-existing last message.
                self.last_seen = await self._extract(page)
                while not self.orch._stopping:
                    await asyncio.sleep(self.s.poll_interval_s)
                    if report_q is not None:
                        await self._drain_reports(page, report_q, notify)
                    await self._poll_once(page)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.warning("instagram scraper stopped: %s", e)
        finally:
            if report_q is not None:
                self.orch.events.unsubscribe(report_q)

    async def _poll_once(self, page) -> None:
        try:
            body = await page.inner_text("body")
        except Exception:
            body = ""
        if looks_like(CHALLENGE_MARKERS, body):
            if not self._paused:
                self._paused = True
                log.warning("instagram scraper: challenge/limit detected — paused; clear it in the window")
            return
        self._paused = False
        latest = await self._extract(page)
        if not is_new_incoming(latest, self.last_seen, self.recent_sent):
            self.last_seen = latest or self.last_seen
            return
        self.last_seen = latest
        text = latest.strip()
        log.info("instagram scraper: inbound: %s", redact(text)[:120])
        try:
            reply = await self.orch.handle_message(text, source="instagram")
        except Exception as e:
            reply = f"error: {e}"
        await self._send(page, reply)

    async def _drain_reports(self, page, q: asyncio.Queue, notify: set) -> None:
        lines = []
        while True:
            try:
                ev = q.get_nowait()
            except asyncio.QueueEmpty:
                break
            if ev["type"] in notify:
                lines.append(format_event(ev))
        if lines:
            await self._send(page, "\n".join(lines)[: self.s.max_reply_chars])

    async def _logged_in(self, page) -> bool:
        try:
            url = page.url
            if "/accounts/login" in url:
                return False
            body = (await page.inner_text("body"))[:4000]
        except Exception:
            return False
        # a composer present is the strongest signal
        if await self._composer(page) is not None:
            return True
        return not looks_like(LOGIN_MARKERS, body)

    async def _extract(self, page) -> str:
        try:
            return (await page.evaluate(DEFAULT_EXTRACT_JS)) or ""
        except Exception:
            return ""

    async def _composer(self, page):
        for sel in ['div[contenteditable="true"]', 'textarea[placeholder*="Message"]',
                    'textarea[aria-label*="Message"]', 'div[aria-label*="Message"]',
                    '[role="textbox"]']:
            try:
                el = await page.query_selector(sel)
                if el and await el.is_visible():
                    return el
            except Exception:
                continue
        return None

    async def _send(self, page, text: str) -> bool:
        text = (text or "").strip()[: self.s.max_reply_chars]
        if not text:
            return False
        el = await self._composer(page)
        if el is None:
            log.warning("instagram scraper: composer not found; cannot reply")
            return False
        try:
            await el.click()
            await el.type(text, delay=15)
            await page.keyboard.press("Enter")
            self.recent_sent.append(text)
            self.recent_sent = self.recent_sent[-10:]
            await asyncio.sleep(1.0)
            return True
        except Exception as e:
            log.warning("instagram scraper: send failed: %s", e)
            return False


async def run_instagram_scraper(orch: Orchestrator, settings: Settings) -> None:
    await InstagramScraper(orch, settings).run()
