"""The Leader: the local Ollama model acting as CTO/main brain.

Responsibilities that stay DETERMINISTIC (not left to the LLM), for reliability:
  * parsing control commands (status / stop / pause / resume / continue / stop all),
  * choosing which project a request refers to (fuzzy match over known projects),
  * enforcing the step schema and clamping plan size.

Responsibilities delegated to the LLM (schema-constrained JSON):
  * classifying a free-text message as command vs new task,
  * decomposing a task into an ordered list of typed steps,
  * synthesising worker review findings into a pass/fail decision,
  * writing short natural-language progress summaries.

If the LLM is unreachable or returns garbage, every LLM step has a deterministic
fallback so the system still functions (single implement+verify plan, etc.).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from ..tasks import StepKind
from .ollama_client import OllamaClient, OllamaError

log = logging.getLogger("leader")

MAX_STEPS = 8
VALID_KINDS = {k.value for k in StepKind}
PLAN_KINDS = {"investigate", "implement", "review", "edge_cases", "fix"}  # verify is auto-appended

INTENT_SCHEMA = {
    "type": "object",
    "properties": {
        "intent": {"type": "string",
                   "enum": ["new_task", "status", "question", "chat"]},
        "answer": {"type": "string"},
    },
    "required": ["intent"],
}

PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "complexity": {"type": "string", "enum": ["trivial", "simple", "moderate", "complex"]},
        "mode": {"type": "string", "enum": ["solo", "standard", "team"]},
        "effort": {"type": "string", "enum": ["low", "high"]},
        "needs_review": {"type": "boolean"},
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "kind": {"type": "string",
                             "enum": ["investigate", "implement", "review", "edge_cases", "fix"]},
                    "instruction": {"type": "string"},
                    "effort": {"type": "string", "enum": ["low", "high"]},
                },
                "required": ["kind", "instruction"],
            },
        },
    },
    "required": ["title", "steps"],
}

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "passed": {"type": "boolean"},
        "must_fix": {"type": "array", "items": {"type": "string"}},
        "summary": {"type": "string"},
    },
    "required": ["passed", "summary"],
}


@dataclass
class ParsedCommand:
    action: str                      # new_task | status | stop | pause | resume | continue |
                                     # stop_all | list | workers | recent_status | help | question | chat
    task_id: int | None = None
    text: str = ""
    answer: str = ""


@dataclass
class PlanStep:
    kind: StepKind
    instruction: str
    effort: str = "high"


@dataclass
class LeaderPlan:
    title: str
    steps: list[PlanStep]
    complexity: str = "moderate"
    mode: str = "standard"       # solo | standard | team
    effort: str = "high"        # default effort for steps that don't set their own
    needs_review: bool = True
    raw: dict = field(default_factory=dict)


# Deterministic control-command patterns (checked before consulting the LLM).
_CMD_PATTERNS = [
    ("stop_all", re.compile(r"^\s*(stop\s+all|emergency\s*stop|halt\s+everything|kill\s+all|acil\s*dur|hepsini\s+durdur)\s*$", re.I)),
    ("status", re.compile(r"^\s*(status|durum|progress|report|rapor|ne\s+durumda|status\?)\s*(?:of\s+)?#?(\d+)?\s*\??\s*$", re.I)),
    ("workers", re.compile(
        r"^\s*(?:hangi\s+)?(?:ai(?:'ler|ler|lar)?|yapay\s+zekalar?|agent(?:ler)?|"
        r"worker(?:lar|ler)?|modeller?)\s+(?:şu\s*an\s+|su\s*an\s+)?"
        r"(?:aktif|çalışıyor|calisiyor|hazır|hazir|available)"
        r"(?:\s+şu\s*an(?:da)?|\s+su\s*an(?:da)?)?"
        r"(?:\s+m[uiü])?\s*\??\s*$",
        re.I)),
    ("recent_status", re.compile(
        r"^\s*(?:ne\s+oldu|noldu|son\s+görev(?:e|de)?\s+ne\s+oldu|"
        r"son\s+gorev(?:e|de)?\s+ne\s+oldu|neden\s+durdu|niye\s+durdu)\s*\??\s*$",
        re.I)),
    ("stop", re.compile(r"^\s*(?:stop|cancel|abort|durdur|iptal)\s+(?:task\s+)?#?(\d+)\s*$", re.I)),
    ("pause", re.compile(r"^\s*(?:pause|beklet|duraklat)\s+(?:task\s+)?#?(\d+)\s*$", re.I)),
    ("resume", re.compile(r"^\s*(?:resume|unpause|devam\s+et)\s+(?:task\s+)?#?(\d+)\s*$", re.I)),
    ("continue", re.compile(r"^\s*(?:continue|devam)\s+(?:task\s+)?#?(\d+)\s*$", re.I)),
    ("list", re.compile(r"^\s*(?:list|tasks|listele|görevler|gorevler)\s*$", re.I)),
    ("help", re.compile(r"^\s*(?:help|yardım|yardim|/help|\?)\s*$", re.I)),
]


class Leader:
    def __init__(self, client: OllamaClient):
        self.client = client

    # ------------------------------------------------------------------ commands
    def parse_command(self, text: str) -> ParsedCommand | None:
        """Deterministic parse of control commands. Returns None if it's not one
        (i.e. it should be treated as a task or question)."""
        # Free-form live adjustment: keep the task id structured and preserve the
        # remainder verbatim as user guidance.
        adjust_patterns = [
            re.compile(r"^\s*(?:adjust|modify|edit|düzenle|duzenle|değiştir|degistir|"
                       r"şekillendir|sekillendir)\s+(?:task\s*)?#?(\d+)\s*[:\-]\s*(.+)$",
                       re.I | re.S),
            re.compile(r"^\s*#?(\d+)\s*(?:'?(?:yi|yı|yu|yü|i|ı|u|ü)|"
                       r"numaralı\s+görevi|numarali\s+gorevi)?\s*"
                       r"(?:düzenle|duzenle|değiştir|degistir|şekillendir|sekillendir)\s*"
                       r"[:\-]?\s*(.+)$", re.I | re.S),
            re.compile(r"^\s*#?(\d+)\s*['’]?(?:de|da)\s+(.+\b(?:değiştir|degistir|"
                       r"düzenle|duzenle|güncelle|guncelle|ekle|kaldır|kaldir|yap).*)$",
                       re.I | re.S),
        ]
        for rx in adjust_patterns:
            m = rx.match(text)
            if m and m.group(2).strip():
                return ParsedCommand("adjust", task_id=int(m.group(1)), text=m.group(2).strip())
        for action, rx in _CMD_PATTERNS:
            m = rx.match(text)
            if not m:
                continue
            tid = None
            for g in m.groups()[1:] if action == "status" else m.groups():
                if g and g.isdigit():
                    tid = int(g)
                    break
            # status regex has the verb in group 1; scan all groups for a number
            if action == "status":
                nums = [int(g) for g in m.groups() if g and g.isdigit()]
                tid = nums[0] if nums else None
            return ParsedCommand(action, task_id=tid, text=text)
        return None

    async def classify(self, text: str) -> ParsedCommand:
        """Command first (deterministic), else ask the LLM new_task vs question vs chat."""
        cmd = self.parse_command(text)
        if cmd:
            return cmd
        # Explicit question prefix -> the leader answers directly, no task/worker.
        m = re.match(r"^\s*(soru|sor|question|ask|chat|sohbet)\s*[:：]\s*(.+)", text, re.I | re.S)
        if m:
            return ParsedCommand("question", text=m.group(2).strip())
        # Deep-research intent -> a research task (web report), not a coding task.
        if re.search(r"\b(deriniemesine|derinlemesine|derin\s*araştırma|derin\s*arastirma|"
                     r"araştır|arastir|araştırma|arastirma|research|deep\s*research)\b", text, re.I):
            return ParsedCommand("research", text=text)
        # Heuristic: imperative coding verbs -> almost certainly a task; skip the LLM.
        if re.search(r"\b(fix|add|implement|create|build|refactor|debug|review|test|make|"
                     r"optimize|update|write|remove|migrate|düzelt|ekle|oluştur|yap|incele)\b",
                     text, re.I) and len(text) > 12:
            return ParsedCommand("new_task", text=text)
        try:
            data = await self.client.chat_json([
                {"role": "system", "content":
                 "Classify the user's message. 'new_task' = they want coding work done on a "
                 "project. 'status' = asking about progress. 'question' = a question about the "
                 "system or their code that needs an answer, no work. 'chat' = smalltalk. "
                 "If 'question' or 'chat', put a brief reply in 'answer'. Output only JSON."},
                {"role": "user", "content": text},
            ], INTENT_SCHEMA, temperature=0.1)
        except OllamaError as e:
            log.warning("classify fallback: %s", e)
            return ParsedCommand("new_task", text=text)
        intent = data.get("intent", "new_task")
        if intent == "status":
            return ParsedCommand("status", text=text)
        if intent in ("question", "chat"):
            return ParsedCommand(intent, text=text, answer=data.get("answer", ""))
        return ParsedCommand("new_task", text=text)

    # ------------------------------------------------------------------ planning
    async def plan(self, request: str, *, project_context: str = "", tools: str = "",
                   workers: str = "") -> LeaderPlan:
        system = (
            "You are the technical lead of a team of autonomous coding agents (Codex, Claude "
            "Code, Arena, and others). Break the user's request into the MINIMUM ordered steps.\n"
            "Step kinds:\n"
            "- investigate: read-only analysis to locate the cause / understand code\n"
            "- implement: write code to build the feature/change\n"
            "- fix: write code to correct failures or review findings\n"
            "- review: read-only senior review of the change (a DIFFERENT agent critiques it)\n"
            "- edge_cases: read-only hunt for bugs/edge cases (a DIFFERENT agent)\n"
            "Pick a mode:\n"
            "- solo: one small change, one implement step, effort=low.\n"
            "- standard: a normal feature/fix; implement (+ maybe investigate/fix).\n"
            "- team: a real project or complex task — the WHOLE team builds ONE codebase together. "
            "  Split the implementation into 2-4 SEPARATE 'implement' steps, one per component/module "
            "  (e.g. backend, frontend, data layer, tests-scaffold), so DIFFERENT agents each write a "
            "  different part. Then add review AND edge_cases by other agents, then fix. Do NOT put all "
            "  the work in one implement step — divide it so every agent contributes a piece.\n"
            "Pick effort per step: 'low' for simple/mechanical work (cheaper, faster models), "
            "'high' for complex reasoning. Prefer low when it will clearly suffice.\n"
            "Rules: Do NOT add a test/verify step — the orchestrator always builds and runs tests "
            "itself. Use team mode with review+edge_cases for anything substantial. Never exceed "
            "7 steps. Each instruction must be concrete and self-contained. Output only JSON."
        )
        ctx = []
        if project_context:
            ctx.append("## Project\n" + project_context)
        if tools:
            ctx.append("## Available tools\n" + tools)
        if workers:
            ctx.append("## Available workers\n" + workers)
        ctx.append("## Request\n" + request)
        try:
            data = await self.client.chat_json(
                [{"role": "system", "content": system},
                 {"role": "user", "content": "\n\n".join(ctx)}],
                PLAN_SCHEMA, temperature=0.2)
            return self._plan_from_json(data, request)
        except OllamaError as e:
            log.warning("plan fallback (%s); using single implement step", e)
            return LeaderPlan(title=request[:80], complexity="simple", needs_review=False,
                              steps=[PlanStep(StepKind.IMPLEMENT, request)])

    def _plan_from_json(self, data: dict, request: str) -> LeaderPlan:
        mode = data.get("mode", "standard")
        if mode not in ("solo", "standard", "team"):
            mode = "standard"
        default_effort = data.get("effort", "low" if mode == "solo" else "high")
        default_effort = default_effort if default_effort in ("low", "high") else "high"
        steps: list[PlanStep] = []
        for raw in data.get("steps", []):
            kind = str(raw.get("kind", "")).lower().strip()
            instr = str(raw.get("instruction", "")).strip()
            eff = raw.get("effort", default_effort)
            eff = eff if eff in ("low", "high") else default_effort
            if kind in PLAN_KINDS and instr:
                steps.append(PlanStep(StepKind(kind), instr, effort=eff))
            if len(steps) >= MAX_STEPS:
                break
        if not steps:
            steps = [PlanStep(StepKind.IMPLEMENT, request, effort=default_effort)]
        if not any(s.kind in (StepKind.IMPLEMENT, StepKind.FIX) for s in steps):
            steps.append(PlanStep(StepKind.IMPLEMENT, request, effort=default_effort))
        # Team mode guarantees cross-agent review + edge-case hunting on the one project.
        if mode == "team":
            kinds = {s.kind for s in steps}
            insert_at = max((i for i, s in enumerate(steps)
                             if s.kind in (StepKind.IMPLEMENT, StepKind.FIX)), default=len(steps) - 1) + 1
            extra = []
            if StepKind.REVIEW not in kinds:
                extra.append(PlanStep(StepKind.REVIEW, "Critically review the implementation for "
                                      "correctness, security and design.", effort="high"))
            if StepKind.EDGE_CASES not in kinds:
                extra.append(PlanStep(StepKind.EDGE_CASES, "Hunt for bugs and missing edge cases in "
                                      "the implementation.", effort="high"))
            steps[insert_at:insert_at] = extra
            steps = steps[:MAX_STEPS]
        return LeaderPlan(
            title=(data.get("title") or request[:80]).strip()[:120],
            steps=steps,
            complexity=data.get("complexity", "moderate"),
            mode=mode,
            effort=default_effort,
            needs_review=bool(data.get("needs_review", mode == "team")),
            raw=data)

    # ------------------------------------------------------------------ review synthesis
    async def synthesise_review(self, verdicts: list[dict], diff_stat: str) -> dict:
        """Combine worker review verdicts into a single pass/fail + must-fix list."""
        # Deterministic short-circuits.
        if not verdicts:
            return {"passed": True, "must_fix": [], "summary": "no review requested"}
        any_fail = any(v and v.get("passed") is False for v in verdicts)
        all_issues: list[str] = []
        for v in verdicts:
            all_issues += (v or {}).get("issues", [])
        if not any_fail and not all_issues:
            return {"passed": True, "must_fix": [], "summary": "reviewers found no blocking issues"}
        try:
            data = await self.client.chat_json([
                {"role": "system", "content":
                 "You are the lead deciding whether a change is acceptable. Given reviewers' "
                 "findings, decide passed=true only if there are no correctness/security blockers. "
                 "List only genuinely blocking items in must_fix (max 6), each actionable. JSON only."},
                {"role": "user", "content":
                 f"Diff stat:\n{diff_stat}\n\nReviewer findings:\n" +
                 "\n".join(f"- {i}" for i in all_issues[:40]) +
                 f"\n\nAny reviewer failed: {any_fail}"},
            ], REVIEW_SCHEMA, temperature=0.1)
            data.setdefault("must_fix", [])
            return data
        except OllamaError:
            return {"passed": not any_fail, "must_fix": all_issues[:6],
                    "summary": "review (heuristic): " + ("issues found" if any_fail else "ok")}

    async def choose_solution(self, request: str, proposals: list[str]) -> str:
        """Choose between independent approaches for a critical task."""
        if not proposals:
            return "No competing proposal was available; proceed conservatively."
        if len(proposals) == 1:
            return proposals[0][:4000]
        prompt = ("Original critical task:\n" + request + "\n\nIndependent proposals:\n" +
                  "\n\n".join(f"## Proposal {i + 1}\n{p[:6000]}"
                                for i, p in enumerate(proposals[:2])) +
                  "\n\nSelect the safer and more correct approach. Return a concise decision, "
                  "why it wins, useful parts to borrow from the other proposal, and an actionable "
                  "implementation plan. Do not write code.")
        try:
            return (await self.client.chat([
                {"role": "system", "content": "You are the final technical decision-maker. "
                 "Prioritize correctness, security, testability and rollback safety."},
                {"role": "user", "content": prompt},
            ], temperature=0.15)).strip()[:6000]
        except OllamaError:
            return ("Leader fallback selection: use Proposal 1 as the baseline and incorporate "
                    "any additional safety checks from Proposal 2.\n\n" + proposals[0][:4000])

    async def answer(self, text: str, context: str = "") -> str:
        """Answer a simple question directly, using the leader model only (no workers)."""
        msgs = [{"role": "system", "content":
                 "You are the user's engineering leader/assistant. Answer their question "
                 "directly, concisely and helpfully in the user's language. Only if fulfilling "
                 "it clearly requires editing their code should you say you can do it as a task "
                 "and ask them to confirm — otherwise just answer."}]
        if context:
            msgs.append({"role": "system", "content": "Context:\n" + context})
        msgs.append({"role": "user", "content": text})
        try:
            return (await self.client.chat(msgs, temperature=0.4)).strip()[:1500]
        except OllamaError:
            return "I couldn't reach the local model to answer that right now."

    async def analyze_image(self, image_path: str, prompt: str = "") -> str:
        """Examine an image the user sent, with the leader's vision model."""
        p = prompt.strip() or ("Bu görseli ayrıntılı incele ve ne olduğunu açıkla. "
                               "Metin/kod varsa oku. (Analyze this image in detail.)")
        try:
            return (await self.client.vision(p, image_path)).strip()[:2500]
        except OllamaError as e:
            return f"Görseli inceleyemedim (vision hatası): {e}"

    async def summarise(self, prompt: str) -> str:
        try:
            return (await self.client.chat(
                [{"role": "system", "content": "Reply with one short status sentence, no preamble."},
                 {"role": "user", "content": prompt}], temperature=0.3)).strip()[:300]
        except OllamaError:
            return prompt[:200]
