"""Thin async client for the local Ollama chat API with JSON-schema-constrained output."""
from __future__ import annotations

import json
import logging

import httpx

log = logging.getLogger("leader.ollama")


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, url: str, model: str, *, timeout_s: float = 300, num_ctx: int = 16384,
                 keep_alive: str = "30m"):
        self.url = url.rstrip("/")
        self.model = model
        self.timeout_s = timeout_s
        self.num_ctx = num_ctx
        self.keep_alive = keep_alive

    async def chat(self, messages: list[dict], *, schema: dict | None = None,
                   temperature: float = 0.2, think: bool = False,
                   model: str | None = None) -> str:
        payload = {
            "model": model or self.model,
            "messages": messages,
            "stream": False,
            "think": think,
            "keep_alive": self.keep_alive,
            "options": {"temperature": temperature, "num_ctx": self.num_ctx},
        }
        if schema is not None:
            payload["format"] = schema
        try:
            async with httpx.AsyncClient(timeout=self.timeout_s) as c:
                r = await c.post(f"{self.url}/api/chat", json=payload)
                r.raise_for_status()
                data = r.json()
        except httpx.HTTPError as e:
            raise OllamaError(f"ollama request failed: {e}") from e
        if data.get("error"):
            raise OllamaError(data["error"])
        return data.get("message", {}).get("content", "")

    async def chat_json(self, messages: list[dict], schema: dict, *, temperature: float = 0.2,
                        model: str | None = None) -> dict:
        content = await self.chat(messages, schema=schema, temperature=temperature, model=model)
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            start, end = content.find("{"), content.rfind("}")
            if start != -1 and end != -1:
                try:
                    return json.loads(content[start:end + 1])
                except json.JSONDecodeError:
                    pass
            raise OllamaError(f"leader did not return valid JSON: {content[:300]}")

    async def vision(self, prompt: str, image_path: str, *, model: str | None = None,
                     temperature: float = 0.3) -> str:
        """Analyze an image with the leader model (gemma4/qwen have vision)."""
        import base64
        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        payload = {
            "model": model or self.model,
            "messages": [{"role": "user", "content": prompt or "Describe this image in detail.",
                          "images": [b64]}],
            "stream": False, "keep_alive": self.keep_alive,
            "options": {"temperature": temperature, "num_ctx": self.num_ctx},
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout_s) as c:
                r = await c.post(f"{self.url}/api/chat", json=payload)
                r.raise_for_status()
                data = r.json()
        except httpx.HTTPError as e:
            raise OllamaError(f"vision request failed: {e}") from e
        if data.get("error"):
            raise OllamaError(data["error"])
        return data.get("message", {}).get("content", "")

    async def available(self) -> tuple[bool, str]:
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(f"{self.url}/api/tags")
                r.raise_for_status()
                names = [m.get("name") for m in r.json().get("models", [])]
            if self.model in names:
                return True, "ready"
            return False, f"model {self.model} not pulled (have: {', '.join(names) or 'none'})"
        except httpx.HTTPError as e:
            return False, f"ollama unreachable: {e}"
