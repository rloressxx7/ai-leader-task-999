# Ollama Leader — persistent build TODO

Legend: [x] done & tested · [~] built, partially verified · [ ] not started · [!] blocked on external input

## Environment facts (verified 2026-09-26)
- Ollama 0.34.4 @127.0.0.1:11434 — models: gemma4:26b (default leader), Qwen3.6-35B-A3B abliterated
- Claude Code 2.1.281 bundled at %APPDATA%\Claude\claude-code\<ver>\claude.exe — NOT on PATH,
  standalone CLI NOT logged in (`claude auth status` → loggedIn=false). User must run `claude auth login` once.
- Codex CLI 0.158.0-alpha.2 at %LOCALAPPDATA%\OpenAI\Codex\bin\<hash>\codex.exe — logged in (ChatGPT).
  Its Windows sandbox (workspace-write) cannot see per-user Python → Leader runs tests itself.
- Arena.ai: NO documented API (api.arena.ai does not resolve). Browser adapter only.
- Chrome + Edge installed (Playwright can use channel="chrome", no browser download needed).
- gh CLI missing; GitHub MCP not authorized.

## Phase 1 — Core MVP  ✅ COMPLETE (built + tested, live E2E green 2026-09-26)
- [x] Config (TOML + env secrets), binary auto-discovery
- [x] SQLite schema
- [x] Task/step state machine + store
- [x] Event bus + emoji reports + persisted events
- [x] Policy engine (AUTO/CONFIRM/BLOCK) + secret scanner/redactor
- [x] Tool registry with real health probes
- [x] Terminal runner (kill process tree, timeouts)
- [x] Git ops: repo detection, worktrees, checkpoints, diff scan, safe merge
- [x] Worker abstraction + registry + persisted availability + stats
- [x] Claude Code adapter (stream-json)  [needs one-time `claude auth login`]
- [x] Codex adapter (exec --json)  [verified working]
- [x] Generic CLI adapter
- [x] Ollama leader: deterministic commands, intent, planning, review parsing
- [x] Orchestrator: plan → workspace → steps → verify → fix loop → finalize
- [x] Failover + rate-limit handling
- [x] Crash recovery on restart (tested)
- [x] Independent verification (build/test detection + counts)
- [x] Dashboard @127.0.0.1:18789 (token-protected mutations, SSE)
- [x] CLI: serve / send / status / stop-all / doctor
- [x] Unit tests (55 passing)
- [x] Live E2E: real Ollama plan + real Codex fix + real pytest 3/3 + real merge

### Bugs found & fixed during E2E (kept as notes)
- source-only folders (no manifest) weren't discovered as projects -> fixed
- verifier used Windows `py` launcher (no pytest) -> use project venv / sys.executable
- stale review verdicts gated the fix loop forever -> reviews now advisory, tests are the gate

## Phase 2  ✅ built (live task flow pending user's one-time Arena login)
- [x] Arena browser adapter (Playwright, persistent profile, human login, no CAPTCHA bypass)
- [x] Multiple Arena workers (arena#1..N, own profiles)
- [x] Parallel read-only steps (engine runs same-group read-only steps concurrently)
- [x] Playwright + Chrome verified against live arena.ai; login detection correct
- [x] arena-login CLI helper; file-block parse/apply with secret-scan + containment
- [!] Live implement/review via Arena needs the user to log in once: `python -m app arena-login`
## Phase 3  ✅ built (live needs user's Meta app tokens + public HTTPS webhook)
- [x] Messaging gateway on separate port (only webhooks exposed), fast-ack + async processing
- [x] Instagram adapter (Graph API send + parse, HMAC verify, allowlist)
- [x] WhatsApp Cloud API adapter (send + parse, HMAC verify, allowlist)
- [x] Event → message delivery with coalescing + persisted per-subscriber cursor
- [x] Tests: signature verify, payload parse, allowlist enforcement, inbound->reply (mocked send)
- [x] Live HTTP smoke test of dashboard server: /, /api/state, token auth (401/200), submit->reply
- [!] Live API messaging needs: Meta app, IG/WhatsApp tokens in secrets.env, public HTTPS webhook (tunnel)
- [x] Instagram via BROWSER SCRAPING (user's preference): cookie/session login, watch one
      DM thread, reply + push reports; `instagram-login` helper; no API/webhook needed
- [!] IG scraping DOM extraction/selectors are best-effort (IG obfuscates + changes markup);
      needs live tuning with the user (can't test blind); account-ban risk noted in docs
## Phase 4  ✅ core items done
- [x] Project memory + discovery (memory/, done in Phase 1)
- [x] Worker performance stats → scheduler selection (registry scoring, Phase 1)
- [x] Automatic task decomposition (leader planning, Phase 1)
- [x] Supervisor watchdog: recovers orphaned/stalled active tasks, re-arms parked ones
- [x] setup.ps1 + leader.ps1 convenience scripts
- [ ] Out-of-PROCESS supervisor (separate watchdog process) + OS autostart — optional; the
      in-process supervisor + startup crash-recovery already cover restart safety
- [ ] More tool adapters (screenshots via Pillow, etc.) — add on demand
