# One-time setup for Ollama Leader (Windows PowerShell). ASCII-only for PS 5.1.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "Creating virtualenv..." -ForegroundColor Cyan
if (-not (Test-Path ".venv")) { python -m venv .venv }

Write-Host "Installing dependencies..." -ForegroundColor Cyan
.\.venv\Scripts\python -m pip install -q --upgrade pip
.\.venv\Scripts\python -m pip install -q -e ".[browser,dev]"

Write-Host "Installing Chromium for Playwright (Arena worker)..." -ForegroundColor Cyan
.\.venv\Scripts\python -m playwright install chromium

if (-not (Test-Path "config.toml")) {
    Copy-Item "config.example.toml" "config.toml"
    Write-Host "Created config.toml from the example. Edit paths (Windows-style) if needed." -ForegroundColor Yellow
}
if ((-not (Test-Path "secrets.env")) -and (Test-Path "secrets.env.example")) {
    Copy-Item "secrets.env.example" "secrets.env"
}

Write-Host "`nChecking environment..." -ForegroundColor Cyan
.\.venv\Scripts\python -m app doctor

Write-Host "`nSetup done." -ForegroundColor Green
Write-Host "  If a worker needs login: .\leader.bat claude-login   (codex is already logged in)"
Write-Host "  Start the leader:        .\leader.bat"
Write-Host "  Log in an Arena worker:  .\leader.bat arena-login --profile 1"
