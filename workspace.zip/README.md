# Ollama Leader — autonomous multi-agent coding orchestrator

A **local Ollama model is the leader/CTO.** You talk to the leader in plain language;
it plans the work, delegates real coding to worker agents (**Codex**, **Claude Code**,
and others), runs on your actual project files, **verifies the result by building and
running the tests itself**, fixes what fails, recovers from crashes, and reports
progress automatically.

It does **not** paste text into a chat box. Workers edit files and run commands for
real, in isolated git worktrees, and the leader merges verified work back.

```
YOU ──► Leader (local Ollama)  ──►  Orchestrator ──► Codex / Claude Code / (Arena) / generic
              │                          │
              │                          ├─ isolated git worktree per task
              └── auto progress reports  ├─ independent build + test verification
                  (dashboard / SSE)      └─ policy-gated merge back to your branch
```

## Status

**Phase 1 (core) — built and verified end-to-end.** A real task ("fix the bug in
mathkit so tests pass") was planned by the local model, implemented by Codex on the
real files, verified by the orchestrator running the real pytest suite (3/3), and
merged back — fully autonomously.

| Component | State |
|---|---|
| Ollama leader: intent parsing, planning, review synthesis (schema-constrained JSON, deterministic fallbacks) | ✅ |
| Task/step state machine + SQLite persistence | ✅ |
| Worker abstraction, registry, availability, performance stats | ✅ |
| Codex adapter (`codex exec --json`, workspace-write sandbox) | ✅ verified logged-in & working |
| Claude Code adapter (`claude -p` stream-json, acceptEdits + allow-list) | ✅ built — **needs one-time `claude auth login`** |
| Generic CLI worker adapter | ✅ |
| Independent verification (auto-detect + run build/tests, parse pass/fail) | ✅ |
| Failover, retries, rate-limit/auth handling, stall detection | ✅ |
| Crash recovery on restart | ✅ tested |
| Git worktrees, checkpoints, safe merge, secret-scanned diffs | ✅ |
| Policy engine (AUTO/CONFIRM/BLOCK) + secret redaction | ✅ |
| Event bus + automatic emoji progress reports | ✅ |
| Local dashboard @ `127.0.0.1:18789` (SSE, token-gated controls) | ✅ |
| Emergency stop / pause / resume / continue | ✅ |
| Supervisor watchdog (recovers orphaned/stalled tasks) | ✅ tested |
| Arena browser adapter, multiple workers (Playwright) | ✅ built — **needs one-time `arena-login`** |
| Instagram / WhatsApp gateway | ✅ built — **needs Meta tokens + public webhook** |

## Requirements

- **Ollama** running with a capable tool/JSON model. Default `gemma4:26b` (also
  fine: the Qwen3.6 model). `ollama pull gemma4:26b`.
- **Codex CLI** logged in (`codex login`) — auto-discovered on Windows.
- **Claude Code** logged in for the CLI: `claude auth login` (or `claude setup-token`).
  Being logged into the Claude desktop app is **not** the same as the standalone CLI.
- Python 3.11+, git.

## Quick start

```bash
cd ollama-leader
python -m venv .venv
.venv\Scripts\python -m pip install -e .
copy config.example.toml config.toml   # then edit paths (Windows-style!)

.venv\Scripts\python -m app doctor      # check leader, workers, tools
.venv\Scripts\python -m app serve       # start leader + dashboard
```

Open `http://127.0.0.1:18789` (token printed on start, also in
`data/dashboard_token.txt`). Or from another shell:

```bash
.venv\Scripts\python -m app send "fix the reconnect in my solana bot and make tests pass"
.venv\Scripts\python -m app status
.venv\Scripts\python -m app stop-all
```

## What "done" means (no fake completion)

A worker saying "done" is never trusted. The orchestrator detects the project's
build/test commands (Cargo, npm/pnpm/yarn, pytest, go, make), **runs them itself**,
parses pass/fail counts, and only completes a task when the build succeeds and tests
pass. If they fail, it spawns fix steps (up to a limit) and re-verifies. Reviews from
worker agents are advisory — they seed fixes but never fail a task whose tests pass.

## Safety model

Normal development is fully autonomous. Only irreversible/outward actions are gated,
and the gate is enforced by the orchestrator (and passed to workers as a deny-list),
not left to a worker's goodwill:

- **BLOCK:** force-push, delete-repository, destroy-database, destructive system
  commands (`rm -rf /`, `format`, `mkfs`…), financial transfers (`solana transfer`,
  `spl-token transfer`, `cast send`…), publishing credentials.
- **CONFIRM:** `git push`, deploy/publish (npm/cargo/docker/anchor/k8s/terraform…),
  bulk deletes, committing detected secrets.
- **AUTO:** everything else, including the local, reversible, secret-scanned merge
  back into your branch (only when the tree is clean and there are no conflicts).

Every category is reconfigurable in `config.toml`. Secrets are redacted before they
reach the DB, logs, events, or any third-party worker. Emergency **STOP ALL** halts
every task and kills every worker process tree.

## Layout

```
app/
├── leader/         local-Ollama brain: commands, planning, review synthesis
├── orchestrator/   engine, events, verification, project resolution
├── workers/        base + claude_code, codex, generic, registry (failover/stats)
├── tools/          terminal (kill-tree), git (worktrees/merge), filesystem, computer, registry
├── tasks/          state machine + SQLite-backed store
├── memory/         project discovery + persistent project/worker memory
├── security/       policy engine + secret detection/redaction
├── dashboard/      FastAPI + single-page UI + SSE
├── database/       SQLite schema/access
└── config/         TOML settings + binary auto-discovery
tests/              55 tests (policy, secrets, verify, tasks, recovery, git, projects…)
```
